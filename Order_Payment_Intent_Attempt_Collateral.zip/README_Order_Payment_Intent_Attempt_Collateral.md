# Order / Payment Intent / Payment Attempt — Collateral Pack

This archive consolidates the located prior working collateral on the PSP Order, Payment Intent/Payment, and Payment Attempt model, plus directly supporting architecture and lifecycle material.

## Contents

### 01 — Core API and object model
- `payment_attempt_intent_order_api_assessment.md` — original comparison and recommendation for Order → Payment Intent → Payment Attempt; API philosophy, use cases, and Decision Platform relationship.
- `The Case for Intent.html` — earlier intent-led API/domain narrative.
- `The_Case_for_Intent_1.2.txt` — extracted text of the later 1.2 HTML working document; included as text because raw-byte export of the original HTML was unavailable.
- `API-Simplification-Review-Response.pdf` — later review response and important refinement of the external API model.

### 02 — Platform architecture
- `PSP_Modular_Payment_Platform_Architecture_Specification_v1.0.docx` — modular platform architecture specification.
- `psp-enterprise-architecture.pdf` — enterprise architecture and system-of-record boundaries for Order, Payment, Session, Attempt, orchestration, routing/retry, and post-authorization operations.
- `upop-platform-architecture-v3-6.pdf` — later UPOP platform architecture, including resource lifecycle, execution, orchestration, and recovery architecture.
- `definitions-and-readiness.pdf` — supporting platform definitions/readiness material.

### 03 — Adjacent lifecycle domains
- `Payment_Resolution_Platform_Strategy_Evaluation_and_Target_Design.pdf` — refund/dispute/alert/resolution design linked to the Order/Payment/Attempt spine.
- `Multi currency support for psp .pdf` — currency and routing design with Order/Session/Payment/Attempt responsibilities.

## Important evolution note — do not treat every document as one unchanged decision

The September assessment recommends three externally meaningful abstraction levels: Order (commerce), Payment Intent (payment lifecycle), and Payment Attempt (execution). Subsequent architecture material retains the Order/Payment/Session/Attempt lifecycle spine.

The later `API-Simplification-Review-Response.pdf` materially refines the external API recommendation:
- Do not force clients that already own an OMS to create a duplicate PSP Order; carry their `order_ref`/merchant order reference instead.
- For clients without an order system, the PSP may own the Order resource.
- The collection aggregate is presented as `Payment` / `PaymentRequest` rather than importing Stripe's `PaymentIntent` vocabulary.
- Attempts and replans remain internal, with read-only visibility for clients that need the decision trace.
- Order, collection/payment, and Session have distinct state dimensions; Session completion does not mean payment completion.

Use the later review response as the most recent API naming/entry-point refinement, while retaining the earlier assessment as the rationale and design history. The documents are working collateral from different dates and should be read with that chronology in mind.

## Scope

This pack contains the relevant located files from the user's Library. It does not claim to include every discussion message or every possible related PSP artifact. The `The Case for Intent 1.2` item is text-extracted; the original HTML binary could not be materialized through the Library export path.
