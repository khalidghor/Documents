# Data Model and API Supplement

This supplement fills the gap in the original collateral archive by providing two explicit, consolidated working specifications:

- `01_Canonical_Data_Model.md` — entities, relationships, attributes, state machines, ownership and invariants.
- `02_API_Resource_and_Endpoint_Specification.md` — progressive-disclosure integration paths, endpoint catalogue, JSON examples, events and open decisions.

These documents adopt the later API simplification position: Order / Obligation / PaymentRequest / typed Session / Attempt / Capture / Refund. Earlier Payment Intent terminology is retained in historical source documents to show the evolution of the design. Example request/response schemas are target proposals and must be checked against the production API contract before implementation.
