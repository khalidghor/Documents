# API Resource & Endpoint Specification — Progressive Disclosure

**Status:** Consolidated target proposal based on the API simplification review. Existing production `POST /payments` semantics are preserved. The durable collection aggregate is externally named `paymentRequest` (`pr_`), not `PaymentIntent`; Payment Intent is the conceptual predecessor in earlier strategy collateral.

## 1. Start with the OMS question

**Does the merchant already own the Order?**

- **Yes:** the merchant's OMS is authoritative. Do not create a PSP Order. Carry `order_ref` on payment/collection requests and optionally declare `order_total` for a derived owed-vs-collected ledger.
- **No:** PSP Order is the commercial system of record. Create an Order and use checkout orchestration.

Both branches use the same underlying PaymentRequest, Session, Attempt, Capture and Refund model, state transitions, webhooks and reconciliation join keys.

## 2. Integration levels

| Level | Use case | API surface |
|---|---|---|
| 1 — Simple payment | Merchant owns UI and order; one-step payment | Existing `POST /payments` |
| 2 — Order-led checkout | Merchant has no OMS; PSP manages thin Order and checkout | `POST /orders`, `POST /orders/{id}/checkout` |
| 3 — Explicit orchestration | Delayed capture, multi-tender, cross-channel continuation, terminal, marketplace and advanced flows | `/payment_requests`, typed `/sessions`, confirm, captures, refunds |

Progressive disclosure is additive. A simple merchant should not have to create an Order, PaymentRequest and Session just to authorize a card.

## 3. Level 1 — preserve the existing simple payment API

```http
POST /payments
Idempotency-Key: 8d8d...
Content-Type: application/json
```

```json
{
  "amount": 10000,
  "currency": "USD",
  "captureMethod": "NOW",
  "merchantOrderNumber": "WEB-2026-0884213",
  "paymentMethodType": {
    "card": { "paymentMethodId": "pm_123" }
  }
}
```

Semantics: the verb-shaped endpoint executes a payment. The response may include the transaction/attempt result and the durable `paymentRequest` aggregate identifier and state. This path implicitly creates/returns the collection aggregate and execution attempt; clients do not manage attempt creation.

For a merchant-owned order, the correlation fields can be extended without creating a duplicate Order:

```json
{
  "order_ref": "WEB-2026-0884213",
  "order_total": 32200,
  "amount": 19000,
  "currency": "USD",
  "captureMethod": "NOW"
}
```

`order_total` is declared context for a derived ledger, not a PSP Order resource.

## 4. Level 2 — PSP-managed Order and checkout

### Create Order

```http
POST /orders
Idempotency-Key: 4c1a...
```

```json
{
  "currency": "USD",
  "total_amount": 25000,
  "customer_id": "cus_123",
  "reference": "WEB-2026-0884213",
  "line_items": [
    { "reference": "sku_1", "description": "Item A", "quantity": 1, "unit_amount": 25000 }
  ]
}
```

### Create checkout binding

```http
POST /orders/{order_id}/checkout
```

```json
{
  "capture_method": "MANUAL",
  "allowed_payment_methods": ["card", "apple_pay", "google_pay"],
  "return_url": "https://merchant.example/return",
  "expires_at": "2026-11-19T23:00:00Z"
}
```

Response (illustrative):

```json
{
  "order": "ord_...",
  "payment_request": "pr_...",
  "session": "cs_...",
  "checkout_url": "https://pay.example/cs_...",
  "payment_status": "REQUIRES_INSTRUMENT"
}
```

The checkout operation wires the Order, PaymentRequest and typed Session. It does not force the client to separately create each resource for the common path.

## 5. Level 3 — explicit collection orchestration

### Create PaymentRequest

```http
POST /payment_requests
```

```json
{
  "amount": 25000,
  "currency": "USD",
  "capture_method": "MANUAL",
  "order_id": "ord_...",
  "payment_method": { "type": "card", "id": "pm_123" },
  "metadata": { "channel": "ecommerce" }
}
```

Response (illustrative):

```json
{
  "id": "pr_...",
  "state": "REQUIRES_ACTION",
  "amount": 25000,
  "currency": "USD",
  "client_secret": "pr_..._secret_...",
  "created_at": "2026-11-18T18:00:00Z"
}
```

### Bind a typed Session

```http
POST /payment_requests/{payment_request_id}/sessions
```

```json
{
  "type": "terminal",
  "terminal_id": "tm_123",
  "expires_at": "2026-11-18T18:05:00Z"
}
```

Allowed session types include `checkout`, `terminal`, `agent`, and `payment_link`. Return a type-specific identifier (`cs_`, `ts_`, `as_`, `link_`). Only one Session for a PaymentRequest may be `IN_PROGRESS` at a time. A completed or abandoned Session does not itself complete or fail the PaymentRequest.

### Confirm collection

```http
POST /payment_requests/{payment_request_id}/confirm
Idempotency-Key: 3d2b...
```

```json
{
  "payment_method": { "type": "card", "id": "pm_123" },
  "return_url": "https://merchant.example/return"
}
```

The PSP runs policy, risk, credential selection, authentication, routing, message enrichment and processor execution. Attempt/replan details remain internal; a sanitized read-only trace can be retrieved if entitled.

### Retrieve collection and decision trace

```http
GET /payment_requests/{payment_request_id}
GET /payment_requests/{payment_request_id}/attempts
GET /payment_requests/{payment_request_id}/sessions
```

Attempt collection is read-only. Do not expose `POST /attempts` as the normal managed lifecycle API.

### Capture

```http
POST /payment_requests/{payment_request_id}/captures
Idempotency-Key: 6c3e...
```

```json
{ "amount": 12000, "final_capture": false }
```

Multiple partial captures are supported when the processor/network permits. The aggregate state becomes `PARTIALLY_CAPTURED` until final/full capture, then `CAPTURED`.

### Refund

```http
POST /payment_requests/{payment_request_id}/refunds
Idempotency-Key: 7a11...
```

```json
{ "amount": 3000, "reason": "customer_return" }
```

Refunds are separate resources (`rfnd_`) and do not rewrite capture or authorization history.

## 6. Derived order ledger — read only

For merchants with their own OMS, the PSP may provide an owed-versus-collected read model:

```http
GET /ledger?order_ref=WEB-2026-0884213
```

```json
{
  "order_ref": "WEB-2026-0884213",
  "owed": 32200,
  "collected": 19000,
  "refunded": 0,
  "open": 13200,
  "tenders": [
    { "type": "card", "amount": 19000, "payment_request": "pr_..." }
  ]
}
```

There is deliberately **no POST /ledger**. The ledger is derived from payment and money-operation records. It is not an Order mirror, does not hold line items, and must never be synchronized with the merchant OMS.

## 7. Resource naming and compatibility decisions

| Concept | External name | Prefix | Rationale |
|---|---|---|---|
| Commercial contract | Order | `ord_` | Keep established commerce meaning |
| Party-level claim | Obligation | `obl_` | Supports seller/franchise/tax/platform allocations |
| Collection aggregate | PaymentRequest | `pr_` | Preserves production meaning; replaces conceptual PaymentIntent externally |
| Customer interaction | Typed Session | `cs_`, `ts_`, `as_`, `link_` | Surface binding, not a money object |
| Network execution | Attempt | `att_` | Internal/read-only execution trace |
| Capture | Capture | `cap_` | Explicit money movement operation |
| Refund | Refund | `rfnd_` | Explicit reversal operation |

The existing `POST /payments` remains the simple execution endpoint. Do not rename its attempt-level semantics to mean the durable collection aggregate; that would create a semantic collision in the production API.

## 8. Webhook/event catalogue (minimum target)

Events should be emitted from authoritative domain transitions and include stable resource IDs, `event_id`, `created_at`, `merchant_id`, `api_version`, and idempotent delivery semantics.

- `order.created`, `order.updated`, `order.fulfillment_updated`, `order.cancelled`, `order.closed`
- `payment_request.created`, `payment_request.requires_action`, `payment_request.processing`, `payment_request.authorized`, `payment_request.partially_captured`, `payment_request.captured`, `payment_request.settled`, `payment_request.failed`, `payment_request.cancelled`, `payment_request.expired`
- `session.created`, `session.active`, `session.completed`, `session.abandoned`, `session.expired`
- `capture.created`, `capture.succeeded`, `capture.failed`
- `refund.created`, `refund.succeeded`, `refund.failed`
- Optional entitled diagnostic event: `payment_request.attempt_updated` (sanitized; do not make internal replans a required merchant workflow)

## 9. API-wide rules to specify before production

- Idempotency scope, retention period, conflict behaviour and replay response.
- Optimistic concurrency / version semantics for confirm, cancel and capture races.
- Amounts in integer minor units; currency immutable per collection aggregate.
- Explicit error taxonomy: validation, policy block, authentication required, decline, connector error, timeout/unknown outcome, duplicate suppression and terminal-state conflict.
- Unknown processor outcome must be reconciled before blindly creating a new attempt; prevent duplicate authorization.
- Authentication and exemption evidence must be attached to the attempt/acquirer context actually used.
- Merchant-visible Attempt fields must be allow-listed and sanitized; no sensitive credential or issuer-only data leakage.
- API versioning, capability/entitlement checks, region/legal-entity constraints and per-connector capability validation.
- Pagination, filtering, expansion, metadata limits, webhook ordering/retry/replay and event schema compatibility.
- Exact state transition guards and allowed operations for each state must be published as a normative transition table.

## 10. Open design decisions (not silently assumed)

1. Whether `paymentRequest` remains camel-case in the existing API response while new REST resources use snake_case or a consistent house style.
2. Whether `PaymentRequest` is exposed as `/payment_requests` or nested under `/orders/{id}/payment_requests` as an alias; one canonical resource identity must be maintained.
3. Whether a PaymentRequest can be amended after authorization, and the exact rules for amount increase/decrease, incremental authorization and reauthorization.
4. How ACH/APM asynchronous states map to the canonical state model without falsely claiming authorization or capture.
5. Whether settlement is a PaymentRequest state or a linked settlement read model; preserve the distinction between capture and settlement.
6. Obligation release, reserve, clawback, tax-beneficiary and multi-currency allocation semantics.
7. The exact production fields and compatibility contract for current `POST /payments` and embedded `paymentRequest` response.

These are design/specification decisions requiring contract and connector validation; example schemas above are illustrative target shapes, not a claim that every field is already deployed.
