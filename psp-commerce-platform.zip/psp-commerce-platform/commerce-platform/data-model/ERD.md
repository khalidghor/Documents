# Entity-relationship view

The full column list is in [DATA-DICTIONARY.md](DATA-DICTIONARY.md) (generated) and the DDL in [schema.sql](schema.sql). These diagrams show the relationships that matter; columns are abbreviated.

## 1. Commerce → payments → disputes

```mermaid
erDiagram
  ACCOUNT ||--o{ ORDER : owns
  ORDER ||--o{ LINE_ITEM : has
  ORDER ||--o{ FULFILLMENT_GROUP : has
  ORDER ||--o{ TAX_LINE : has
  ORDER ||--o{ DISCOUNT : has
  ORDER ||--o{ FEE : has
  ORDER ||--o{ TIP : has
  ORDER ||--o{ ORDER_TENDER : "non-PSP tenders"
  ORDER ||--o{ RETURN : has
  ORDER ||--o{ SELLER_ORDER : "derived per seller"
  ORDER ||--o{ ORDER_VERSION : amendments
  LINE_ITEM ||--o{ LINE_MODIFIER : "nested modifiers"
  LINE_ITEM }o--|| FULFILLMENT_GROUP : "delivered by"
  LINE_ITEM }o--o| SELLER : "sold by"
  FULFILLMENT_GROUP ||--o{ SHIPMENT : has
  RETURN ||--o{ RETURN_LINE : has

  ORDER ||--o{ PAYMENT_INTENT : "collected by"
  PAYMENT_INTENT ||--o{ PAYMENT_ALLOCATION : "pays for lines"
  PAYMENT_ALLOCATION }o--|| LINE_ITEM : ""
  PAYMENT_INTENT ||--o{ INTENT_VERSION : "amendments (A1)"
  PAYMENT_INTENT ||--o{ OPERATION : instructions
  OPERATION ||--o{ OPERATION : "parent (capture→auth, refund→capture)"
  OPERATION ||--o{ OPERATION_LINE_ALLOCATION : "covers lines"
  OPERATION ||--o{ ATTEMPT : dispatches
  ATTEMPT ||--o{ EXTERNAL_REFERENCE : "NTI, ARN, trace"
  ATTEMPT ||--o| DECISION_RECORD : "decision_ref"
  PAYMENT_INTENT ||--o{ RECOVERY_CASE : "unknown outcomes"
  PAYMENT_INTENT ||--o{ RETRY_SCHEDULE : "managed retries"

  OPERATION ||--o{ DISPUTE : "capture contested"
  DISPUTE ||--o{ DISPUTE_LINE : "lines and sellers"
  DISPUTE ||--o{ EVIDENCE_ITEM : evidence
  DISPUTE ||--o{ DISPUTE_STAGE_HISTORY : stages
  PAYMENT_INTENT ||--o{ DISPUTE_ALERT : "pre-dispute"
```

## 2. Money: two ledgers and the marketplace

```mermaid
erDiagram
  LEDGER_ACCOUNT ||--o{ POSTING : ""
  JOURNAL_ENTRY ||--|{ POSTING : "balanced (deferred trigger)"
  JOURNAL_ENTRY }o--o| OPERATION : "caused by"
  JOURNAL_ENTRY }o--o| DISPUTE : "caused by"
  JOURNAL_ENTRY }o--o| LINE_ITEM : "attributed to"
  ALLOCATION ||--|{ ALLOCATION_LINE : "per line: gross, commission, tax, net"
  ALLOCATION ||--|| JOURNAL_ENTRY : "posts"
  SELLER_AGREEMENT }o--|| COMMISSION_PLAN : uses
  SELLER_AGREEMENT ||--|| ACCOUNT : "seller"
  DISPUTE_ALLOCATION_RULESET ||--o{ DISPUTE : "decided (rule, version)"
  TRANSFER }o--o| ALLOCATION : "funded by"
  PAYOUT }o--|| ACCOUNT : "to"
  RESERVE }o--|| ACCOUNT : "on"
  NEGATIVE_BALANCE_CASE }o--|| ACCOUNT : "seller"
  RECONCILIATION_RUN }o--|| ACCOUNT : "platform book"
```

`ledger.account.ledger` is `acquiring` (book = PSP legal entity, "where is the money") or `commerce` (book = platform account, "who owes whom"). Both share one append-only double-entry engine; the reconciliation run checks the control invariant every day.

## 3. Identity, credentials, intelligence, configuration

```mermaid
erDiagram
  LEGAL_ENTITY ||--o{ ACCOUNT : ""
  ACCOUNT ||--o{ ACCOUNT : "parent (platform→merchant→seller)"
  ACCOUNT ||--o{ MERCHANT_ACCOUNT_REF : "MIDs per acquirer"
  ACCOUNT ||--o{ LOCATION : ""
  LOCATION ||--o{ TERMINAL : ""
  ACCOUNT ||--o{ API_KEY : ""
  ACCOUNT ||--o{ ACCESS_GRANT : "On-Behalf-Of"
  ACCOUNT ||--o{ CUSTOMER : ""
  CUSTOMER ||--o{ PAYMENT_METHOD : "vault references only"
  PAYMENT_METHOD ||--o{ MANDATE : "versioned"
  PAYMENT_METHOD ||--o{ CREDENTIAL_REGISTRATION : "funds & lifecycle signals"
  CREDENTIAL_REGISTRATION ||--o{ REGISTRATION_PROGRAMME : ""
  CREDENTIAL_REGISTRATION ||--o{ FUNDS_SIGNAL : ""
  BIN_RANGE }o--o| ISSUER : ""
  CREDENTIAL_INSIGHT }o--|| ACCOUNT : "requested by"
  CREDENTIAL_SIGNAL }o--|| PAYMENT_METHOD : "by fingerprint"
  RETRY_COUNTER }o--|| ACCOUNT : "per credential per network"
  CONFIG_DOCUMENT }o--o| ACCOUNT : "scope + authority"
  ENTITLEMENT }o--|| ACCOUNT : "capability × scope"
```

## 4. Where each state model is stored

| State model | Table / column |
|---|---|
| Commerce | `commerce.order.status`, `.fulfillment_status`, `commerce.line_item.status`, `commerce.fulfillment_group.status` |
| Payment (ten states) | `payments.payment_intent.status` (+ `internal_state`, never serialized) |
| Operation / attempt | `payments.operation.status`, `payments.attempt.outcome` |
| Rail | `payments.attempt.rail_state` |
| Financial | `ledger.*` (authoritative); projections in `payment_intent.funds_status`, `finality_status` |
