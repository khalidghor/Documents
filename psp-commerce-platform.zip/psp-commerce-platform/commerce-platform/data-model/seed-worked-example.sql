-- Worked example from docs/08 §4, posted into both ledgers, then the control invariant is checked.
-- Load after schema.sql:  psql -d psp -f schema.sql -f seed-worked-example.sql
BEGIN;

-- Acquiring ledger accounts (book = PSP legal entity le_psp_us)
INSERT INTO ledger.account (id, ledger, book, party, purpose, currency, normal_balance) VALUES
 ('acq:scheme_receivable',        'acquiring','le_psp_us','psp','scheme_receivable','USD','debit'),
 ('acq:settlement_cash',          'acquiring','le_psp_us','psp','settlement_cash','USD','debit'),
 ('acq:merchant_payable:MarketCo','acquiring','le_psp_us','merchant:acct_MarketCo','merchant_payable','USD','credit'),
 ('acq:psp_fee_revenue',          'acquiring','le_psp_us','psp','psp_fee_revenue','USD','credit'),
 ('acq:dispute_fee_revenue',      'acquiring','le_psp_us','psp','dispute_fee_revenue','USD','credit');

-- Commerce ledger accounts (book = platform account acct_MarketCo)
INSERT INTO ledger.account (id, ledger, book, party, purpose, currency, normal_balance) VALUES
 ('com:psp_receivable',      'commerce','acct_MarketCo','platform','psp_receivable','USD','debit'),
 ('com:seller:A:pending',    'commerce','acct_MarketCo','seller:sel_A','pending','USD','credit'),
 ('com:seller:B:pending',    'commerce','acct_MarketCo','seller:sel_B','pending','USD','credit'),
 ('com:commission_revenue',  'commerce','acct_MarketCo','platform','commission_revenue','USD','credit'),
 ('com:processing_fee_exp',  'commerce','acct_MarketCo','platform','processing_fee_expense','USD','debit'),
 ('com:tax:US-XX:mf',        'commerce','acct_MarketCo','tax:US-XX','tax_payable','USD','credit');

-- helper: one journal entry with postings
CREATE TEMP TABLE je (id text, ledger text, event text, src text, lines jsonb);
INSERT INTO je VALUES
 -- capture 1 ($70.00) + fee ($2.33)
 ('je_a1','acquiring','capture.succeeded','op_2','[["acq:scheme_receivable","debit",7000],["acq:merchant_payable:MarketCo","credit",7000]]'),
 ('je_a2','acquiring','fee.assessed','op_2','[["acq:merchant_payable:MarketCo","debit",233],["acq:psp_fee_revenue","credit",233]]'),
 ('je_c1','commerce','capture.succeeded','op_2','[["com:psp_receivable","debit",7000],["com:seller:A:pending","credit",5500],["com:commission_revenue","credit",900],["com:tax:US-XX:mf","credit",600]]'),
 ('je_c2','commerce','fee.assessed','op_2','[["com:processing_fee_exp","debit",233],["com:psp_receivable","credit",233]]'),
 -- capture 2 ($48.00) + fee ($1.69)
 ('je_a3','acquiring','capture.succeeded','op_5','[["acq:scheme_receivable","debit",4800],["acq:merchant_payable:MarketCo","credit",4800]]'),
 ('je_a4','acquiring','fee.assessed','op_5','[["acq:merchant_payable:MarketCo","debit",169],["acq:psp_fee_revenue","credit",169]]'),
 ('je_c3','commerce','capture.succeeded','op_5','[["com:psp_receivable","debit",4800],["com:seller:B:pending","credit",3800],["com:commission_revenue","credit",600],["com:tax:US-XX:mf","credit",400]]'),
 ('je_c4','commerce','fee.assessed','op_5','[["com:processing_fee_exp","debit",169],["com:psp_receivable","credit",169]]'),
 -- refund li_2 ($44.00; admin fee 1.20 retained)
 ('je_a5','acquiring','refund.succeeded','op_6','[["acq:merchant_payable:MarketCo","debit",4400],["acq:scheme_receivable","credit",4400]]'),
 ('je_c5','commerce','refund.succeeded','op_6','[["com:seller:B:pending","debit",3520],["com:commission_revenue","debit",480],["com:tax:US-XX:mf","debit",400],["com:psp_receivable","credit",4400]]'),
 -- dispute lost on capture 1 ($70.00 + $15.00 fee), seller A liable, commission retained, tax reversed
 ('je_a6','acquiring','dispute.funds_withdrawn','dp_1','[["acq:merchant_payable:MarketCo","debit",7000],["acq:settlement_cash","credit",7000]]'),
 ('je_a7','acquiring','dispute.fee','dp_1','[["acq:merchant_payable:MarketCo","debit",1500],["acq:dispute_fee_revenue","credit",1500]]'),
 ('je_c6','commerce','dispute.lost','dp_1','[["com:seller:A:pending","debit",6400],["com:tax:US-XX:mf","debit",600],["com:seller:A:pending","debit",1500],["com:psp_receivable","credit",8500]]');

INSERT INTO ledger.journal_entry (id, ledger, book, currency, event_type, source_event_id, effective_at)
SELECT id, ledger, CASE ledger WHEN 'acquiring' THEN 'le_psp_us' ELSE 'acct_MarketCo' END, 'USD', event, src, now() FROM je;

INSERT INTO ledger.posting (journal_entry_id, line_no, account_id, direction, amount)
SELECT je.id, l.ord::smallint, l.v->>0, l.v->>1, (l.v->>2)::bigint
FROM je, jsonb_array_elements(je.lines) WITH ORDINALITY AS l(v, ord);

COMMIT;  -- the deferred trigger rejects the whole transaction if any entry is unbalanced

-- The control invariant (docs/08 §3.3): acquiring merchant payable = commerce psp_receivable
SELECT
  (SELECT balance FROM ledger.account_balance WHERE account_id = 'acq:merchant_payable:MarketCo') AS acquiring_merchant_payable,
  (SELECT balance FROM ledger.account_balance WHERE account_id = 'com:psp_receivable')            AS commerce_psp_receivable;

SELECT account_id, balance FROM ledger.account_balance WHERE ledger = 'commerce' ORDER BY account_id;
