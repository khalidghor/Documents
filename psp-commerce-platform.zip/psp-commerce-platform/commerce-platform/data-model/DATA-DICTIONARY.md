# Data dictionary

Generated from `schema.sql` by `scripts/gen_data_dictionary.py`. Do not edit by hand.

82 tables and views across 12 schemas.

## `tenancy`

### `tenancy.access_grant`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `grantor_account_id` | text | NOT NULL | tenancy.account |  |
| `grantee_account_id` | text | NOT NULL | tenancy.account |  |
| `scopes` | text[] | NOT NULL |  |  |
| `expires_at` | timestamp with time zone |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `tenancy.account`

The authority ladder below the PSP: platform → payfac → merchant → sub-merchant/seller. Every business row is owned by an account.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `type` | text | NOT NULL |  |  |
| `parent_account_id` | text |  | tenancy.account |  |
| `legal_entity_id` | text | NOT NULL | tenancy.legal_entity |  |
| `psp_legal_entity_id` | text | NOT NULL | tenancy.legal_entity |  |
| `entitlement_pattern` | text | NOT NULL |  |  |
| `default_currency` | character(3) | NOT NULL |  |  |
| `mcc` | character(4) |  |  |  |
| `descriptor` | text |  |  |  |
| `industry_profile` | text |  |  |  |
| `fund_flow` | text |  |  |  |
| `api_version` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `tenancy.api_key`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `mode` | text | NOT NULL |  |  |
| `kind` | text | NOT NULL |  |  |
| `scopes` | text[] | NOT NULL |  |  |
| `hashed_secret` | bytea | NOT NULL |  |  |
| `disclosure_tier` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `revoked_at` | timestamp with time zone |  |  |  |

### `tenancy.legal_entity`

Legal entities: the PSP's own entities (books of the acquiring ledger), platforms, merchants, sellers.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `name` | text | NOT NULL |  |  |
| `country` | character(2) | NOT NULL |  |  |
| `role` | text | NOT NULL |  |  |
| `tax_ids` | jsonb | NOT NULL |  |  |
| `address` | jsonb |  |  |  |
| `kyb_status` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `tenancy.location`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `name` | text | NOT NULL |  |  |
| `type` | text | NOT NULL |  |  |
| `address` | jsonb |  |  |  |
| `timezone` | text | NOT NULL |  |  |
| `tax_jurisdiction` | text |  |  |  |
| `attributes` | jsonb | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `tenancy.merchant_account_ref`

MIDs at each acquirer; the attempt records which one was used.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `acquirer` | text | NOT NULL |  |  |
| `mid` | text | NOT NULL |  |  |
| `mcc` | character(4) | NOT NULL |  |  |
| `country` | character(2) | NOT NULL |  |  |
| `currencies` | character(3)[] | NOT NULL |  |  |
| `capabilities` | jsonb | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |

### `tenancy.terminal`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `location_id` | text | NOT NULL | tenancy.location |  |
| `serial` | text | NOT NULL |  |  |
| `model` | text |  |  |  |
| `offline_floor_limit` | bigint | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |

## `catalog`

### `catalog.modifier`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `modifier_group_id` | text | NOT NULL | catalog.modifier_group |  |
| `name` | text | NOT NULL |  |  |
| `price` | bigint | NOT NULL |  |  |
| `tax_code` | text |  |  |  |
| `child_group_ids` | text[] | NOT NULL |  |  |

### `catalog.modifier_group`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `name` | text | NOT NULL |  |  |
| `min_select` | integer | NOT NULL |  |  |
| `max_select` | integer |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `catalog.price`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `price_book_id` | text | NOT NULL | catalog.price_book |  |
| `variant_id` | text | NOT NULL | catalog.variant |  |
| `unit_amount` | bigint | NOT NULL |  |  |

### `catalog.price_book`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `name` | text | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `scope` | jsonb | NOT NULL |  |  |
| `tax_inclusive` | boolean | NOT NULL |  |  |
| `valid_from` | timestamp with time zone |  |  |  |
| `valid_to` | timestamp with time zone |  |  |  |

### `catalog.product`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `seller_account_id` | text |  | tenancy.account |  |
| `name` | text | NOT NULL |  |  |
| `description` | text |  |  |  |
| `type` | text | NOT NULL |  |  |
| `tax_code` | text |  |  |  |
| `attributes` | jsonb | NOT NULL |  |  |
| `availability` | jsonb | NOT NULL |  |  |
| `version` | integer | NOT NULL |  |  |
| `active` | boolean | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `catalog.product_modifier_group`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `product_id` | text | NOT NULL | catalog.product |  |
| `modifier_group_id` | text | NOT NULL | catalog.modifier_group |  |
| `position` | integer | NOT NULL |  |  |

### `catalog.variant`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `product_id` | text | NOT NULL | catalog.product |  |
| `sku` | text | NOT NULL |  |  |
| `gtin` | text |  |  |  |
| `options` | jsonb | NOT NULL |  |  |
| `inventory_policy` | text | NOT NULL |  |  |

## `customer`

### `customer.customer`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `consent_holder_id` | text | NOT NULL |  |  |
| `email` | text |  |  |  |
| `phone` | text |  |  |  |
| `name` | text |  |  |  |
| `addresses` | jsonb | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `customer.mandate`

Versioned mandates; compare-and-set on version; terminal states never reopen (PD-003 §17).

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `version` | integer | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `payment_method_id` | text |  | customer.payment_method |  |
| `type` | text | NOT NULL |  |  |
| `scope` | jsonb | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `valid_from` | timestamp with time zone | NOT NULL |  |  |
| `valid_to` | timestamp with time zone |  |  |  |
| `headroom_remaining` | bigint |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `customer.payment_method`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `customer_id` | text |  | customer.customer |  |
| `type` | text | NOT NULL |  |  |
| `credential_ref` | text | NOT NULL |  |  |
| `fingerprint` | text | NOT NULL |  |  |
| `display` | jsonb | NOT NULL |  |  |
| `bin8` | character(8) |  |  |  |
| `status` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

## `commerce`

### `commerce.bundle_component`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `line_item_id` | text | NOT NULL | commerce.line_item |  |
| `sku` | text | NOT NULL |  |  |
| `name` | text |  |  |  |
| `quantity` | numeric(18,6) | NOT NULL |  |  |
| `allocated_price` | bigint | NOT NULL |  |  |

### `commerce.discount`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `line_item_id` | text |  | commerce.line_item |  |
| `code` | text |  |  |  |
| `type` | text | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `funded_by` | text | NOT NULL |  |  |
| `funding_split` | jsonb |  |  |  |

### `commerce.fee`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `type` | text | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `payee` | text | NOT NULL |  |  |
| `taxable` | boolean | NOT NULL |  |  |

### `commerce.fulfillment_group`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `method` | text | NOT NULL |  |  |
| `fulfilled_by` | text | NOT NULL |  |  |
| `seller_account_id` | text |  | tenancy.account |  |
| `location_id` | text |  | tenancy.location |  |
| `ship_to` | jsonb |  |  |  |
| `recipient` | jsonb |  |  |  |
| `promised_at` | timestamp with time zone |  |  |  |
| `promised_window` | tstzrange |  |  |  |
| `capture_trigger` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `commerce.line_item`

One sellable thing at one price; carries seller, fulfillment group and quantities that bound refunds.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `position` | integer | NOT NULL |  |  |
| `type` | text | NOT NULL |  |  |
| `product_id` | text |  | catalog.product |  |
| `variant_id` | text |  | catalog.variant |  |
| `sku` | text |  |  |  |
| `catalog_version` | integer |  |  |  |
| `name` | text | NOT NULL |  |  |
| `quantity` | numeric(18,6) | NOT NULL |  |  |
| `unit_of_measure` | text | NOT NULL |  |  |
| `unit_price` | bigint | NOT NULL |  |  |
| `tax_code` | text |  |  |  |
| `seller_account_id` | text |  | tenancy.account |  |
| `fulfillment_group_id` | text |  | commerce.fulfillment_group |  |
| `attributes` | jsonb | NOT NULL |  |  |
| `qty_allocated` | numeric(18,6) | NOT NULL |  |  |
| `qty_fulfilled` | numeric(18,6) | NOT NULL |  |  |
| `qty_canceled` | numeric(18,6) | NOT NULL |  |  |
| `qty_returned` | numeric(18,6) | NOT NULL |  |  |
| `qty_refunded` | numeric(18,6) | NOT NULL |  |  |
| `amount_subtotal` | bigint | NOT NULL |  |  |
| `amount_discount` | bigint | NOT NULL |  |  |
| `amount_tax` | bigint | NOT NULL |  |  |
| `amount_total` | bigint | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `metadata` | jsonb | NOT NULL |  |  |

### `commerce.line_modifier`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `line_item_id` | text | NOT NULL | commerce.line_item |  |
| `parent_modifier_id` | text |  | commerce.line_modifier |  |
| `modifier_id` | text |  |  |  |
| `name` | text | NOT NULL |  |  |
| `quantity` | numeric(18,6) | NOT NULL |  |  |
| `unit_price` | bigint | NOT NULL |  |  |
| `tax_code` | text |  |  |  |

### `commerce.order`

The commercial transaction. Five status fields, each a different question (docs/02 §3).

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `platform_account_id` | text |  | tenancy.account |  |
| `version` | integer | NOT NULL |  |  |
| `livemode` | boolean | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `payment_status` | text | NOT NULL |  |  |
| `fulfillment_status` | text | NOT NULL |  |  |
| `settlement_status` | text | NOT NULL |  |  |
| `dispute_status` | text | NOT NULL |  |  |
| `industry_profile` | text |  |  |  |
| `channel` | jsonb | NOT NULL |  |  |
| `location_id` | text |  | tenancy.location |  |
| `customer_id` | text |  | customer.customer |  |
| `customer_snapshot` | jsonb |  |  |  |
| `buyer_agent` | jsonb |  |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `collection_plan` | jsonb | NOT NULL |  |  |
| `subtotal` | bigint | NOT NULL |  |  |
| `discount_total` | bigint | NOT NULL |  |  |
| `tax_total` | bigint | NOT NULL |  |  |
| `fee_total` | bigint | NOT NULL |  |  |
| `tip_total` | bigint | NOT NULL |  |  |
| `shipping_total` | bigint | NOT NULL |  |  |
| `total` | bigint | NOT NULL |  |  |
| `canceled_total` | bigint | NOT NULL |  |  |
| `amount_authorized` | bigint | NOT NULL |  |  |
| `amount_collected` | bigint | NOT NULL |  |  |
| `amount_refunded` | bigint | NOT NULL |  |  |
| `amount_disputed` | bigint | NOT NULL |  |  |
| `amount_charged_back` | bigint | NOT NULL |  |  |
| `hold_reason` | text |  |  |  |
| `pending_expires_at` | timestamp with time zone |  |  |  |
| `dispute_window_closes_at` | timestamp with time zone |  |  |  |
| `cancellation_reason` | text |  |  |  |
| `placed_at` | timestamp with time zone |  |  |  |
| `completed_at` | timestamp with time zone |  |  |  |
| `closed_at` | timestamp with time zone |  |  |  |
| `canceled_at` | timestamp with time zone |  |  |  |
| `external_references` | jsonb | NOT NULL |  |  |
| `metadata` | jsonb | NOT NULL |  |  |
| `test_clock_id` | text |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `commerce.order_tender`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `type` | text | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `reference` | text |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `commerce.order_timeline`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | bigint | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `at` | timestamp with time zone | NOT NULL |  |  |
| `type` | text | NOT NULL |  |  |
| `summary` | text |  |  |  |
| `actor` | text | NOT NULL |  |  |
| `cause_event_id` | text |  |  |  |
| `cause_object` | text |  |  |  |

### `commerce.order_version`

Amendment history; an order is never edited without a version and a reason.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `order_id` | text | NOT NULL | commerce.order |  |
| `version` | integer | NOT NULL |  |  |
| `reason` | text | NOT NULL |  |  |
| `actor` | text | NOT NULL |  |  |
| `diff` | jsonb | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `commerce.return`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `status` | text | NOT NULL |  |  |
| `refund_destination` | text | NOT NULL |  |  |
| `refund_on` | text | NOT NULL |  |  |
| `refund_amount` | bigint |  |  |  |
| `restocking_fee` | bigint | NOT NULL |  |  |
| `include_shipping` | boolean | NOT NULL |  |  |
| `refund_status` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `commerce.return_line`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `return_id` | text | NOT NULL | commerce.return |  |
| `line_item_id` | text | NOT NULL | commerce.line_item |  |
| `quantity` | numeric(18,6) | NOT NULL |  |  |
| `reason` | text | NOT NULL |  |  |
| `condition` | text |  |  |  |
| `disposition` | text |  |  |  |

### `commerce.seller_order`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `seller_account_id` | text | NOT NULL | tenancy.account |  |
| `merchant_of_record` | text | NOT NULL |  |  |
| `tax_liability` | text | NOT NULL |  |  |
| `subtotal` | bigint | NOT NULL |  |  |
| `commission` | bigint | NOT NULL |  |  |
| `fees` | bigint | NOT NULL |  |  |
| `net_to_seller` | bigint | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `payout_status` | text | NOT NULL |  |  |

### `commerce.shipment`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `fulfillment_group_id` | text | NOT NULL | commerce.fulfillment_group |  |
| `carrier` | text |  |  |  |
| `service` | text |  |  |  |
| `tracking_number` | text |  |  |  |
| `shipped_at` | timestamp with time zone |  |  |  |
| `delivered_at` | timestamp with time zone |  |  |  |
| `proof_of_delivery` | jsonb |  |  |  |
| `lines` | jsonb | NOT NULL |  |  |

### `commerce.tax_line`

Per line, per jurisdiction tax with the liable party; drives the commerce ledger tax accounts.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `line_item_id` | text |  | commerce.line_item |  |
| `fee_id` | text |  | commerce.fee |  |
| `jurisdiction` | text | NOT NULL |  |  |
| `tax_type` | text | NOT NULL |  |  |
| `rate` | numeric(9,6) | NOT NULL |  |  |
| `taxable_amount` | bigint | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `inclusive` | boolean | NOT NULL |  |  |
| `liable_party` | text | NOT NULL |  |  |
| `collected_by` | text | NOT NULL |  |  |
| `remitted_by` | text | NOT NULL |  |  |
| `rule_ref` | text |  |  |  |
| `engine_ref` | text |  |  |  |

### `commerce.tip`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `amount` | bigint | NOT NULL |  |  |
| `recipient` | text | NOT NULL |  |  |
| `recipient_id` | text |  |  |  |
| `added_at` | text | NOT NULL |  |  |

## `payments`

### `payments.attempt`

One dispatch to one acquirer or rail. Written only by the platform; carries exec_id, plan_version, decision_ref.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `operation_id` | text | NOT NULL | payments.operation |  |
| `payment_intent_id` | text | NOT NULL | payments.payment_intent |  |
| `sequence` | integer | NOT NULL |  |  |
| `origin` | text | NOT NULL |  |  |
| `rail` | text | NOT NULL |  |  |
| `acquirer` | text |  |  |  |
| `merchant_account_ref_id` | text |  | tenancy.merchant_account_ref |  |
| `credential_type` | text |  |  |  |
| `credential_ref` | text |  |  |  |
| `authentication` | jsonb |  |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `amount_approved` | bigint |  |  |  |
| `outcome` | text | NOT NULL |  |  |
| `result` | jsonb |  |  |  |
| `rail_state` | text |  |  |  |
| `exec_id` | text | NOT NULL |  |  |
| `plan_version` | integer | NOT NULL |  |  |
| `decision_ref` | text |  |  |  |
| `dispatched_at` | timestamp with time zone |  |  |  |
| `responded_at` | timestamp with time zone |  |  |  |
| `platform_latency_ms` | integer |  |  |  |
| `network_latency_ms` | integer |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `payments.decision_record`

PD-002 decision records: propensity, fallback counterfactual and rejected options are mandatory.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `attempt_id` | text |  | payments.attempt |  |
| `decision_point` | text | NOT NULL |  |  |
| `chosen` | jsonb | NOT NULL |  |  |
| `propensity` | numeric(8,6) | NOT NULL |  |  |
| `fallback` | jsonb | NOT NULL |  |  |
| `rejected` | jsonb | NOT NULL |  |  |
| `experiment_assignment` | jsonb |  |  |  |
| `exec_id` | text | NOT NULL |  |  |
| `plan_version` | integer | NOT NULL |  |  |
| `policy_set_version` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `payments.external_reference`

Network transaction ids, ARNs, ACH traces, BNPL ids — typed and scoped, never primary keys. Used to match disputes and alerts.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | bigint | NOT NULL |  |  |
| `attempt_id` | text |  | payments.attempt |  |
| `operation_id` | text |  | payments.operation |  |
| `type` | text | NOT NULL |  |  |
| `value` | text | NOT NULL |  |  |
| `scope` | text | NOT NULL |  |  |

### `payments.intent_version`

A1: intent is immutable; amendments create versions. Execution never edits these rows.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `payment_intent_id` | text | NOT NULL | payments.payment_intent |  |
| `version` | integer | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `payment_method_id` | text |  |  |  |
| `mandate` | text |  |  |  |
| `reason` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `payments.operation`

One instruction (authorize, capture, refund…). Carries the idempotency key; every retry shares it. Append-only.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `payment_intent_id` | text | NOT NULL | payments.payment_intent |  |
| `intent_version` | integer | NOT NULL |  |  |
| `type` | text | NOT NULL |  |  |
| `parent_operation_id` | text |  | payments.operation |  |
| `amount` | bigint | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `idempotency_key` | text | NOT NULL |  |  |
| `request_hash` | bytea | NOT NULL |  |  |
| `initiated_by` | text | NOT NULL |  |  |
| `reason` | text |  |  |  |
| `capture_sequence` | integer |  |  |  |
| `final_capture` | boolean |  |  |  |
| `fulfillment_group_id` | text |  | commerce.fulfillment_group |  |
| `refund_reason` | text |  |  |  |
| `refund_capture_operation_id` | text |  | payments.operation |  |
| `return_id` | text |  | commerce.return |  |
| `refund_destination` | text |  |  |  |
| `dispute_alert_id` | text |  |  |  |
| `fallback_required` | boolean | NOT NULL |  |  |
| `reauth_mode` | text |  |  |  |
| `supersedes_operation_id` | text |  | payments.operation |  |
| `auth_expires_at` | timestamp with time zone |  |  |  |
| `auth_status` | text |  |  |  |
| `network_transaction_id` | text |  |  |  |
| `result` | jsonb |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `completed_at` | timestamp with time zone |  |  |  |

### `payments.operation_line_allocation`

Which lines a capture or refund covers; the basis of marketplace allocation for that money.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `operation_id` | text | NOT NULL | payments.operation |  |
| `order_line_id` | text | NOT NULL | commerce.line_item |  |
| `quantity` | numeric(18,6) |  |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `tax` | bigint | NOT NULL |  |  |

### `payments.payment_allocation`

Which order lines (and so which sellers and tax lines) each Payment Intent pays for.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `payment_intent_id` | text | NOT NULL | payments.payment_intent |  |
| `order_line_id` | text | NOT NULL | commerce.line_item |  |
| `seller_account_id` | text |  | tenancy.account |  |
| `amount` | bigint | NOT NULL |  |  |
| `application_fee` | bigint | NOT NULL |  |  |

### `payments.payment_intent`

Durable obligation to collect; ten external states; authorization, finality and funds blocks (docs/03).

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `livemode` | boolean | NOT NULL |  |  |
| `intent_version` | integer | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `internal_state` | text | NOT NULL |  | Internal state machine value (PD-001 §14 + AUTHORIZATION_EXPIRING, REAUTHORIZATION_IN_FLIGHT, RETRY_SCHEDULED, CAPTURE_PENDING_SETTLEMENT_CHECK). |
| `status_before_dispute` | text |  |  |  |
| `order_id` | text |  | commerce.order |  |
| `order_reference` | text |  |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `amount_details` | jsonb | NOT NULL |  |  |
| `payment_method_id` | text |  | customer.payment_method |  |
| `method_type` | text |  |  |  |
| `capture_method` | text | NOT NULL |  |  |
| `authorization_type` | text | NOT NULL |  |  |
| `mandate_id` | text |  |  |  |
| `mandate_version` | integer |  |  |  |
| `session_id` | text |  |  |  |
| `customer_id` | text |  | customer.customer |  |
| `on_behalf_of` | text |  | tenancy.account |  |
| `stored_credential` | jsonb |  |  |  |
| `channel` | jsonb |  |  |  |
| `auth_status` | text | NOT NULL |  |  |
| `amount_authorized` | bigint | NOT NULL |  |  |
| `amount_capturable` | bigint | NOT NULL |  |  |
| `authorized_at` | timestamp with time zone |  |  |  |
| `auth_expires_at` | timestamp with time zone |  |  |  |
| `auth_expiry_basis` | text |  |  |  |
| `reauthorization_count` | integer | NOT NULL |  |  |
| `current_auth_operation_id` | text |  |  |  |
| `amount_captured` | bigint | NOT NULL |  |  |
| `amount_refunded` | bigint | NOT NULL |  |  |
| `amount_reversed` | bigint | NOT NULL |  |  |
| `amount_disputed` | bigint | NOT NULL |  |  |
| `amount_charged_back` | bigint | NOT NULL |  |  |
| `capture_count` | integer | NOT NULL |  |  |
| `final_capture_received` | boolean | NOT NULL |  |  |
| `finality_status` | text | NOT NULL |  |  |
| `final_at` | timestamp with time zone |  |  |  |
| `reversible_until` | timestamp with time zone |  |  |  |
| `funds_status` | text | NOT NULL |  |  |
| `settlement_date` | date |  |  |  |
| `available_on` | date |  |  |  |
| `last_result` | jsonb |  |  |  |
| `next_action` | jsonb |  |  |  |
| `policies` | jsonb | NOT NULL |  |  |
| `cancellation_reason` | text |  |  |  |
| `retry_window_ends_at` | timestamp with time zone |  |  |  |
| `latest_exec_id` | text |  |  |  |
| `latest_plan_version` | integer |  |  |  |
| `metadata` | jsonb | NOT NULL |  |  |
| `test_clock_id` | text |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `payments.recovery_case`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `payment_intent_id` | text | NOT NULL | payments.payment_intent |  |
| `attempt_id` | text |  | payments.attempt |  |
| `kind` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `opened_at` | timestamp with time zone | NOT NULL |  |  |
| `closed_at` | timestamp with time zone |  |  |  |

### `payments.retry_schedule`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `payment_intent_id` | text | NOT NULL | payments.payment_intent |  |
| `at` | timestamp with time zone | NOT NULL |  |  |
| `basis` | text | NOT NULL |  |  |
| `funds_signal_id` | text |  |  |  |
| `status` | text | NOT NULL |  |  |

## `disputes`

### `disputes.dispute`

Contested money, linked to the exact capture; marketplace allocation recorded with rule and ruleset version.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `payment_intent_id` | text | NOT NULL | payments.payment_intent |  |
| `operation_id` | text | NOT NULL | payments.operation |  |
| `order_id` | text |  | commerce.order |  |
| `network` | text | NOT NULL |  |  |
| `network_flow` | text | NOT NULL |  |  |
| `reason_code` | text | NOT NULL |  |  |
| `reason_category` | text | NOT NULL |  |  |
| `stage` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `funds_withdrawn` | bigint | NOT NULL |  |  |
| `fee` | bigint | NOT NULL |  |  |
| `funds_reinstated` | bigint | NOT NULL |  |  |
| `evidence_due_by` | timestamp with time zone |  |  |  |
| `liability` | jsonb | NOT NULL |  |  |
| `allocation_rule_id` | text |  |  |  |
| `allocation_ruleset_version` | integer |  |  |  |
| `liable_party` | text |  |  |  |
| `liable_seller_account_id` | text |  | tenancy.account |  |
| `responder` | text |  |  |  |
| `fee_bearer` | text |  |  |  |
| `hold_applied` | bigint | NOT NULL |  |  |
| `win_likelihood` | jsonb |  |  |  |
| `network_case_id` | text |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `disputes.dispute_alert`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `source` | text | NOT NULL |  |  |
| `type` | text | NOT NULL |  |  |
| `payment_intent_id` | text |  | payments.payment_intent |  |
| `operation_id` | text |  | payments.operation |  |
| `match_confidence` | text | NOT NULL |  |  |
| `amount` | bigint |  |  |  |
| `currency` | character(3) |  |  |  |
| `reason_category` | text |  |  |  |
| `status` | text | NOT NULL |  |  |
| `respond_by` | timestamp with time zone |  |  |  |
| `recommended_action` | jsonb |  |  |  |
| `resolution` | jsonb |  |  |  |
| `external_id` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `disputes.dispute_line`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `dispute_id` | text | NOT NULL | disputes.dispute |  |
| `order_line_id` | text | NOT NULL | commerce.line_item |  |
| `amount` | bigint | NOT NULL |  |  |
| `seller_account_id` | text |  | tenancy.account |  |
| `share_amount` | bigint |  |  |  |

### `disputes.dispute_stage_history`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | bigint | NOT NULL |  |  |
| `dispute_id` | text | NOT NULL | disputes.dispute |  |
| `stage` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `at` | timestamp with time zone | NOT NULL |  |  |
| `note` | text |  |  |  |

### `disputes.evidence_item`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `dispute_id` | text | NOT NULL | disputes.dispute |  |
| `type` | text | NOT NULL |  |  |
| `source` | text | NOT NULL |  |  |
| `auto_assembled` | boolean | NOT NULL |  |  |
| `file_id` | text |  |  |  |
| `text` | text |  |  |  |
| `data` | jsonb |  |  |  |
| `submitted_at` | timestamp with time zone |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

## `ledger`

### `ledger.account`

Accounts of the acquiring ledger (where the money is) and the commerce ledger (who owes whom).

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `ledger` | text | NOT NULL |  |  |
| `book` | text | NOT NULL |  |  |
| `party` | text | NOT NULL |  |  |
| `purpose` | text | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `normal_balance` | text | NOT NULL |  |  |
| `attributes` | jsonb | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `ledger.account_balance`

Balances in each account's normal direction. Production uses incrementally maintained balances; this view is the definition.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `account_id` | text |  |  |  |
| `ledger` | text |  |  |  |
| `book` | text |  |  |  |
| `party` | text |  |  |  |
| `purpose` | text |  |  |  |
| `currency` | character(3) |  |  |  |
| `balance` | numeric |  |  |  |

### `ledger.journal_entry`

Append-only. Derived from the payment/commerce journal; never written by API handlers directly.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `ledger` | text | NOT NULL |  |  |
| `book` | text | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `event_type` | text | NOT NULL |  |  |
| `source_event_id` | text | NOT NULL |  |  |
| `order_id` | text |  |  |  |
| `order_line_id` | text |  |  |  |
| `payment_intent_id` | text |  |  |  |
| `operation_id` | text |  |  |  |
| `attempt_id` | text |  |  |  |
| `dispute_id` | text |  |  |  |
| `seller_account_id` | text |  |  |  |
| `rule_ref` | text |  |  |  |
| `effective_at` | timestamp with time zone | NOT NULL |  |  |
| `recorded_at` | timestamp with time zone | NOT NULL |  |  |

### `ledger.posting`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `journal_entry_id` | text | NOT NULL | ledger.journal_entry |  |
| `line_no` | smallint | NOT NULL |  |  |
| `account_id` | text | NOT NULL | ledger.account |  |
| `direction` | text | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |

### `ledger.reconciliation_run`

Control invariant: acquiring merchant_payable(platform) = Σ commerce ledger balances. Breaks open cases; never plugged.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `book` | text | NOT NULL |  |  |
| `as_of` | timestamp with time zone | NOT NULL |  |  |
| `acquiring_merchant_payable` | bigint | NOT NULL |  |  |
| `commerce_control_total` | bigint | NOT NULL |  |  |
| `difference` | bigint |  |  |  |
| `status` | text | NOT NULL |  |  |
| `case_id` | text |  |  |  |

## `marketplace`

### `marketplace.allocation`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `platform_account_id` | text | NOT NULL | tenancy.account |  |
| `source_type` | text | NOT NULL |  |  |
| `source_id` | text | NOT NULL |  |  |
| `order_id` | text |  | commerce.order |  |
| `payment_intent_id` | text |  | payments.payment_intent |  |
| `journal_entry_id` | text |  | ledger.journal_entry |  |
| `rule_refs` | text[] | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `marketplace.allocation_line`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `allocation_id` | text | NOT NULL | marketplace.allocation |  |
| `order_line_id` | text | NOT NULL | commerce.line_item |  |
| `seller_account_id` | text |  | tenancy.account |  |
| `gross` | bigint | NOT NULL |  |  |
| `commission` | bigint | NOT NULL |  |  |
| `tax` | bigint | NOT NULL |  |  |
| `tax_liable_party` | text |  |  |  |
| `net_to_seller` | bigint | NOT NULL |  |  |

### `marketplace.commission_plan`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `platform_account_id` | text | NOT NULL | tenancy.account |  |
| `name` | text | NOT NULL |  |  |
| `rules` | jsonb | NOT NULL |  |  |
| `version` | integer | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `marketplace.dispute_allocation_ruleset`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `version` | integer | NOT NULL |  |  |
| `platform_account_id` | text | NOT NULL | tenancy.account |  |
| `status` | text | NOT NULL |  |  |
| `rules` | jsonb | NOT NULL |  |  |
| `recovery_waterfall` | text[] | NOT NULL |  |  |
| `signature` | text |  |  |  |
| `published_at` | timestamp with time zone |  |  |  |

### `marketplace.negative_balance_case`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `seller_account_id` | text | NOT NULL | tenancy.account |  |
| `amount` | bigint | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `waterfall_step` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `opened_at` | timestamp with time zone | NOT NULL |  |  |

### `marketplace.payout`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `amount` | bigint | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `rail` | text | NOT NULL |  |  |
| `destination_ref` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `arrival_date` | date |  |  |  |
| `failure_reason` | text |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `marketplace.reserve`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `type` | text | NOT NULL |  |  |
| `percent` | numeric(5,2) |  |  |  |
| `hold_days` | integer |  |  |  |
| `minimum_amount` | bigint |  |  |  |
| `reason` | text |  |  |  |
| `active_from` | timestamp with time zone | NOT NULL |  |  |
| `active_to` | timestamp with time zone |  |  |  |

### `marketplace.seller_agreement`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `seller_account_id` | text | NOT NULL | tenancy.account |  |
| `platform_account_id` | text | NOT NULL | tenancy.account |  |
| `role` | text | NOT NULL |  |  |
| `fund_flow` | text | NOT NULL |  |  |
| `merchant_of_record` | text | NOT NULL |  |  |
| `refund_liability` | text | NOT NULL |  |  |
| `dispute_liability` | text | NOT NULL |  |  |
| `negative_balance_liability` | text | NOT NULL |  |  |
| `commission_plan_id` | text |  | marketplace.commission_plan |  |
| `payout_schedule` | jsonb | NOT NULL |  |  |
| `reserve_policy` | jsonb |  |  |  |
| `tier` | text | NOT NULL |  |  |
| `protection_eligible` | boolean | NOT NULL |  |  |
| `debit_mandate_id` | text |  |  |  |
| `effective_from` | timestamp with time zone | NOT NULL |  |  |

### `marketplace.transfer`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `platform_account_id` | text | NOT NULL | tenancy.account |  |
| `from_party` | text | NOT NULL |  |  |
| `to_party` | text | NOT NULL |  |  |
| `amount` | bigint | NOT NULL |  |  |
| `currency` | character(3) | NOT NULL |  |  |
| `source_allocation_id` | text |  | marketplace.allocation |  |
| `amount_reversed` | bigint | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

## `tax`

### `tax.determination`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `order_id` | text | NOT NULL | commerce.order |  |
| `line_item_id` | text |  | commerce.line_item |  |
| `jurisdiction` | text | NOT NULL |  |  |
| `liable_party` | text | NOT NULL |  |  |
| `collected_by` | text | NOT NULL |  |  |
| `remitted_by` | text | NOT NULL |  |  |
| `invoice_issuer` | text | NOT NULL |  |  |
| `rule_ref` | text | NOT NULL |  |  |
| `inputs` | jsonb | NOT NULL |  |  |
| `engine` | text | NOT NULL |  |  |
| `engine_ref` | text |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `tax.registration`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `jurisdiction` | text | NOT NULL |  |  |
| `regime` | text | NOT NULL |  |  |
| `number` | text | NOT NULL |  |  |
| `facilitator` | boolean | NOT NULL |  |  |
| `valid_from` | date | NOT NULL |  |  |
| `valid_to` | date |  |  |  |

### `tax.remittance_period`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `jurisdiction` | text | NOT NULL |  |  |
| `period` | daterange | NOT NULL |  |  |
| `collected` | bigint | NOT NULL |  |  |
| `refunded` | bigint | NOT NULL |  |  |
| `adjusted` | bigint | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |

## `intelligence`

### `intelligence.bin_range`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `low` | character(8) | NOT NULL |  |  |
| `high` | character(8) | NOT NULL |  |  |
| `brand` | text | NOT NULL |  |  |
| `networks` | text[] | NOT NULL |  |  |
| `funding` | text | NOT NULL |  |  |
| `product` | text |  |  |  |
| `commercial` | boolean | NOT NULL |  |  |
| `regulated_debit` | boolean | NOT NULL |  |  |
| `issuer_id` | text |  | intelligence.issuer |  |
| `issuer_country` | character(2) |  |  |  |
| `issuer_currency` | character(3) |  |  |  |
| `source` | text | NOT NULL |  |  |
| `as_of` | date | NOT NULL |  |  |

### `intelligence.credential_insight`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `credential_fingerprint` | text | NOT NULL |  |  |
| `payment_method_id` | text |  |  |  |
| `bin8` | character(8) |  |  |  |
| `purpose` | text | NOT NULL |  |  |
| `context` | jsonb | NOT NULL |  |  |
| `sections` | jsonb | NOT NULL |  |  |
| `decision_ref` | text |  |  |  |
| `computed_at` | timestamp with time zone | NOT NULL |  |  |
| `valid_until` | timestamp with time zone | NOT NULL |  |  |

### `intelligence.credential_registration`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `payment_method_id` | text | NOT NULL | customer.payment_method |  |
| `purposes` | text[] | NOT NULL |  |  |
| `consent_type` | text | NOT NULL |  |  |
| `consent_ref` | text | NOT NULL |  |  |
| `related_payment_intent_id` | text |  | payments.payment_intent |  |
| `status` | text | NOT NULL |  |  |
| `expires_at` | timestamp with time zone |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `intelligence.credential_signal`

Early-warning signals keyed by fingerprint; cross-merchant facts exposed only as bands (usage policy).

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `credential_fingerprint` | text | NOT NULL |  |  |
| `signal` | text | NOT NULL |  |  |
| `band` | text |  |  |  |
| `source` | text | NOT NULL |  |  |
| `observed_at` | timestamp with time zone | NOT NULL |  |  |
| `expires_at` | timestamp with time zone |  |  |  |

### `intelligence.funds_signal`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `registration_id` | text | NOT NULL | intelligence.credential_registration |  |
| `source` | text | NOT NULL |  |  |
| `type` | text | NOT NULL |  |  |
| `recommended_retry_at` | timestamp with time zone |  |  |  |
| `window_ends_at` | timestamp with time zone |  |  |  |
| `confidence` | numeric(5,4) |  |  |  |
| `confidence_low` | numeric(5,4) |  |  |  |
| `confidence_high` | numeric(5,4) |  |  |  |
| `basis` | text[] | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `intelligence.issuer`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `name` | text | NOT NULL |  |  |
| `country` | character(2) |  |  |  |
| `supports` | jsonb | NOT NULL |  |  |
| `three_ds` | jsonb |  |  |  |
| `updated_at` | timestamp with time zone | NOT NULL |  |  |

### `intelligence.registration_programme`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `registration_id` | text | NOT NULL | intelligence.credential_registration |  |
| `programme` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
| `external_ref` | text |  |  |  |
| `reason` | text |  |  |  |

### `intelligence.retry_counter`

Network and Nacha retry allowances per merchant and credential; the retry engine checks it before every retry.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `account_id` | text | NOT NULL | tenancy.account |  |
| `credential_fingerprint` | text | NOT NULL |  |  |
| `network` | text | NOT NULL |  |  |
| `window_start` | timestamp with time zone | NOT NULL |  |  |
| `attempts` | integer | NOT NULL |  |  |
| `last_decline_category` | text |  |  |  |
| `blocked_reason` | text |  |  |  |

## `config`

### `config.document`

Configuration as signed, versioned documents per authority level; lower levels may only narrow higher ones.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `scope_account_id` | text |  | tenancy.account |  |
| `authority` | text | NOT NULL |  |  |
| `version` | integer | NOT NULL |  |  |
| `body` | jsonb | NOT NULL |  |  |
| `schema_version` | text | NOT NULL |  |  |
| `signature` | text |  |  |  |
| `status` | text | NOT NULL |  |  |
| `valid_from` | timestamp with time zone |  |  |  |
| `created_by` | text | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `config.entitlement`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `account_id` | text | NOT NULL | tenancy.account |  |
| `capability` | text | NOT NULL |  |  |
| `scope` | jsonb | NOT NULL |  |  |
| `state` | text | NOT NULL |  |  |

## `platform`

### `platform.audit_log`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | bigint | NOT NULL |  |  |
| `account_id` | text |  |  |  |
| `actor` | text | NOT NULL |  |  |
| `action` | text | NOT NULL |  |  |
| `object_type` | text |  |  |  |
| `object_id` | text |  |  |  |
| `request_id` | text |  |  |  |
| `details` | jsonb |  |  |  |
| `at` | timestamp with time zone | NOT NULL |  |  |

### `platform.event`

External event stream (curated projection, ten-state vocabulary). The internal journal is a separate store.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `type` | text | NOT NULL |  |  |
| `api_version` | text | NOT NULL |  |  |
| `livemode` | boolean | NOT NULL |  |  |
| `object_type` | text | NOT NULL |  |  |
| `object_id` | text | NOT NULL |  |  |
| `sequence` | bigint | NOT NULL |  |  |
| `cause_event_id` | text |  |  |  |
| `data` | jsonb | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `platform.idempotency_key`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `account_id` | text | NOT NULL | tenancy.account |  |
| `key` | text | NOT NULL |  |  |
| `request_hash` | bytea | NOT NULL |  |  |
| `response_status` | integer |  |  |  |
| `response_body` | jsonb |  |  |  |
| `resource_id` | text |  |  |  |
| `locked_until` | timestamp with time zone |  |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `platform.outbox`

Transactional outbox; dual writes are rejected.

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | bigint | NOT NULL |  |  |
| `event_id` | text | NOT NULL | platform.event |  |
| `published_at` | timestamp with time zone |  |  |  |

### `platform.test_clock`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `frozen_time` | timestamp with time zone | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |

### `platform.webhook_delivery`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | bigint | NOT NULL |  |  |
| `endpoint_id` | text | NOT NULL | platform.webhook_endpoint |  |
| `event_id` | text | NOT NULL | platform.event |  |
| `attempt` | integer | NOT NULL |  |  |
| `status_code` | integer |  |  |  |
| `next_retry_at` | timestamp with time zone |  |  |  |
| `dead_lettered` | boolean | NOT NULL |  |  |
| `created_at` | timestamp with time zone | NOT NULL |  |  |

### `platform.webhook_endpoint`

| Column | Type | Null | References | Note |
|---|---|---|---|---|
| `id` | text | NOT NULL |  |  |
| `account_id` | text | NOT NULL | tenancy.account |  |
| `url` | text | NOT NULL |  |  |
| `enabled_events` | text[] | NOT NULL |  |  |
| `api_version` | text | NOT NULL |  |  |
| `secret_ref` | text | NOT NULL |  |  |
| `status` | text | NOT NULL |  |  |
