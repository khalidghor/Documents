---
name: psp-credential-intelligence-and-retries
description: Use PSP credential and payments intelligence — BIN and issuer data, predicted cost, early-warning risk signals, dispute propensity, approval probability and recommended strategy (network token, 3DS/exemptions, routing, debit network) — and set up NSF recovery with credential registrations, funds signals and retries that stay inside Visa, Mastercard and Nacha limits. Use when improving approval rates, explaining declines, choosing authentication, or recovering insufficient-funds failures.
---

# Credential intelligence and NSF recovery

Reference: `docs/09-credential-intelligence.md`, `docs/10-nsf-signals-and-retries.md`, `config/credential-intelligence.yaml`, `config/retry-policy.yaml`.

## Getting an insight
- Call `credential_insights_get` with a `payment_method`, `credential_fingerprint` or `bin` — **never a card number** (the MCP server refuses PANs; PANs go only to the PCI host, from a PCI-scoped system).
- Always pass `context` (amount, currency, MCC, channel, initiator, stored_credential, candidate acquirers) and a `purpose`. Without context, approval and strategy are generic.
- Read every estimate with its interval and `support`. If `support: insufficient`, say so — do not quote a number.
- Early-warning signals declare `status`; `not_available` means we do not receive that signal (e.g. issuer-side compromise lists), not that the card is clean.

## Turning insight into action
| Insight | Action |
|---|---|
| Network token eligible, higher approval by option | Prefer the token credential (the platform does this automatically; advise merchants who self-route) |
| High friendly-fraud band, low risk band | Keep frictionless 3DS for liability shift; strengthen delivery evidence |
| Low approval probability for card | Offer BNPL or pay-by-bank first in the session |
| Regulated debit with co-badged networks | Expect PIN-less debit routing for cost |
| Issuer `approval_trend: anomaly` | Do not retry blindly; check payment intelligence for an issuer incident |

## NSF recovery
1. Confirm the failure is recoverable: `last_result.reason = insufficient_funds`, `retryability.retryable = true`, `network_advice` is not Mastercard MAC 03/21 or a Visa category-1 code.
2. Register the credential: `credential_registrations_create` with `purposes: ["nsf_recovery"]` and the consent reference (stored-credential agreement or mandate).
3. Either enable managed retries (`policies.managed_retries`) or listen for `credential.funds_signal` and re-confirm the **same** intent at `recommended_retry_at`.
4. Never exceed: Visa 15 reattempts in 30 days (none for category 1), Mastercard MAC timing (24–30) and excessive-attempt limits, Nacha two re-presentments of R01/R09 within 180 days. `retryability.attempts_remaining_under_network_rules` is the counter to obey.
5. Measure recovery against the holdout, and watch the guardrail: "canceled recurring" disputes on recovered payments.
