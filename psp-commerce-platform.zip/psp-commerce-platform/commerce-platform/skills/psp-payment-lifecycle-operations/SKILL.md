---
name: psp-payment-lifecycle-operations
description: Operate Payment Intents safely after checkout — captures (single, partial, multi), incremental authorizations, expiring authorizations and reauthorization (reauth-then-reverse or reverse-then-reauth), reversals, single or multiple partial refunds, and ACH/BNPL specifics. Use when asked to capture, refund, extend, reauthorize, cancel or explain a payment, or to diagnose why a capture or refund failed.
---

# Operate the payment lifecycle

Read `docs/05-payment-lifecycle.md` once; this skill is its checklist.

## Always start by reading the intent
`payment_intents_get` then `payment_intents_get_lineage`. Note:
- `status` (ten states) — what the merchant sees;
- `authorization.status`, `amount_capturable`, `expires_at`, `expiry_basis`, `reauthorization_count`;
- `amount_captured / refunded / disputed / charged_back`, and per-capture refunds in the lineage;
- `finality` and `funds` — whether money is final and where it is;
- `last_result.retryability` — whether a re-confirm is allowed and when.

## Decide the operation

| Goal | Preconditions | Tool | Notes |
|---|---|---|---|
| Capture a shipment | `amount_capturable ≥ amount`, now < `expires_at` | `payment_intents_capture` with `final_capture:false` unless it is the last | Pass `fulfillment_group_id` |
| Last capture | — | `final_capture:true` | Remainder is released automatically |
| Tip above authorization | MCC tolerance, else increment first | `payment_intents_increment_authorization` then capture | |
| Authorization about to expire | Stored-credential consent; amount ≤ capturable | `payment_intents_reauthorize` `mode:auto` | Debit/prepaid → reverse-then-reauth; credit → reauth-then-reverse |
| Authorization already expired | Nothing captured → intent is `canceled`; create a new intent only with a mandate or the customer present | — | Never capture an expired authorization |
| Cancel unshipped lines | Before capture | `orders_amend` (cancel_lines) or reverse | A reversal, not a refund |
| Refund | Captured; amount ≤ capture − refunded − disputed − charged back | `payment_intents_refund` with `capture_operation` for multi-capture | Many partial refunds are fine |
| Refund under open dispute | — | Do not. Accept the dispute instead | `refund_blocked_by_dispute` |
| Retry a failed payment | `retryability.retryable` and inside the window | `payment_intents_confirm` on the same intent | Respect `attempts_remaining_under_network_rules` |

## Money-moving calls
Every capture, refund, reversal, reauthorization and cancel is money movement. Show the user exactly what will happen (amount, which capture, what is released) and get an explicit go-ahead before calling with `confirm: true`. Reuse the same `idempotency_key` when retrying after a timeout.

## Method specifics
- **ACH**: captured on acceptance; `finality.reversible_until` is up to 60 days; no void after submission; R01/R09 → at most two re-presentments in 180 days; R10 is an unauthorized return (a dispute with no representment).
- **BNPL**: the provider holds the authorization and its validity; refunds adjust the buyer's plan; disputes run through the provider.
- **RTP/FedNow**: final on receipt; refunds are new credits.

## Explaining a payment
Use the `explain_payment` prompt: lineage, why each attempt exists (`origin`), the decision records (`payment_intents_explain_decisions`), each state model separately, and the next safe action.
