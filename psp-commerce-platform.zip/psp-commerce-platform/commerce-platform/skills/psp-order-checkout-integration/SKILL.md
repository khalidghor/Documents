---
name: psp-order-checkout-integration
description: Build a checkout, POS, kiosk, app or agent purchase flow on the PSP Order and Payment Intent resources. Use when integrating orders for QSR, e-retail, retail, grocery, marketplace or services; choosing a collection plan; wiring webhooks; or setting up sandbox scenarios to test authorization expiry, split shipments, split tender and returns.
---

# Integrate checkout on Orders + Payment Intents

## When to use
A developer (or you, acting for one) is building any flow where a buyer pays for goods or services and the merchant wants line-level refunds, split shipment captures, split tender, marketplace sellers or dispute evidence without building its own ledger. If the merchant already has an OMS and only needs to collect money, skip to step 4 and integrate at the Payment Intent level with `order_reference`.

## Steps

1. **Pick the industry profile** (`docs/11-industry-playbooks.md`, `config/order-profiles.yaml`). It sets the collection plan, capture trigger, authorization type and partial-authorization behaviour. Do not hand-pick these unless the profile is wrong for the business.

   | Business | `industry_profile` | Collection plan |
   |---|---|---|
   | Counter / app order-ahead | `qsr` | `pay_now` |
   | Table service, bar tab | `qsr` | `authorize_then_capture_on_close` |
   | Ships goods | `e_retail` | `authorize_then_capture_on_fulfillment` (multi-capture) |
   | Store POS | `retail` | `split_tender` |
   | Several sellers | `marketplace` | `authorize_then_capture_on_fulfillment` per seller |
   | Deposit then balance | `services` | `deposit_then_balance` (needs a mandate) |

2. **Model the lines properly.** One line per sellable thing; nested `modifiers` for QSR; `seller_id` on every marketplace line; `fulfillment_group_id` on every line that ships or is picked up; discounts with `funded_by`. Quantities are decimal strings. Never put tax or shipping inside a product line's price.

3. **Create and place the order.** `orders_create` with `place: true` (or create a draft, then `orders_place`). The response's `payments[]` holds the Payment Intent(s) the plan created; if one has `next_action`, hand its `client_secret` to the front end (3DS, BNPL redirect, bank consent, terminal).

4. **Collect stored-credential consent at checkout** whenever the plan may need a reauthorization (backorders, pre-orders, split shipments beyond the validity window) or a later MIT (balances, installments). Without it the platform cannot reauthorize and the order will hit `payment_exception` on expiry.

5. **Drive fulfillment, not payments.** Call `orders_ship_fulfillment` / complete for each group; the capture trigger captures for you (sequence numbers, final capture, remainder release). Do not call capture yourself unless the merchant has no Order.

6. **Handle the webhooks that need action** (`docs/12-developer-experience.md` §5):
   - `order.payment_attention_required` — authorization expiring under `notify` policy: ship now, reauthorize, or cancel lines.
   - `order.payment_exception` — the balance is no longer covered: re-engage the customer (pay link) or cancel lines.
   - `payment_intent.refund.failed` — choose a fallback destination.
   - `dispute.created` — see the `psp-dispute-management` skill.
   Everything else is informational; the platform owns retries, recovery and reauthorization.

7. **Returns** go through `orders_create_return`; the refund plan refunds the right capture(s) and, in a marketplace, the right seller.

8. **Test in the sandbox with a test clock** (`test_clocks_advance`): advance 9 days to see `authorization_expiring` and the reauthorization; use scenario cards for partial authorization, declined reauthorization, NSF and disputes.

## Checks before going live
- Every POST sends an `Idempotency-Key` (SDKs do; raw HTTP must).
- The integration never reads processor codes — only `last_result` (canonical result) and `retryability`.
- Order `status`, `payment_status`, `fulfillment_status`, `settlement_status` and `dispute_status` are displayed separately.
- No card numbers touch the merchant's servers (sessions/elements or the PCI host only).

## Mistakes to avoid
- Creating a new Payment Intent to "retry" a soft decline, a step-up or an expiring authorization — that is the platform's job on the same intent.
- Capturing after `authorization.expires_at`.
- Using refunds to cancel unshipped lines (that is a reversal; `orders_amend` does it).
- Treating `captured` on ACH as final — read `finality`.
