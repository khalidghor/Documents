---
name: psp-marketplace-ledger-setup
description: Configure a marketplace, platform or PayFac on the PSP — choose a fund-flow model (merchant of record, settlement merchant, liability), commission and fee plans, tax responsibility (marketplace facilitator, deemed supplier), dispute allocation rules and the recovery waterfall, payouts and reserves — and explain or reconcile the two ledgers (acquiring and commerce). Use for any multi-seller, split-payment, seller payout, marketplace tax or seller liability question.
---

# Set up a marketplace and its two ledgers

Reference: `docs/08-marketplace-and-ledgers.md`, `config/marketplace/*.yaml`, `reference/marketplace-ledger.ts` (tested worked example).

## 1. Choose the fund-flow model
Ask who the buyer contracts with, whose descriptor appears, and who the platform wants debited first.

| If… | Model |
|---|---|
| The platform sells and owns the customer (one brand at checkout) | `platform_mor_separate_transfers` (or `platform_mor_destination`) |
| Sellers are known brands whose name and MCC must appear | `seller_mor_on_behalf_of` |
| Sellers run their own business on the platform's software | `seller_mor_direct` |
| Splits must be fixed at authorization (Adyen-style) | `split_at_authorization` with a liable account |
| The platform onboards sub-merchants under its MID | `payfac_submerchant` |

Write it in `marketplace.yaml` with `liability_defaults`; override per seller only with a reason.

## 2. Commission, fees, promotions, tips
- Commission applies to item price only (not tax, not seller-charged shipping) unless the contract says otherwise.
- Decide `refund_admin_fee` and `commission_on_chargeback` (retain/refund) — both change seller outcomes; the worked example shows each.
- Every discount needs `funded_by`; tips are pass-through liabilities.

## 3. Tax responsibility
Use `tax-responsibility.yaml`. For US sales the platform is usually the marketplace facilitator; in the EU/UK/AU the platform can be the deemed supplier for imports and non-resident sellers. Mark every new regime `verify_before_production` and get tax counsel sign-off. Decide `chargeback_treatment` per regime.

## 4. Dispute allocation
Start from `dispute-allocation-rules.yaml`: processing errors and platform-decided fraud → platform; marketplace-fulfilled → platform; seller-fulfilled not-received / not-as-described → seller with evidence SLA; small amounts absorbed; protection programme for compliant sellers. Then:
1. `dispute_rules_simulate` with `lookback_days: 90`;
2. present liability by party (current vs. proposed) and the changed cases;
3. publish only after the user agrees.

## 5. Payouts, reserves, recovery
New sellers: weekly payouts after delivery, rolling reserve. Recovery waterfall: available → pending → reserve → future payouts → bank debit (mandate) → platform absorbs.

## 6. Reconcile the two ledgers
- Acquiring ledger = where the money is (PSP books, by merchant account).
- Commerce ledger = who owes whom (platform book, by seller/purpose).
- Invariant: platform `merchant_payable` (acquiring) = `psp_receivable` (commerce) = Σ commerce balances. Use `ledger_reconciliation`; a break is a case to investigate, never a plug.
- To explain a seller's balance, list commerce entries for the seller (`ledger_entries_list` with `seller_id`) and walk capture → fee → refund → dispute, as in docs/08 §4.
