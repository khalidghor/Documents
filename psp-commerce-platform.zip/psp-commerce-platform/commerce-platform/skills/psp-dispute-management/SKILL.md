---
name: psp-dispute-management
description: Handle pre-dispute alerts (Ethoca, Verifi CDRN, Visa RDR, Order Insight, inquiries) and disputes/chargebacks on the PSP platform — decide refund vs. decline, assemble evidence (including Visa Compelling Evidence 3.0), choose accept vs. represent by expected value, meet deadlines, and apply marketplace dispute allocation to sellers. Use for any chargeback, dispute alert, retrieval request or dispute-rule question.
---

# Manage disputes and pre-disputes

Reference: `docs/07-disputes.md`, `docs/05-payment-lifecycle.md` §8–9, `config/dispute-policy.yaml`, `config/marketplace/dispute-allocation-rules.yaml`.

## Pre-dispute alerts (`dispute_alerts_list`)
1. Check `match_confidence`. Only act on `exact` (or `probable` after confirming amount, date, last4 and MID).
2. Follow `recommended_action` unless the user has a reason not to; it comes from the prevention rules.
   - `fraud_confirmed` → refund and cancel future shipments/subscriptions.
   - "not received" without tracking → refund; with signed delivery → decline and keep evidence ready.
3. Resolve with `dispute_alerts_resolve` before `respond_by`. A refund here is an ordinary refund (`reason: dispute_prevention`) and follows the order's line and seller allocation.

## Disputes (`disputes_list`, `disputes_get`)
1. Read `reason.category`, `network_flow`, `stage`, `evidence_due_by`, `liability`, `win_likelihood`, and `allocation` (marketplaces).
2. Check required evidence by reason:

   | Reason | Evidence that wins |
   |---|---|
   | Fraud (Visa 10.4 / MC 4837) | 3DS liability shift; else CE 3.0 (two undisputed prior transactions 120–365 days old with matching IP/device + one more element); AVS/CVV; device |
   | Not received | Tracking + proof of delivery to the billing/shipping address; signature for high value |
   | Not as described | Product description snapshot, terms, communications, return offered |
   | Credit not processed | Refund record with ARN and date — or proof no refund was owed (return policy, item not returned) |
   | Canceled recurring | Cancellation policy accepted, no cancellation received, usage after the claimed date |
   | Duplicate / incorrect amount | Distinct receipts / correct amount evidence |
   | Agentic purchase | Agent authority record: mandate@version, instruction hash, step-up |

3. Decide: represent when `p(win) × amount − effort − fee risk > 0`, otherwise accept. Never refund an amount under open dispute — accept instead.
4. Save a draft (`disputes_draft_evidence`), show the user what will be submitted, then submit (`disputes_submit_evidence`, irreversible) — or accept (`disputes_accept`). Both need explicit user confirmation.
5. Pre-arbitration: re-evaluate with the issuer's new information. Arbitration needs a human decision (fees).

## Marketplaces
- The allocation rule on the dispute says who is liable, who responds and who pays the fee. If the responder is `platform_with_seller_evidence`, request evidence from the seller early; the rule says what happens if they miss the SLA.
- To change who bears what, edit the rule set and run `dispute_rules_simulate` over the last 90 days before publishing. Explain the change in liability by party.

## Monitoring
Watch dispute and fraud ratios per merchant/seller against the thresholds in `dispute-policy.yaml` (VAMP, ECM/EFM). Rising ratios → tighten prevention rules, require 3DS for CNP, or add seller reserves.
