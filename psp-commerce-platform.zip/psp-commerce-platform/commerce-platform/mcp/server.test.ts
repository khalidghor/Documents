import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { containsPan, deriveIdempotencyKey } from './server.ts';

const SERVER = join(dirname(fileURLToPath(import.meta.url)), 'server.ts');

function rpc(messages: object[], env: Record<string, string> = {}): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const p = spawn(process.execPath, [SERVER], { env: { ...process.env, PSP_API_BASE: 'http://127.0.0.1:9', ...env } });
    let out = '';
    p.stdout.on('data', (d) => (out += d));
    p.on('error', reject);
    const want = messages.filter((m: any) => m.id !== undefined).length;
    const timer = setTimeout(() => { p.kill(); reject(new Error('timeout: ' + out)); }, 5000);
    p.stdout.on('data', () => {
      const lines = out.split('\n').filter(Boolean);
      if (lines.length >= want) { clearTimeout(timer); p.kill(); resolve(lines.map((l) => JSON.parse(l))); }
    });
    for (const m of messages) p.stdin.write(JSON.stringify({ jsonrpc: '2.0', ...m }) + '\n');
  });
}

test('PAN detection uses Luhn and ignores ids and amounts', () => {
  assert.equal(containsPan({ number: '4242 4242 4242 4242' }), true);
  assert.equal(containsPan({ note: 'card 4000-0000-0000-0002' }), true);
  assert.equal(containsPan({ amount: 11800, order_id: 'ord_8Kd2', bin: '42424242' }), false);
  assert.equal(containsPan({ ref: '1234567890123456' }), false); // fails Luhn
});

test('idempotency keys are stable for the same arguments regardless of key order', () => {
  assert.equal(deriveIdempotencyKey('t', { a: 1, b: { c: 2, d: 3 } }), deriveIdempotencyKey('t', { b: { d: 3, c: 2 }, a: 1 }));
  assert.notEqual(deriveIdempotencyKey('t', { a: 1 }), deriveIdempotencyKey('t', { a: 2 }));
});

test('initialize, list tools with annotations, list resources and prompts', async () => {
  const [init, tools, resources, prompts] = await rpc([
    { id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 't', version: '0' } } },
    { method: 'notifications/initialized' },
    { id: 2, method: 'tools/list' },
    { id: 3, method: 'resources/list' },
    { id: 4, method: 'prompts/list' },
  ]);
  assert.equal(init.result.serverInfo.name, 'psp-commerce');
  const names = tools.result.tools.map((t: any) => t.name);
  assert.ok(names.includes('payment_intents_reauthorize'));
  const refund = tools.result.tools.find((t: any) => t.name === 'payment_intents_refund');
  assert.equal(refund.annotations.destructiveHint, true);
  assert.ok(refund.inputSchema.properties.confirm);
  assert.ok(resources.result.resources.some((r: any) => r.uri === 'psp://docs/05-payment-lifecycle.md'));
  assert.ok(prompts.result.prompts.some((p: any) => p.name === 'prepare_dispute_response'));
});

test('money movement is a dry run unless enabled twice; PANs are refused', async () => {
  const [dry, pan] = await rpc([
    { id: 1, method: 'tools/call', params: { name: 'payment_intents_capture', arguments: { payment_intent_id: 'pi_1', amount: 7000, final_capture: false, confirm: true } } },
    { id: 2, method: 'tools/call', params: { name: 'credential_insights_get', arguments: { bin: '4242424242424242' } } },
  ], { PSP_API_KEY: 'sk_test_x' });
  assert.match(dry.result.content[0].text, /DRY RUN/);
  assert.match(dry.result.content[0].text, /Idempotency-Key: mcp-/);
  assert.equal(pan.result.isError, true);
  assert.match(pan.result.content[0].text, /pan_not_allowed_in_mcp/);
});

test('live keys and sandbox tools are guarded', async () => {
  const [live] = await rpc([{ id: 1, method: 'tools/call', params: { name: 'orders_list', arguments: {} } }], { PSP_API_KEY: 'sk_live_x' });
  assert.match(live.result.content[0].text, /PSP_ALLOW_LIVE/);
  const [sandbox] = await rpc([{ id: 1, method: 'tools/call', params: { name: 'test_simulate_ach_return', arguments: { payment_intent_id: 'pi_1', code: 'R01' } } }], { PSP_API_KEY: 'sk_live_x', PSP_ALLOW_LIVE: 'true' });
  assert.match(sandbox.result.content[0].text, /sk_test_/);
});
