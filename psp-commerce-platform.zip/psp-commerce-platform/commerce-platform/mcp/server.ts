#!/usr/bin/env node
/**
 * PSP Commerce MCP server — a dependency-free Model Context Protocol server over stdio (JSON-RPC 2.0,
 * newline-delimited). Node 22.18+ runs this TypeScript directly.
 *
 * It is a thin, policy-enforcing proxy over the REST API (docs/13): every tool is one REST call declared
 * in tools.json. It never holds business logic. Safety rules:
 *   1. no PAN ever leaves this process (Luhn-valid 13–19 digit sequences are refused);
 *   2. money movement needs PSP_ALLOW_MONEY_MOVEMENT=true AND confirm:true on the call (else a dry run);
 *   3. an Idempotency-Key is always sent (derived from tool + arguments if the agent gives none);
 *   4. live keys are refused unless PSP_ALLOW_LIVE=true; sandbox tools need a test key.
 *
 * Environment: PSP_API_BASE (default http://localhost:4242), PSP_API_KEY, PSP_ALLOW_MONEY_MOVEMENT,
 * PSP_ALLOW_LIVE, PSP_ON_BEHALF_OF, PSP_API_VERSION.
 */
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';

type Json = null | boolean | number | string | Json[] | { [k: string]: Json };
interface ToolDef {
  name: string; method: 'GET' | 'POST'; path: string; title: string; description: string;
  properties: Record<string, Json>; required?: string[];
  readOnly?: boolean; destructive?: boolean; idempotentHint?: boolean; money?: boolean; sandbox?: boolean;
  fixedBody?: Record<string, Json>; render?: 'lineage';
}
interface PromptDef { name: string; description: string; arguments: { name: string; required: boolean }[]; template: string }

const HERE = dirname(fileURLToPath(import.meta.url));
const PACKAGE_ROOT = join(HERE, '..');
const manifest = JSON.parse(readFileSync(join(HERE, 'tools.json'), 'utf8')) as { tools: ToolDef[]; prompts: PromptDef[] };

const env = {
  base: (process.env.PSP_API_BASE ?? 'http://localhost:4242').replace(/\/$/, ''),
  key: process.env.PSP_API_KEY ?? '',
  allowMoney: process.env.PSP_ALLOW_MONEY_MOVEMENT === 'true',
  allowLive: process.env.PSP_ALLOW_LIVE === 'true',
  onBehalfOf: process.env.PSP_ON_BEHALF_OF,
  apiVersion: process.env.PSP_API_VERSION ?? '2026-11-15',
};

// ------------------------------------------------------------------------------------------- safety
export function containsPan(value: unknown): boolean {
  const text = typeof value === 'string' ? value : JSON.stringify(value ?? '');
  const candidates = text.match(/(?:\d[ -]?){13,19}/g) ?? [];
  return candidates.some((c) => luhn(c.replace(/[ -]/g, '')));
}

function luhn(digits: string): boolean {
  if (!/^\d{13,19}$/.test(digits)) return false;
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let d = Number(digits[digits.length - 1 - i]);
    if (i % 2 === 1) { d *= 2; if (d > 9) d -= 9; }
    sum += d;
  }
  return sum % 10 === 0;
}

function canonical(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).sort().map((k) => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(',')}}`;
  return JSON.stringify(v);
}

export function deriveIdempotencyKey(tool: string, args: Record<string, unknown>): string {
  return 'mcp-' + createHash('sha256').update(tool + canonical(args)).digest('hex').slice(0, 32);
}

// ------------------------------------------------------------------------------------------- tools
function inputSchema(t: ToolDef) {
  const properties: Record<string, Json> = { ...t.properties };
  if (t.method === 'POST') properties.idempotency_key = { type: 'string', description: 'Optional; derived from the arguments if omitted.' };
  if (t.money) properties.confirm = { type: 'boolean', description: 'Must be true to move money. Without it the tool returns a dry run.' };
  return { type: 'object', properties, required: t.required ?? [], additionalProperties: false };
}

function listTools() {
  return manifest.tools.map((t) => ({
    name: t.name,
    title: t.title,
    description: t.description + (t.money ? ' Moves money: requires confirm=true and a server started with PSP_ALLOW_MONEY_MOVEMENT=true.' : '') + (t.sandbox ? ' Sandbox only.' : ''),
    inputSchema: inputSchema(t),
    annotations: {
      title: t.title,
      readOnlyHint: Boolean(t.readOnly),
      destructiveHint: Boolean(t.destructive),
      idempotentHint: Boolean(t.idempotentHint || t.readOnly || t.method === 'POST'),
      openWorldHint: true,
    },
  }));
}

export function buildRequest(t: ToolDef, rawArgs: Record<string, unknown>) {
  const args = { ...rawArgs };
  const idem = (args.idempotency_key as string | undefined) ?? (t.method === 'POST' ? deriveIdempotencyKey(t.name, rawArgs) : undefined);
  delete args.idempotency_key;
  delete args.confirm;
  let path = t.path;
  for (const m of t.path.matchAll(/{([a-z_]+)}/g)) {
    const v = args[m[1]];
    if (typeof v !== 'string' || !v) throw new ToolError(`missing path parameter ${m[1]}`);
    path = path.replace(m[0], encodeURIComponent(v));
    delete args[m[1]];
  }
  const headers: Record<string, string> = { 'Psp-Version': env.apiVersion, Accept: 'application/json' };
  if (env.key) headers.Authorization = `Bearer ${env.key}`;
  if (env.onBehalfOf) headers['On-Behalf-Of'] = env.onBehalfOf;
  let url = env.base + path;
  let body: string | undefined;
  if (t.method === 'GET') {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(args)) {
      if (Array.isArray(v)) v.forEach((x) => qs.append(`${k}[]`, String(x)));
      else if (v !== undefined && v !== null) qs.append(k, typeof v === 'object' ? JSON.stringify(v) : String(v));
    }
    if ([...qs].length) url += `?${qs}`;
  } else {
    headers['Content-Type'] = 'application/json';
    headers['Idempotency-Key'] = idem!;
    body = JSON.stringify({ ...args, ...(t.fixedBody ?? {}) });
  }
  return { method: t.method, url, headers, body, idempotencyKey: idem };
}

class ToolError extends Error {}

async function callTool(name: string, args: Record<string, unknown>) {
  const t = manifest.tools.find((x) => x.name === name);
  if (!t) throw new ToolError(`unknown tool ${name}`);
  if (containsPan(args)) return text('Refused: pan_not_allowed_in_mcp. Card numbers never go through the MCP server; use a payment method, token, fingerprint or BIN.', true);
  if (env.key.startsWith('sk_live_') && !env.allowLive) return text('Refused: a live key is configured but PSP_ALLOW_LIVE is not true.', true);
  if (t.sandbox && !env.key.startsWith('sk_test_')) return text('Refused: sandbox tools require a sk_test_ key.', true);
  const req = buildRequest(t, args);
  if (t.money && !(env.allowMoney && args.confirm === true)) {
    return text(
      `DRY RUN — no money moved.\nWould call ${req.method} ${req.url}\nIdempotency-Key: ${req.idempotencyKey}\nBody: ${req.body ?? '(none)'}\n` +
      `To execute: start the server with PSP_ALLOW_MONEY_MOVEMENT=true and call again with confirm=true.`,
    );
  }
  let res: Response;
  try {
    res = await fetch(req.url, { method: req.method, headers: req.headers, body: req.body });
  } catch (e) {
    return text(`Network error calling ${req.url}: ${(e as Error).message}. The call is idempotent; retrying with the same arguments is safe.`, true);
  }
  const raw = await res.text();
  let data: unknown = raw;
  try { data = JSON.parse(raw); } catch { /* not JSON */ }
  if (!res.ok) return text(`HTTP ${res.status}\n${JSON.stringify(data, null, 2)}`, true);
  if (t.render === 'lineage') return text(renderLineage(data));
  return text(JSON.stringify(data, null, 2));
}

function renderLineage(data: unknown): string {
  const ops = ((data as { data?: unknown[] })?.data ?? []) as Record<string, any>[];
  if (!ops.length) return 'No operations.';
  const lines = ops.map((o) => {
    const head = `├─ ${o.id}  ${o.type}${o.capture ? ` seq ${o.capture.sequence}${o.capture.final_capture ? ' final' : ''}` : ''}  ${o.amount}  ${o.status}${o.parent_operation ? `  (parent ${o.parent_operation})` : ''}`;
    const atts = (o.attempts_expanded ?? []).map((a: Record<string, any>) => `│   └─ ${a.id}  ${a.origin}  ${a.rail}${a.acquirer ? ` · ${a.acquirer}` : ''}  ${a.outcome}`);
    return [head, ...atts].join('\n');
  });
  return lines.join('\n');
}

function text(s: string, isError = false) {
  return { content: [{ type: 'text', text: s }], isError };
}

// ------------------------------------------------------------------------------------------- resources & prompts
function listResources() {
  const out: { uri: string; name: string; mimeType: string }[] = [];
  const add = (dir: string, scheme: string, ext: string, mime: string) => {
    const abs = join(PACKAGE_ROOT, dir);
    for (const f of walk(abs)) if (f.endsWith(ext)) out.push({ uri: `psp://${scheme}/${relative(abs, f)}`, name: `${scheme}/${relative(abs, f)}`, mimeType: mime });
  };
  add('docs', 'docs', '.md', 'text/markdown');
  add('openapi', 'openapi', '.yaml', 'application/yaml');
  add('config', 'config', '.yaml', 'application/yaml');
  return out;
}

function readResource(uri: string) {
  const m = uri.match(/^psp:\/\/(docs|openapi|config)\/(.+)$/);
  if (!m || m[2].includes('..')) throw new ToolError(`unknown resource ${uri}`);
  const file = join(PACKAGE_ROOT, m[1], m[2]);
  return { contents: [{ uri, mimeType: file.endsWith('.md') ? 'text/markdown' : 'application/yaml', text: readFileSync(file, 'utf8') }] };
}

function walk(dir: string): string[] {
  return readdirSync(dir).flatMap((f) => {
    const p = join(dir, f);
    return statSync(p).isDirectory() ? walk(p) : [p];
  });
}

function getPrompt(name: string, args: Record<string, string>) {
  const p = manifest.prompts.find((x) => x.name === name);
  if (!p) throw new ToolError(`unknown prompt ${name}`);
  const body = p.template.replace(/{(\w+)}/g, (_, k) => args[k] ?? `<${k}>`);
  return { description: p.description, messages: [{ role: 'user', content: { type: 'text', text: body } }] };
}

// ------------------------------------------------------------------------------------------- JSON-RPC
async function handle(msg: { id?: number | string; method: string; params?: any }) {
  switch (msg.method) {
    case 'initialize':
      return {
        protocolVersion: msg.params?.protocolVersion ?? '2025-06-18',
        capabilities: { tools: { listChanged: false }, resources: { listChanged: false }, prompts: { listChanged: false } },
        serverInfo: { name: 'psp-commerce', title: 'PSP Commerce Platform', version: '0.1.0' },
        instructions: 'Orders, Payment Intents, operations, disputes, marketplace ledgers and credential intelligence. Read psp://docs/05-payment-lifecycle.md before operating payments. Never send card numbers.',
      };
    case 'ping': return {};
    case 'tools/list': return { tools: listTools() };
    case 'tools/call': return callTool(msg.params?.name, msg.params?.arguments ?? {});
    case 'resources/list': return { resources: listResources() };
    case 'resources/read': return readResource(msg.params?.uri);
    case 'prompts/list': return { prompts: manifest.prompts.map(({ name, description, arguments: a }) => ({ name, description, arguments: a })) };
    case 'prompts/get': return getPrompt(msg.params?.name, msg.params?.arguments ?? {});
    default: throw Object.assign(new Error(`method not found: ${msg.method}`), { code: -32601 });
  }
}

function send(obj: unknown) { process.stdout.write(JSON.stringify(obj) + '\n'); }

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const rl = createInterface({ input: process.stdin });
  rl.on('line', async (line) => {
    if (!line.trim()) return;
    let msg: any;
    try { msg = JSON.parse(line); } catch { send({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'parse error' } }); return; }
    if (msg.id === undefined) return; // notification (e.g. notifications/initialized)
    try {
      send({ jsonrpc: '2.0', id: msg.id, result: await handle(msg) });
    } catch (e) {
      const code = (e as { code?: number }).code ?? (e instanceof ToolError ? -32602 : -32603);
      send({ jsonrpc: '2.0', id: msg.id, error: { code, message: (e as Error).message } });
    }
  });
}
