# PSP Commerce Platform — Orders, Payment Intents, Lifecycle, Marketplace Ledgers & Credential Intelligence

This package specifies the order and payment layer for a PSP that competes with Stripe and Adyen on omnichannel acceptance. The target users are QSR, e-retail, retail, marketplaces, PayFacs, checkout products, enterprises and agents. It builds on **ST-003 "The Case for Intent" (v1.3)**: one durable object per purchase, ten states for every method, and decisions the platform makes and can prove. ST-003's identity hierarchy is used as written: Order → Payment Intent → Operation → Attempt.

Everything here is checked mechanically:
- the OpenAPI files pass lint;
- the SQL loads into PostgreSQL 16;
- the configuration parses;
- the examples validate against the schemas;
- the lifecycle and ledger rules run as tests (25 passing).

## Start here — a reading path

| If you are… | Read, in order | Time |
|---|---|---|
| **An executive** | [00 Strategy & positioning](docs/00-strategy-and-positioning.md) → [05 §0 and §10 — the lifecycle on one page](docs/05-payment-lifecycle.md) → [08 §4 — the two-ledger worked example](docs/08-marketplace-and-ledgers.md) | 25 min |
| **A product manager** | 00 → [01 Resource model](docs/01-resource-model.md) → [02 Order](docs/02-order-resource.md) → [03 Payment Intent](docs/03-payment-intent.md) → [06 Order reflection](docs/06-order-payment-reflection.md) → [11 Industry playbooks](docs/11-industry-playbooks.md) | 1.5 h |
| **A payments engineer** | 01 → 03 → [04 Operations & attempts](docs/04-operations-and-attempts.md) → [05 Lifecycle](docs/05-payment-lifecycle.md) → [07 Disputes](docs/07-disputes.md) → [`reference/`](reference) → [`openapi/`](openapi) | 2 h |
| **A marketplace or PayFac lead** | [08 Marketplace & ledgers](docs/08-marketplace-and-ledgers.md) → [`config/marketplace/`](config/marketplace) → [`reference/marketplace-ledger.test.ts`](reference/marketplace-ledger.test.ts) | 1 h |
| **A risk or intelligence lead** | [09 Credential intelligence](docs/09-credential-intelligence.md) → [10 NSF signals & retries](docs/10-nsf-signals-and-retries.md) → [`config/retry-policy.yaml`](config/retry-policy.yaml) | 45 min |
| **A data or platform architect** | [14 Data model & configuration](docs/14-data-model-and-configuration.md) → [`data-model/ERD.md`](data-model/ERD.md) → [`data-model/schema.sql`](data-model/schema.sql) → [`config/README.md`](config/README.md) | 1.5 h |
| **A developer-experience or AI lead** | [12 Developer experience](docs/12-developer-experience.md) → [13 MCP & skills](docs/13-mcp-and-skills.md) → [`mcp/`](mcp) → [`skills/`](skills) | 45 min |

## What is in the box

```
commerce-platform/
├── README.md                         ← you are here
├── docs/                             the specification, in 15 chapters
│   ├── 00-strategy-and-positioning   the bet, vs Stripe/Adyen, decisions P1–P12, open items
│   ├── 01-resource-model             identity hierarchy, four state models, method vs rail
│   ├── 02-order-resource             lines, modifiers, fulfillment, collection plans, five statuses, returns
│   ├── 03-payment-intent             ten states, authorization/finality/funds blocks, methods beyond card
│   ├── 04-operations-and-attempts    authorize · incremental · reauthorize · reverse · capture · refund; attempts
│   ├── 05-payment-lifecycle          ★ the full logical view: auth → expiry → reauth → captures → refunds → pre-dispute → dispute
│   ├── 06-order-payment-reflection   ★ how every payment event moves the order
│   ├── 07-disputes                   dispute & alert resources, evidence, automation, monitoring
│   ├── 08-marketplace-and-ledgers    ★ fund flows, two ledgers, worked example to the cent, dispute allocation, tax
│   ├── 09-credential-intelligence    BIN, issuer, cost, risk, early warning, disputes, approval, strategy
│   ├── 10-nsf-signals-and-retries    credential registration, funds signals, managed retries, network limits
│   ├── 11-industry-playbooks         QSR · e-retail · retail · marketplace · PayFac · enterprise · agentic
│   ├── 12-developer-experience       portal IA, conventions, event catalog, sandbox and test clocks
│   ├── 13-mcp-and-skills             MCP server design and safety; the five agent skills
│   └── 14-data-model-and-configuration
├── openapi/                          Swagger / OpenAPI 3.1 — 77 operations, 6 domains, 25 webhooks
│   ├── psp.openapi.yaml              all domains
│   ├── orders | payment-intents | disputes | marketplace | intelligence | platform .openapi.yaml
│   ├── paths/                        generated from scripts/build_openapi.py (one endpoint table)
│   └── schemas/                      hand-written schemas
├── dist/
│   ├── openapi/*.bundled.yaml        single-file specs for Swagger UI, Postman, SDK generators
│   └── portal/                       api-reference.html (Redoc) + index.html (all chapters, one page)
├── data-model/
│   ├── schema.sql                    PostgreSQL 16 DDL — 12 schemas, 82 tables/views, invariants, RLS
│   ├── ERD.md                        relationships (Mermaid)
│   ├── DATA-DICTIONARY.md            every column (generated)
│   └── seed-worked-example.sql       posts docs/08 §4 into both ledgers and reconciles
├── config/                           signed-configuration sources, by authority level (see config/README.md)
├── mcp/                              dependency-free MCP server (stdio) + tools.json (44 tools, 4 prompts) + tests
├── skills/                           5 agent skills (SKILL.md) for Claude Code / Agent SDK
├── reference/                        executable model of the lifecycle, order projection and ledgers + tests
├── examples/                         request payloads per industry (validated against the schemas)
└── scripts/                          build_openapi.py, gen_data_dictionary.py, build_portal.py
```

## The answers to the questions in the brief, and where they are

| Question | Answer in |
|---|---|
| A data model for an order with catalog, items, ledger, payments, full lifecycle, QSR/e-retail/retail | [02](docs/02-order-resource.md), [11](docs/11-industry-playbooks.md), `openapi/schemas/orders.yaml`, `commerce` schema |
| The order built on a Payment Intent that covers card, ACH, BNPL and more | [01 §4](docs/01-resource-model.md), [03](docs/03-payment-intent.md), [06](docs/06-order-payment-reflection.md) |
| Attempt resources for authorization, capture and refund | [04](docs/04-operations-and-attempts.md), `openapi/payment-intents.openapi.yaml` |
| The full lifecycle: authorization, expiry, reauth or reversal-then-reauth, single or multiple captures, single or multiple partial refunds, disputes, dispute disposition, pre-dispute | [05](docs/05-payment-lifecycle.md) (with sequence and state diagrams), proven in [`reference/lifecycle.test.ts`](reference/lifecycle.test.ts) |
| How payment lifecycle changes reflect in the order lifecycle | [06](docs/06-order-payment-reflection.md), [`reference/order-projection.ts`](reference/order-projection.ts) |
| Marketplace: two ledgers, sellers, tax liability, dispute pass-through strategies (as Stripe/Adyen do, and beyond) | [08](docs/08-marketplace-and-ledgers.md), `config/marketplace/*`, [`reference/marketplace-ledger.test.ts`](reference/marketplace-ledger.test.ts), `data-model/seed-worked-example.sql` |
| Swagger and PDP docs for orders, payment intents, attempts and the rest | `openapi/`, `dist/portal/api-reference.html`, [12](docs/12-developer-experience.md) |
| MCP server and skills | [13](docs/13-mcp-and-skills.md), `mcp/`, `skills/` |
| Credential intelligence: BIN, issuer, insight signals, predictive cost, early-warning systems, dispute rating, success rate, strategy | [09](docs/09-credential-intelligence.md), `openapi/intelligence.openapi.yaml` |
| NSF signals, registering credentials with networks, notifying merchants to retry | [10](docs/10-nsf-signals-and-retries.md), `config/retry-policy.yaml` |
| The full application data model and its configuration | [14](docs/14-data-model-and-configuration.md), `data-model/`, `config/` |

## How to run and check it

```bash
# From the repository root (Node 22.18+, Python 3 with PyYAML, PostgreSQL 16 optional)
npm install
npm run commerce:test          # 25 tests: lifecycle, order projection, both ledgers, MCP server
npm run commerce:typecheck     # tsc over reference/ and mcp/
npm run commerce:openapi       # regenerate paths + roots from the endpoint table, then lint with Redocly
npm run commerce:portal        # rebuild dist/ (bundled specs, Redoc reference, one-page portal)

# Database
createdb psp && psql -d psp -f commerce-platform/data-model/schema.sql -f commerce-platform/data-model/seed-worked-example.sql

# MCP server (stdio) against the sandbox or the local reference API (npm start)
PSP_API_BASE=http://localhost:4242 PSP_API_KEY=sk_test_... node commerce-platform/mcp/server.ts
```

## Read with care

- **Network, Nacha and tax values** in `config/` are defaults as commonly published. They are flagged `verify_before_production` and must be confirmed with scheme compliance and tax counsel. They change every release cycle.
- **Competitive comparisons** in doc 00 summarize public capabilities and will drift. Re-check them before external use.
- **Network funds-availability notifications**: the API and data model are ready for them, but whether a network offers a push programme for NSF retry timing is a commercial negotiation. Today, Mastercard Merchant Advice Codes, open banking and our own models carry the feature.
- **The reference implementation** makes the rules testable. It is not the production engine.

## Relationship to the rest of this repository

The repository root holds the running PSP platform: vault, decision platform, execution, ledger, evidence and the agentic gateway; see the [root README](../README.md). Its domain already uses the same ten external states and fifteen internal ones (`src/domain/states.ts`), and the same Order → Payment → Attempt nesting. This package is the commerce-grade specification for growing that platform: the full Order, the lifecycle operations, the marketplace ledgers, credential intelligence and the developer surface.
