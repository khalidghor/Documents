# Configuration guide

Configuration is data, not code (ST-003 A15). Every file here is the source of a **versioned, signed document** stored in `config.document` (see `data-model/schema.sql`), published at an **authority level**, and compiled into the execution plans the runtime uses. The runtime never calls a configuration service on the authorization path; it reads the compiled, signed snapshot.

## Authority and precedence

| Level | Authority | Examples here | May |
|---|---|---|---|
| 1 | Regulator | (sanctions, SCA — enforced via the policy platform) | Prohibit / require |
| 2 | Network | `authorization-validity.yaml`, `retry-policy.yaml` | Prohibit / require |
| 3 | PSP | `payment-lifecycle-policy.yaml`, `rails.yaml`, `credential-intelligence.yaml`, `platform.yaml`, `entitlements.yaml`, `order-profiles.yaml` | Set bounds and defaults |
| 4 | Platform | `marketplace/*.yaml`, `dispute-policy.yaml` | Narrow inside levels 1–3; configure its marketplace |
| 5 | PayFac | sub-merchant overrides | Narrow |
| 6 | Merchant | preferences (capture timing, expiry policy, refund mode) | Narrow; choose |
| 7 | Sub-merchant / seller | seller-level preferences | Narrow |
| 8 | Learned strategy | — | Choose inside everything above; never widen |

Lower levels can only **narrow** what higher levels allow. A merchant cannot lengthen an authorization's validity beyond the network rule or retry more often than the network allows.

## Files

| File | Controls | Read by |
|---|---|---|
| [`platform.yaml`](platform.yaml) | PSP legal entities, hosts, API conventions, webhooks, retention, disclosure tiers | Everything |
| [`entitlements.yaml`](entitlements.yaml) | Capability catalog excerpt (verification by scope) and packages | Edge, "can I?" check |
| [`rails.yaml`](rails.yaml) | The seven declarations per rail; legal operations per rail | Lifecycle engine, API validation |
| [`authorization-validity.yaml`](authorization-validity.yaml) | How long each authorization lives; `expires_at` and `expiry_basis` | Lifecycle engine, expiry scheduler |
| [`payment-lifecycle-policy.yaml`](payment-lifecycle-policy.yaml) | Reauthorization, partial authorization, capture (multi, tolerance), reversal, refunds, unknown outcomes, ACH finality | Lifecycle engine |
| [`retry-policy.yaml`](retry-policy.yaml) | Visa decline categories, Mastercard MACs, Amex/Discover limits, Nacha re-presentment, NSF recovery | Retry engine, funds signals |
| [`dispute-policy.yaml`](dispute-policy.yaml) | Response windows, prevention (alerts, RDR, data sharing), evidence, representment, monitoring thresholds | Dispute service |
| [`order-profiles.yaml`](order-profiles.yaml) | Industry defaults: QSR, e-retail, retail, grocery, marketplace, hospitality, services, digital, B2B | Order service |
| [`credential-intelligence.yaml`](credential-intelligence.yaml) | Sources, models, advisory strategy, access and anti-probing | Intelligence service |
| [`marketplace/marketplace.yaml`](marketplace/marketplace.yaml) | Fund flow, liabilities, commission plans, payouts, reserves, holds, negative balances | Allocation engine, payouts |
| [`marketplace/dispute-allocation-rules.yaml`](marketplace/dispute-allocation-rules.yaml) | Who bears each dispute, who responds, fees, holds | Dispute allocation |
| [`marketplace/tax-responsibility.yaml`](marketplace/tax-responsibility.yaml) | Liability regimes per jurisdiction, engine adapter, information reporting | Tax determination |

## Lifecycle of a configuration change

1. Edit the file (or the equivalent API object) → **draft** version.
2. **Validate**: schema, conflicts across authority levels (a lower level widening a higher one is a compile error), dependencies (a capability's dependencies must be entitled).
3. **Simulate**: for rule sets with money consequences (dispute allocation, retry, reauthorization), replay recent traffic and show the diff.
4. **Approve** by change tier (ST-001 §06): mechanical below T6; emergency and irreversible changes stay human.
5. **Publish**: signed, versioned, pushed to the runtime; exposure by predicate (canary → ramp → stable); rollback by pointer.
6. **Measure**: where the change is a strategy choice, against the holdout.

## Values marked `verify_before_production`

Network, Nacha and tax values in these files are reasonable defaults as commonly published, **not** a legal or scheme-compliance opinion. They change frequently. Each must be confirmed against the current rule books (and by tax counsel for tax regimes) and re-verified on every network release cycle.
