#!/usr/bin/env python3
"""Generate the OpenAPI path files and per-domain root documents from one endpoint table.

Schemas are hand-written in openapi/schemas/*.yaml. Paths are generated here so that every
endpoint gets the same conventions: Idempotency-Key on every POST, standard error responses,
pagination on lists, tags, and operationIds. Run:

    python3 commerce-platform/scripts/build_openapi.py

then lint/bundle with Redocly (see commerce-platform/README.md).
"""
import os
import re
import sys

import yaml

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "openapi")

# (domain, method, path, operationId, tag, summary, request_schema, response_schema, status, extra)
# schema refs are "file#Name" relative to openapi/schemas.  extra: dict with keys
#   list=True (pagination), query=[...] (extra query params), pci=True (PCI host),
#   money=True (moves money), sandbox=True, desc="..."
E = []


def ep(domain, method, path, op_id, tag, summary, req=None, resp=None, status="200", **extra):
    E.append(dict(domain=domain, method=method, path=path, op_id=op_id, tag=tag, summary=summary,
                  req=req, resp=resp, status=status, extra=extra))


O, P, D, M, I, X = "orders", "payment-intents", "disputes", "marketplace", "intelligence", "platform"

# ---------------------------------------------------------------- Orders & catalog
ep(O, "post", "/v1/orders", "createOrder", "Orders", "Create an order (draft, or placed with place=true)",
   "orders#OrderCreate", "orders#Order", "201",
   desc="Creates the commercial transaction. Prices and tax codes are snapshotted from the catalog onto the lines. "
        "With `place: true` the collection plan runs immediately and Payment Intents are created as it requires.")
ep(O, "get", "/v1/orders", "listOrders", "Orders", "List orders", None, "orders#OrderList", list=True,
   query=["status", "payment_status", "fulfillment_status", "customer", "seller_id", "channel.type"])
ep(O, "get", "/v1/orders/{order_id}", "getOrder", "Orders", "Retrieve an order", None, "orders#Order")
ep(O, "post", "/v1/orders/{order_id}/place", "placeOrder", "Orders", "Place a draft order and run its collection plan",
   None, "orders#Order",
   desc="Locks the lines, computes tax, derives seller orders, and creates the Payment Intent(s) the collection plan "
        "requires. Returns the order with `payments[]`; a payment needing customer action carries `next_action`.")
ep(O, "post", "/v1/orders/{order_id}/amend", "amendOrder", "Orders",
   "Amend a placed order (cancel/add/update lines, tips, fulfillment)", "orders#OrderAmend", "orders#Order", if_match=True,
   desc="Creates a new order version. `payment_adjustment: auto` performs the needed partial reversal, incremental "
        "authorization, new Payment Intent or refund.")
ep(O, "post", "/v1/orders/{order_id}/cancel", "cancelOrder", "Orders", "Cancel an order", None, "orders#Order", money=True,
   desc="Reverses uncaptured authorizations and refunds captured amounts per the cancellation policy.")
ep(O, "post", "/v1/orders/{order_id}/close", "closeOrder", "Orders",
   "Close an open check (QSR / hospitality) — adds tip and captures", None, "orders#Order", money=True)
ep(O, "post", "/v1/orders/{order_id}/fulfillments/{fulfillment_group_id}/ship", "shipFulfillment", "Fulfillment",
   "Record a shipment; captures per the group's capture trigger", "orders#Shipment", "orders#Order", money=True)
ep(O, "post", "/v1/orders/{order_id}/fulfillments/{fulfillment_group_id}/complete", "completeFulfillment",
   "Fulfillment", "Complete a fulfillment group (handover, delivery)", None, "orders#Order", money=True)
ep(O, "post", "/v1/orders/{order_id}/returns", "createReturn", "Returns", "Create a return (RMA) for order lines",
   "orders#ReturnCreate", "orders#OrderReturn", "201")
ep(O, "post", "/v1/orders/{order_id}/returns/{return_id}/receive", "receiveReturn", "Returns",
   "Receive a return; executes the refund plan if refund_on=receipt", None, "orders#OrderReturn", money=True)
ep(O, "get", "/v1/orders/{order_id}/timeline", "getOrderTimeline", "Orders", "Order timeline with causes", None,
   "orders#Order")
ep(O, "post", "/v1/catalog/products", "createProduct", "Catalog", "Create a product", "orders#Product", "orders#Product", "201")
ep(O, "get", "/v1/catalog/products", "listProducts", "Catalog", "Search products", None, "orders#Product", list=True,
   query=["query", "seller_id", "location_id", "channel"])
ep(O, "get", "/v1/catalog/products/{product_id}", "getProduct", "Catalog", "Retrieve a product", None, "orders#Product")
ep(O, "post", "/v1/catalog/price_books", "createPriceBook", "Catalog", "Create a price book", "orders#PriceBook",
   "orders#PriceBook", "201")
ep(O, "post", "/v1/catalog/quotes", "quoteBasket", "Catalog", "Price and tax a basket without creating an order",
   "orders#OrderCreate", "orders#PriceQuote")

# ---------------------------------------------------------------- Payment Intents
ep(P, "post", "/v1/payment_intents", "createPaymentIntent", "Payment Intents", "Create a Payment Intent",
   "payment-intents#PaymentIntentCreate", "payment-intents#PaymentIntent", "201")
ep(P, "get", "/v1/payment_intents", "listPaymentIntents", "Payment Intents", "List Payment Intents", None,
   "payment-intents#PaymentIntentList", list=True, query=["status", "order_id", "customer", "on_behalf_of"])
ep(P, "get", "/v1/payment_intents/{payment_intent_id}", "getPaymentIntent", "Payment Intents",
   "Retrieve a Payment Intent", None, "payment-intents#PaymentIntent")
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/confirm", "confirmPaymentIntent", "Payment Intents",
   "Confirm (authorize, charge or debit)", "payment-intents#ConfirmRequest", "payment-intents#PaymentIntent", money=True,
   desc="Creates an `authorize`, `charge` or `debit` operation. Also re-confirms a `failed` intent whose "
        "`last_result.retryability.retryable` is true.")
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/capture", "capturePaymentIntent", "Payment Intents",
   "Capture (single, partial or multi-capture)", "payment-intents#CaptureRequest", "payment-intents#PaymentIntent",
   money=True, desc="`final_capture: false` keeps the remainder capturable; a final capture releases it.")
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/increment_authorization", "incrementAuthorization",
   "Payment Intents", "Incremental authorization", "payment-intents#IncrementRequest", "payment-intents#PaymentIntent",
   money=True)
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/reauthorize", "reauthorizePaymentIntent", "Payment Intents",
   "Reauthorize the capturable remainder before or after expiry", "payment-intents#ReauthorizeRequest",
   "payment-intents#PaymentIntent", money=True,
   desc="Mode `reauth_then_reverse` keeps a hold at all times; `reverse_then_reauth` never double-holds (debit, "
        "prepaid). Requires stored-credential consent; sent as a merchant-initiated transaction.")
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/reverse", "reversePaymentIntent", "Payment Intents",
   "Full or partial authorization reversal", "payment-intents#ReverseRequest", "payment-intents#PaymentIntent", money=True)
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/cancel", "cancelPaymentIntent", "Payment Intents",
   "Cancel (void) a Payment Intent", "payment-intents#CancelRequest", "payment-intents#PaymentIntent", money=True)
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/amend", "amendPaymentIntent", "Payment Intents",
   "Amend the intent (new intent_version)", "payment-intents#AmendRequest", "payment-intents#PaymentIntent")
ep(P, "post", "/v1/payment_intents/{payment_intent_id}/refunds", "createRefund", "Refunds",
   "Refund (one of many partial refunds, or full)", "payment-intents#RefundRequest", "payment-intents#Operation", "201",
   money=True, desc="Draws on a specific capture for multi-capture intents. Rejected with `refund_blocked_by_dispute` "
                    "for amounts under open dispute; converted to a reversal before capture.")
ep(P, "get", "/v1/payment_intents/{payment_intent_id}/refunds", "listRefunds", "Refunds", "List refunds", None,
   "payment-intents#OperationList", list=True)
ep(P, "get", "/v1/payment_intents/{payment_intent_id}/operations", "listOperations", "Operations & Attempts",
   "List operations (authorize, capture, refund, …)", None, "payment-intents#OperationList", list=True,
   query=["type", "status"])
ep(P, "get", "/v1/payment_intents/{payment_intent_id}/operations/{operation_id}", "getOperation",
   "Operations & Attempts", "Retrieve an operation", None, "payment-intents#Operation")
ep(P, "get", "/v1/payment_intents/{payment_intent_id}/attempts", "listAttempts", "Operations & Attempts",
   "List attempts (written only by the platform)", None, "payment-intents#AttemptList", list=True,
   query=["operation", "outcome"])
ep(P, "get", "/v1/payment_intents/{payment_intent_id}/decisions", "listDecisions", "Operations & Attempts",
   "Why and why not: decision explanations per attempt", None, "payment-intents#DecisionExplanation")

# ---------------------------------------------------------------- Disputes
ep(D, "get", "/v1/disputes", "listDisputes", "Disputes", "List disputes", None, "disputes#DisputeList", list=True,
   query=["status", "stage", "payment_intent", "order_id", "seller_id", "reason.category"])
ep(D, "get", "/v1/disputes/{dispute_id}", "getDispute", "Disputes", "Retrieve a dispute", None, "disputes#Dispute")
ep(D, "post", "/v1/disputes/{dispute_id}/evidence", "submitDisputeEvidence", "Disputes",
   "Save or submit evidence", "disputes#DisputeEvidenceSubmit", "disputes#Dispute")
ep(D, "post", "/v1/disputes/{dispute_id}/accept", "acceptDispute", "Disputes", "Accept (concede) a dispute",
   "disputes#DisputeAccept", "disputes#Dispute", money=True)
ep(D, "post", "/v1/disputes/{dispute_id}/request_seller_evidence", "requestSellerEvidence", "Disputes",
   "Ask the liable seller for evidence (marketplaces)", "disputes#DisputeSellerEvidenceRequest", "disputes#Dispute")
ep(D, "get", "/v1/dispute_alerts", "listDisputeAlerts", "Dispute Alerts", "List pre-dispute alerts", None,
   "disputes#DisputeAlertList", list=True, query=["status", "source", "payment_intent"])
ep(D, "get", "/v1/dispute_alerts/{dispute_alert_id}", "getDisputeAlert", "Dispute Alerts", "Retrieve an alert", None,
   "disputes#DisputeAlert")
ep(D, "post", "/v1/dispute_alerts/{dispute_alert_id}/resolve", "resolveDisputeAlert", "Dispute Alerts",
   "Resolve an alert (refund, decline, share data)", "disputes#DisputeAlertResolve", "disputes#DisputeAlert", money=True)

# ---------------------------------------------------------------- Marketplace
ep(M, "post", "/v1/sellers", "createSeller", "Sellers", "Create a seller or sub-merchant", "marketplace#SellerCreate",
   "marketplace#Seller", "201")
ep(M, "get", "/v1/sellers", "listSellers", "Sellers", "List sellers", None, "marketplace#SellerList", list=True,
   query=["status", "role"])
ep(M, "get", "/v1/sellers/{seller_id}", "getSeller", "Sellers", "Retrieve a seller", None, "marketplace#Seller")
ep(M, "post", "/v1/sellers/{seller_id}", "updateSeller", "Sellers", "Update a seller", "marketplace#SellerCreate",
   "marketplace#Seller")
ep(M, "get", "/v1/sellers/{seller_id}/balance", "getSellerBalance", "Ledgers & Balances", "Seller balance", None,
   "marketplace#Balance")
ep(M, "post", "/v1/allocations/preview", "previewAllocation", "Allocations",
   "Preview how a capture, refund or lost dispute would allocate", "marketplace#AllocationPreviewRequest",
   "marketplace#Allocation")
ep(M, "get", "/v1/allocations/{allocation_id}", "getAllocation", "Allocations", "Retrieve an allocation", None,
   "marketplace#Allocation")
ep(M, "get", "/v1/ledgers/{ledger}/accounts", "listLedgerAccounts", "Ledgers & Balances",
   "List ledger accounts (acquiring | commerce)", None, "marketplace#LedgerAccount", list=True, query=["book", "party"])
ep(M, "get", "/v1/ledgers/{ledger}/entries", "listJournalEntries", "Ledgers & Balances", "List journal entries", None,
   "marketplace#JournalEntryList", list=True, query=["book", "order_id", "payment_intent", "seller_id", "event"])
ep(M, "get", "/v1/ledgers/reconciliation", "getReconciliation", "Ledgers & Balances",
   "Control-account reconciliation between the two ledgers", None, "marketplace#ReconciliationStatus", query=["book"])
ep(M, "post", "/v1/transfers", "createTransfer", "Transfers & Payouts", "Transfer between commerce-ledger parties",
   "marketplace#TransferCreate", "marketplace#Transfer", "201", money=True)
ep(M, "post", "/v1/transfers/{transfer_id}/reversals", "reverseTransfer", "Transfers & Payouts", "Reverse a transfer",
   "marketplace#TransferCreate", "marketplace#Transfer", money=True)
ep(M, "get", "/v1/payouts", "listPayouts", "Transfers & Payouts", "List payouts", None, "marketplace#PayoutList",
   list=True, query=["party", "status"])
ep(M, "get", "/v1/dispute_allocation_rules", "getDisputeAllocationRules", "Dispute Allocation",
   "Current dispute allocation rule set", None, "marketplace#DisputeAllocationRuleSet")
ep(M, "post", "/v1/dispute_allocation_rules", "publishDisputeAllocationRules", "Dispute Allocation",
   "Publish a new rule set version (signed)", "marketplace#DisputeAllocationRuleSet", "marketplace#DisputeAllocationRuleSet",
   "201")
ep(M, "post", "/v1/dispute_allocation_rules/simulate", "simulateDisputeAllocationRules", "Dispute Allocation",
   "Replay past disputes under a proposed rule set", "marketplace#RuleSimulationRequest", "marketplace#RuleSimulationResult")

# ---------------------------------------------------------------- Intelligence
ep(I, "post", "/v1/credential_insights", "createCredentialInsight", "Credential Intelligence",
   "Insight for a payment method, token, fingerprint or BIN", "intelligence#CredentialInsightRequest",
   "intelligence#CredentialInsight", "201", desc="PANs are rejected on this host (`pan_not_allowed`). Use the PCI host.")
ep(I, "post", "/pci/v1/credential_insights", "createCredentialInsightPci", "Credential Intelligence",
   "Insight for a PAN (PCI host only)", "intelligence#PciCredentialInsightRequest", "intelligence#CredentialInsight",
   "201", pci=True)
ep(I, "get", "/v1/credential_insights/{insight_id}", "getCredentialInsight", "Credential Intelligence",
   "Retrieve an insight", None, "intelligence#CredentialInsight")
ep(I, "get", "/v1/bins/{bin}", "getBin", "Credential Intelligence", "BIN lookup (6–8 digits)", None,
   "intelligence#BinInfo")
ep(I, "post", "/v1/credential_registrations", "createCredentialRegistration", "Funds Signals & Retries",
   "Register a credential for funds and lifecycle signals", "intelligence#CredentialRegistrationCreate",
   "intelligence#CredentialRegistration", "201")
ep(I, "get", "/v1/credential_registrations/{registration_id}", "getCredentialRegistration",
   "Funds Signals & Retries", "Retrieve a registration", None, "intelligence#CredentialRegistration")
ep(I, "post", "/v1/credential_registrations/{registration_id}/cancel", "cancelCredentialRegistration",
   "Funds Signals & Retries", "Cancel a registration", None, "intelligence#CredentialRegistration")
ep(I, "get", "/v1/funds_signals", "listFundsSignals", "Funds Signals & Retries", "List funds signals", None,
   "intelligence#FundsSignalList", list=True, query=["payment_method", "registration", "type"])
ep(I, "get", "/v1/payment_intents/{payment_intent_id}/retry_recommendation", "getRetryRecommendation",
   "Funds Signals & Retries", "Should this failed intent be retried, and when?", None, "intelligence#RetryRecommendation")

# ---------------------------------------------------------------- Platform (events, capabilities, sandbox)
ep(X, "post", "/v1/capabilities/check", "canI", "Capabilities", "The \"can I?\" check across the five planes",
   "payment-intents#CapabilityCheck", "payment-intents#CapabilityAnswer")
ep(X, "get", "/v1/events", "listEvents", "Events & Webhooks", "List events", None, "events#EventList", list=True,
   query=["type", "related_object"])
ep(X, "get", "/v1/events/{event_id}", "getEvent", "Events & Webhooks", "Retrieve an event", None, "events#Event")
ep(X, "post", "/v1/events/{event_id}/redeliver", "redeliverEvent", "Events & Webhooks", "Redeliver (replay) an event",
   None, "events#Event")
ep(X, "post", "/v1/webhook_endpoints", "createWebhookEndpoint", "Events & Webhooks", "Create a webhook endpoint",
   "events#WebhookEndpointCreate", "events#WebhookEndpoint", "201")
ep(X, "post", "/v1/test_helpers/test_clocks", "createTestClock", "Test Helpers", "Create a test clock",
   "events#TestClockCreate", "events#TestClock", "201", sandbox=True)
ep(X, "post", "/v1/test_helpers/test_clocks/{clock_id}/advance", "advanceTestClock", "Test Helpers",
   "Advance a test clock (fires expiry, reauthorization, settlement, dispute windows)", "events#TestClockAdvance",
   "events#TestClock", sandbox=True)
ep(X, "post", "/v1/test_helpers/payment_intents/{payment_intent_id}/dispute", "simulateDispute", "Test Helpers",
   "Simulate a dispute", "events#SimulateDispute", "events#SimulationAck", sandbox=True)
ep(X, "post", "/v1/test_helpers/dispute_alerts", "simulateDisputeAlert", "Test Helpers", "Simulate a pre-dispute alert",
   "events#SimulateAlert", "events#SimulationAck", sandbox=True)
ep(X, "post", "/v1/test_helpers/payment_intents/{payment_intent_id}/ach_return", "simulateAchReturn", "Test Helpers",
   "Simulate an ACH return", "events#SimulateAchReturn", "events#SimulationAck", sandbox=True)
ep(X, "post", "/v1/test_helpers/credential_registrations/{registration_id}/signal", "simulateFundsSignal",
   "Test Helpers", "Simulate a funds signal", "events#SimulateFundsSignal", "events#SimulationAck", sandbox=True)

DOMAINS = {
    O: ("Orders & Catalog API", "The commercial transaction: catalog, orders, line items, fulfillment, returns. "
        "Built on Payment Intents; never moves money itself. See docs/02 and docs/06."),
    P: ("Payment Intents API", "One durable obligation to collect, any method, ten states; operations (authorize, "
        "reauthorize, capture, reverse, refund) and attempts. See docs/03–05."),
    D: ("Disputes API", "Disputes and pre-dispute alerts, evidence, acceptance, marketplace seller evidence. See docs/07."),
    M: ("Marketplace & Ledgers API", "Sellers, allocations, the acquiring and commerce ledgers, transfers, payouts and "
        "dispute allocation rules. See docs/08."),
    I: ("Credential Intelligence API", "Credential insights (BIN, issuer, cost, risk, disputes, approval, strategy), "
        "credential registrations and funds signals for NSF recovery. See docs/09–10."),
    X: ("Platform API", "Capabilities (\"can I?\"), events and webhooks, and sandbox test helpers. See docs/12."),
}

TAG_DESCRIPTIONS = {
    "Orders": "The commercial transaction and its five statuses (docs/02).",
    "Fulfillment": "Fulfillment groups and shipments; captures follow the capture trigger.",
    "Returns": "RMAs, refund plans and exchanges.",
    "Catalog": "Products, variants, modifiers, price books and basket quotes.",
    "Payment Intents": "One durable obligation to collect, any method, ten states (docs/03).",
    "Refunds": "Refund operations: many partial refunds per capture (docs/05 §7).",
    "Operations & Attempts": "Instructions and their dispatches, with exec_id and decision_ref (docs/04).",
    "Disputes": "Chargebacks, ACH unauthorized returns and BNPL disputes (docs/07).",
    "Dispute Alerts": "Pre-dispute alerts and inquiries: Ethoca, CDRN, RDR, Order Insight (docs/05 §8).",
    "Sellers": "Marketplace sellers and PayFac sub-merchants with liability settings (docs/08).",
    "Allocations": "Who earns what share of each capture, refund or dispute.",
    "Ledgers & Balances": "The acquiring ledger and the commerce ledger, and their reconciliation.",
    "Transfers & Payouts": "Movements between parties and out to bank accounts.",
    "Dispute Allocation": "Rules deciding who bears a dispute, simulated before publication.",
    "Credential Intelligence": "BIN, issuer, cost, risk, dispute, approval and strategy insight (docs/09).",
    "Funds Signals & Retries": "Credential registration, funds signals and NSF retry recommendations (docs/10).",
    "Capabilities": "The five planes, queryable: can I?",
    "Events & Webhooks": "Signed, at-least-once events with causes; replay.",
    "Test Helpers": "Sandbox clocks and simulators for time-dependent lifecycles.",
}

WEBHOOK_EVENTS = [
    "order.confirmed", "order.payment_exception", "order.completed", "order.dispute_updated",
    "payment_intent.authorized", "payment_intent.authorization_expiring", "payment_intent.reauthorized",
    "payment_intent.authorization_expired", "payment_intent.partially_captured", "payment_intent.captured",
    "payment_intent.payment_failed", "payment_intent.retry_scheduled", "payment_intent.refund.succeeded",
    "payment_intent.refund.failed", "payment_intent.disputed", "payment_intent.dispute.closed",
    "payment_intent.ach_return", "dispute_alert.created", "dispute.created", "dispute.won", "dispute.lost",
    "seller.negative_balance", "payout.paid", "credential.funds_signal", "credential.updated",
]


def key_for(path):
    return re.sub(r"[^a-zA-Z0-9]+", "_", path.strip("/")).strip("_")


def schema_ref(spec, from_dir):
    f, name = spec.split("#")
    return {"$ref": f"{from_dir}schemas/{f}.yaml#/schemas/{name}"}


def common(kind, name, from_dir):
    return {"$ref": f"{from_dir}schemas/common.yaml#/{kind}/{name}"}


def build_operation(e):
    fd = "../"
    params = []
    for p in re.findall(r"{([a-z_]+)}", e["path"]):
        params.append({"name": p, "in": "path", "required": True, "schema": {"type": "string"}})
    if e["method"] == "post":
        params.append(common("parameters", "IdempotencyKey", fd))
    params.append(common("parameters", "ApiVersion", fd))
    params.append(common("parameters", "OnBehalfOf", fd))
    if e["extra"].get("if_match"):
        params.append(common("parameters", "IfMatch", fd))
    if e["method"] == "get":
        params.append(common("parameters", "Expand", fd))
    if e["extra"].get("list"):
        for n in ("Limit", "StartingAfter", "EndingBefore", "CreatedGte", "CreatedLt"):
            params.append(common("parameters", n, fd))
    for q in e["extra"].get("query", []):
        params.append({"name": q, "in": "query", "required": False, "schema": {"type": "string"}})
    op = {"operationId": e["op_id"], "tags": [e["tag"]], "summary": e["summary"]}
    desc = e["extra"].get("desc", "")
    notes = []
    if e["extra"].get("money"):
        notes.append("**Moves money.** Idempotent by `Idempotency-Key`; the MCP server requires `confirm: true`.")
    if e["extra"].get("sandbox"):
        notes.append("**Sandbox only** (`sk_test_` keys).")
    if e["extra"].get("pci"):
        notes.append("**PCI host only:** `https://pci.example-psp.com`.")
        op["servers"] = [{"url": "https://pci.example-psp.com", "description": "PCI host"}]
    if desc or notes:
        op["description"] = "\n\n".join([d for d in [desc] + notes if d])
    op["parameters"] = params
    if e["req"]:
        op["requestBody"] = {"required": True, "content": {"application/json": {"schema": schema_ref(e["req"], fd)}}}
    responses = {}
    if e["resp"]:
        responses[e["status"]] = {"description": "OK" if e["status"] == "200" else "Created",
                                  "content": {"application/json": {"schema": schema_ref(e["resp"], fd)}}}
    else:
        responses[e["status"]] = {"description": "OK"}
    responses["400"] = common("responses", "BadRequest", fd)
    responses["401"] = common("responses", "Unauthorized", fd)
    if "{" in e["path"]:
        responses["404"] = common("responses", "NotFound", fd)
    if e["method"] == "post":
        responses["409"] = common("responses", "Conflict", fd)
    if e["extra"].get("money"):
        responses["402"] = common("responses", "PaymentError", fd)
    responses["429"] = common("responses", "RateLimited", fd)
    op["responses"] = responses
    return op


def main():
    by_domain = {}
    for e in E:
        by_domain.setdefault(e["domain"], {}).setdefault(e["path"], {})[e["method"]] = build_operation(e)
    os.makedirs(os.path.join(ROOT, "paths"), exist_ok=True)
    for domain, paths in by_domain.items():
        doc = {key_for(p): item for p, item in paths.items()}
        with open(os.path.join(ROOT, "paths", f"{domain}.yaml"), "w") as fh:
            fh.write(f"# GENERATED by scripts/build_openapi.py — edit the endpoint table there, not this file.\n")
            yaml.safe_dump(doc, fh, sort_keys=False, width=120, allow_unicode=True)

    def root(domains, title, description, filename):
        tags, seen = [], set()
        for e in E:
            if e["domain"] in domains and e["tag"] not in seen:
                seen.add(e["tag"])
                tags.append({"name": e["tag"], "description": TAG_DESCRIPTIONS[e["tag"]]})
        doc = {
            "openapi": "3.1.0",
            "info": {"title": title, "version": "2026-11-15", "description": description,
                     "contact": {"name": "Payments Developer Portal"},
                     "license": {"name": "Proprietary", "identifier": "LicenseRef-Proprietary"}},
            "servers": [{"url": "https://api.example-psp.com", "description": "Live"},
                        {"url": "https://sandbox.api.example-psp.com", "description": "Sandbox"},
                        {"url": "http://localhost:4242", "description": "Local reference server"}],
            "security": [{"bearerAuth": []}],
            "tags": tags,
            "paths": {},
            "components": {"securitySchemes": {"bearerAuth": {"type": "http", "scheme": "bearer",
                                                              "description": "sk_live_… / sk_test_… / restricted keys"}}},
        }
        for e in E:
            if e["domain"] in domains:
                doc["paths"].setdefault(e["path"], {"$ref": f"paths/{e['domain']}.yaml#/{key_for(e['path'])}"})
        if P in domains or len(domains) > 1:
            doc["webhooks"] = {
                ev: {"post": {"summary": f"{ev} webhook", "operationId": "webhook_" + key_for(ev),
                              "tags": ["Events & Webhooks"] if X in domains else [tags[0]["name"]],
                              "requestBody": {"content": {"application/json": {
                                  "schema": {"$ref": "schemas/events.yaml#/schemas/Event"}}}},
                              "responses": {"200": {"description": "Acknowledge within 10 seconds"}}}}
                for ev in WEBHOOK_EVENTS}
        with open(os.path.join(ROOT, filename), "w") as fh:
            fh.write("# GENERATED by scripts/build_openapi.py\n")
            yaml.safe_dump(doc, fh, sort_keys=False, width=120, allow_unicode=True)

    for domain, (title, desc) in DOMAINS.items():
        root({domain}, f"PSP {title}", desc, f"{domain}.openapi.yaml")
    root(set(DOMAINS), "PSP Commerce Platform API (all domains)",
         "Orders, Payment Intents, operations and attempts, disputes, marketplace ledgers, credential intelligence "
         "and the platform API in one document.", "psp.openapi.yaml")
    print(f"{len(E)} endpoints across {len(by_domain)} domains")


if __name__ == "__main__":
    sys.exit(main())
