#!/usr/bin/env python3
"""Build dist/portal/index.html — every chapter of docs/ on one navigable page (the PDP's guide half).

The API reference half (dist/portal/api-reference.html) is built by Redocly from openapi/psp.openapi.yaml.
Requires: pip install markdown
"""
import html
import os
import re

import markdown

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
DOCS = os.path.join(ROOT, "docs")
OUT = os.path.join(ROOT, "dist", "portal", "index.html")


def render(md_text):
    # Mermaid fences become <pre class="mermaid"> so the browser renders diagrams.
    blocks = []

    def keep(m):
        blocks.append(m.group(1))
        return f"\n\nMERMAIDBLOCK{len(blocks) - 1}\n\n"

    md_text = re.sub(r"```mermaid\n(.*?)```", keep, md_text, flags=re.S)
    # Links between chapters point at anchors on this page.
    md_text = re.sub(r"\]\((\d\d-[a-z0-9-]+)\.md(#[^)]*)?\)", lambda m: f"](#{m.group(1)})", md_text)
    md_text = re.sub(r"\]\(\.\./([^)]+)\)", lambda m: f"](../../{m.group(1)})", md_text)
    out = markdown.markdown(md_text, extensions=["tables", "fenced_code", "sane_lists"])
    for i, b in enumerate(blocks):
        out = out.replace(f"<p>MERMAIDBLOCK{i}</p>", f'<pre class="mermaid">{html.escape(b)}</pre>')
    return out


def main():
    chapters = sorted(f for f in os.listdir(DOCS) if f.endswith(".md"))
    nav, body = [], []
    for f in chapters:
        slug = f[:-3]
        text = open(os.path.join(DOCS, f), encoding="utf-8").read()
        title = re.search(r"^# (.+)$", text, re.M).group(1)
        nav.append(f'<a href="#{slug}">{html.escape(title)}</a>')
        body.append(f'<section id="{slug}">{render(text)}</section>')
    page = TEMPLATE.replace("{{NAV}}", "\n".join(nav)).replace("{{BODY}}", "\n".join(body))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write(page)
    print(f"wrote {OUT} ({len(chapters)} chapters)")


TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PSP Developer Portal</title>
<style>
:root { --bg:#fbfbfa; --fg:#1d1d1f; --muted:#5f6368; --line:#e3e3e0; --accent:#2f5bd3; --code:#f2f2ef; --nav:#f4f4f1; }
@media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { --bg:#141416; --fg:#e8e8ea; --muted:#a0a0a8; --line:#2c2c31; --accent:#8fa8ff; --code:#1e1e22; --nav:#1a1a1d; } }
:root[data-theme="dark"] { --bg:#141416; --fg:#e8e8ea; --muted:#a0a0a8; --line:#2c2c31; --accent:#8fa8ff; --code:#1e1e22; --nav:#1a1a1d; }
* { box-sizing: border-box; }
body { margin:0; background:var(--bg); color:var(--fg); font:15px/1.6 -apple-system, "Segoe UI", Inter, Roboto, sans-serif; }
nav { position:fixed; top:0; left:0; bottom:0; width:280px; overflow:auto; background:var(--nav); border-right:1px solid var(--line); padding:20px 16px; }
nav h1 { font-size:16px; margin:0 0 4px; } nav p { color:var(--muted); font-size:13px; margin:0 0 16px; }
nav a { display:block; color:var(--fg); text-decoration:none; font-size:13.5px; padding:5px 8px; border-radius:6px; }
nav a:hover { background:var(--line); }
nav .ref { margin-top:16px; border-top:1px solid var(--line); padding-top:12px; }
main { margin-left:280px; max-width:1060px; padding:24px 40px 80px; }
section { border-bottom:1px solid var(--line); padding-bottom:32px; margin-bottom:32px; }
h1 { font-size:28px; line-height:1.25; } h2 { font-size:21px; margin-top:32px; } h3 { font-size:17px; }
a { color:var(--accent); }
blockquote { margin:0; padding:8px 16px; border-left:3px solid var(--accent); color:var(--muted); }
table { border-collapse:collapse; width:100%; display:block; overflow-x:auto; font-size:13.5px; margin:12px 0; }
th, td { border:1px solid var(--line); padding:6px 9px; text-align:left; vertical-align:top; }
th { background:var(--nav); }
code { background:var(--code); padding:1px 5px; border-radius:4px; font-size:12.5px; }
pre { background:var(--code); padding:12px 14px; border-radius:8px; overflow-x:auto; font-size:12.5px; line-height:1.45; }
pre code { background:none; padding:0; }
pre.mermaid { background:transparent; text-align:center; }
@media (max-width: 860px) { nav { position:static; width:auto; border-right:none; border-bottom:1px solid var(--line); } main { margin-left:0; padding:16px; } }
</style>
</head>
<body>
<nav>
<h1>PSP Developer Portal</h1>
<p>Orders · Payment Intents · Lifecycle · Marketplace ledgers · Credential intelligence</p>
{{NAV}}
<div class="ref"><a href="api-reference.html">API reference (OpenAPI) →</a></div>
</nav>
<main>
{{BODY}}
</main>
<script type="module">
import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11.4.1/dist/mermaid.esm.min.mjs";
const dark = matchMedia("(prefers-color-scheme: dark)").matches;
mermaid.initialize({ startOnLoad: true, theme: dark ? "dark" : "neutral", securityLevel: "strict" });
</script>
</body>
</html>
"""

if __name__ == "__main__":
    main()
