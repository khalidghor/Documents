#!/usr/bin/env python3
"""Generate data-model/DATA-DICTIONARY.md from a database with schema.sql loaded.

    python3 commerce-platform/scripts/gen_data_dictionary.py "host=/tmp/pg port=5499 user=postgres dbname=psp"

Uses psql (no Python driver needed).
"""
import os
import subprocess
import sys

SCHEMAS = ["tenancy", "catalog", "customer", "commerce", "payments", "disputes", "ledger", "marketplace", "tax",
           "intelligence", "config", "platform"]


def q(dsn, sql):
    out = subprocess.run(["psql", dsn, "-AtF", "\t", "-c", sql], check=True, capture_output=True, text=True).stdout
    return [line.split("\t") for line in out.splitlines() if line]


def main():
    dsn = sys.argv[1]
    here = os.path.dirname(os.path.abspath(__file__))
    out = ["# Data dictionary", "",
           "Generated from `schema.sql` by `scripts/gen_data_dictionary.py`. Do not edit by hand.", ""]
    tables = q(dsn, """
      select n.nspname, c.relname, coalesce(obj_description(c.oid), '')
      from pg_class c join pg_namespace n on n.oid = c.relnamespace
      where c.relkind in ('r','v') and n.nspname = any(string_to_array('%s', ','))
      order by array_position(string_to_array('%s', ','), n.nspname::text), c.relname""" % (",".join(SCHEMAS), ",".join(SCHEMAS)))
    out.append(f"{len(tables)} tables and views across {len(SCHEMAS)} schemas.\n")
    current = None
    for schema, table, comment in tables:
        if schema != current:
            out += [f"## `{schema}`", ""]
            current = schema
        out += [f"### `{schema}.{table}`", ""]
        if comment:
            out += [comment, ""]
        cols = q(dsn, f"""
          select a.attname, format_type(a.atttypid, a.atttypmod), case when a.attnotnull then 'NOT NULL' else '' end,
                 coalesce(col_description(a.attrelid, a.attnum), ''),
                 coalesce((select string_agg(distinct ccu.table_schema || '.' || ccu.table_name, ', ')
                   from information_schema.key_column_usage kcu
                   join information_schema.constraint_column_usage ccu on ccu.constraint_name = kcu.constraint_name
                   join information_schema.table_constraints tc on tc.constraint_name = kcu.constraint_name
                   where tc.constraint_type = 'FOREIGN KEY' and kcu.table_schema = '{schema}'
                     and kcu.table_name = '{table}' and kcu.column_name = a.attname), '')
          from pg_attribute a
          where a.attrelid = '{schema}."{table}"'::regclass and a.attnum > 0 and not a.attisdropped
          order by a.attnum""")
        out += ["| Column | Type | Null | References | Note |", "|---|---|---|---|---|"]
        for name, typ, nn, note, ref in cols:
            out.append(f"| `{name}` | {typ} | {nn} | {ref} | {note} |")
        out.append("")
    path = os.path.join(here, "..", "data-model", "DATA-DICTIONARY.md")
    with open(path, "w") as fh:
        fh.write("\n".join(out))
    print(f"wrote {path}: {len(tables)} tables/views")


if __name__ == "__main__":
    main()
