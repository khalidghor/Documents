/**
 * Reference model of the Payment Intent lifecycle (docs/05). In-memory and deterministic: issuer and
 * rail responses are passed in by the caller, time comes from the caller. It exists to make the rules in
 * the documents executable and tested — it is not the production engine.
 *
 * Rules encoded here (docs/04 §4, docs/05 §12):
 *  - status is DERIVED from authorizations, captures, refunds and disputes — never set by hand, so a won
 *    dispute restores the prior state by construction;
 *  - captures draw on a live authorization; capture after expiry is blocked;
 *  - a final capture releases the remainder (partial reversal);
 *  - refunds are per capture and can never touch an amount under open dispute;
 *  - reauthorization is a new operation on the same intent, in one of two modes;
 *  - ACH is captured on acceptance and carries a finality block (D86).
 */

export type Status =
  | 'requires_action' | 'processing' | 'authorized' | 'partially_captured' | 'captured'
  | 'failed' | 'canceled' | 'partially_refunded' | 'refunded' | 'disputed';

export type OperationType =
  | 'authorize' | 'incremental_authorization' | 'reauthorization' | 'partial_reversal' | 'reversal'
  | 'capture' | 'charge' | 'debit' | 'refund';

export type Method = 'card' | 'ach_debit' | 'bnpl';
export type Network = 'visa' | 'mastercard' | 'amex' | 'discover' | 'ach' | 'bnpl';
export type ReauthMode = 'reauth_then_reverse' | 'reverse_then_reauth';

export class LifecycleError extends Error {
  readonly code: string;
  constructor(code: string, message?: string) {
    super(message ?? code);
    this.code = code;
  }
}

const DAY = 86_400_000;
const HOUR = 3_600_000;

/** Mirrors config/authorization-validity.yaml (subset). */
export function authorizationValidity(network: Network, initiator: 'customer' | 'merchant', type: 'final' | 'estimated'): { ms: number; basis: string } {
  if (network === 'visa') return initiator === 'merchant' ? { ms: 5 * DAY, basis: 'visa.mit.standard' } : { ms: 10 * DAY, basis: 'visa.cit.standard' };
  if (network === 'mastercard') return type === 'estimated' ? { ms: 30 * DAY, basis: 'mastercard.pre_authorization' } : { ms: 7 * DAY, basis: 'mastercard.final_or_undefined' };
  if (network === 'amex') return { ms: 7 * DAY, basis: 'amex.standard' };
  if (network === 'discover') return { ms: 10 * DAY, basis: 'discover.standard' };
  if (network === 'bnpl') return { ms: 28 * DAY, basis: 'bnpl.provider_default' };
  return { ms: 0, basis: 'none' };
}

export interface Operation {
  id: string;
  type: OperationType;
  amount: number;
  parent?: string;
  status: 'succeeded' | 'failed';
  at: number;
  detail?: Record<string, unknown>;
}

interface AuthHold {
  op: string;
  kind: 'original' | 'reauthorization';
  amount: number;          // authorized (incl. incrementals)
  captured: number;        // captured against this hold
  released: number;        // reversed / released
  status: 'active' | 'superseded' | 'reversed' | 'expired';
  expiresAt: number;
  basis: string;
}

interface Capture {
  op: string;
  seq: number;
  amount: number;
  refunded: number;
  disputedOpen: number;
  chargedBack: number;
}

interface Dispute {
  id: string;
  captureOp: string;
  amount: number;
  status: 'needs_response' | 'won' | 'lost';
}

export interface IntentOptions {
  id: string;
  amount: number;
  method: Method;
  network: Network;
  funding?: 'credit' | 'debit' | 'prepaid';
  captureMethod: 'automatic' | 'manual' | 'multi';
  authorizationType?: 'final' | 'estimated';
  storedCredentialConsent?: boolean;
  policies?: {
    onAuthorizationExpiry?: 'reauthorize' | 'notify' | 'cancel';
    reauthorizationMode?: 'auto' | ReauthMode;
    partialAuthorization?: 'reject' | 'accept_and_collect_remainder';
    overcaptureTolerancePercent?: number;
  };
  now: number;
}

export class PaymentIntent {
  readonly id: string;
  readonly amount: number;
  readonly method: Method;
  readonly network: Network;
  readonly operations: Operation[] = [];
  readonly events: string[] = [];
  private holds: AuthHold[] = [];
  private captures: Capture[] = [];
  private disputes: Dispute[] = [];
  private seq = 0;
  private opCounter = 0;
  private terminal: null | { status: 'failed' | 'canceled'; reason: string; retryable?: boolean } = null;
  private pendingAction = false;
  private achRepresentments = 0;
  finality: { status: 'not_applicable' | 'provisional' | 'final'; reversibleUntil?: number } = { status: 'not_applicable' };

  private readonly o: IntentOptions;

  constructor(o: IntentOptions) {
    this.o = o;
    this.id = o.id;
    this.amount = o.amount;
    this.method = o.method;
    this.network = o.network;
  }

  // ------------------------------------------------------------------ derived state
  get amountCaptured() { return sum(this.captures.map((c) => c.amount)); }
  get amountRefunded() { return sum(this.captures.map((c) => c.refunded)); }
  get amountChargedBack() { return sum(this.captures.map((c) => c.chargedBack)); }
  get amountDisputed() { return sum(this.captures.map((c) => c.disputedOpen)); }
  get amountCapturable() {
    const h = this.activeHold();
    return h ? h.amount - h.captured - h.released : 0;
  }
  get amountAuthorized() { return sum(this.holds.filter((h) => h.status === 'active').map((h) => h.amount)); }
  get authorization() {
    const h = this.activeHold() ?? this.holds[this.holds.length - 1];
    return h ? { status: h.status, expiresAt: h.expiresAt, basis: h.basis, reauthorizationCount: this.holds.filter((x) => x.kind === 'reauthorization').length, operation: h.op } : { status: 'none' as const };
  }
  get captureList() { return this.captures.map((c) => ({ ...c })); }
  get disputeList() { return this.disputes.map((d) => ({ ...d })); }

  get status(): Status {
    if (this.disputes.some((d) => d.status === 'needs_response')) return 'disputed';
    if (this.disputes.some((d) => d.status === 'lost')) return 'disputed';
    if (this.terminal && this.amountCaptured === 0) return this.terminal.status;
    if (this.pendingAction) return 'requires_action';
    const captured = this.amountCaptured;
    const refunded = this.amountRefunded;
    if (refunded > 0) return refunded === captured ? 'refunded' : 'partially_refunded';
    if (captured > 0) return this.amountCapturable > 0 ? 'partially_captured' : 'captured';
    if (this.amountCapturable > 0) return 'authorized';
    return 'processing';
  }

  get lastResult() { return this.terminal; }

  // ------------------------------------------------------------------ authorization
  /** Confirm. `approved` = amount the issuer approved (0 = decline). */
  confirm(r: { approved: number; requiresAction?: boolean; retryable?: boolean; now: number }) {
    if (this.method === 'ach_debit') throw new LifecycleError('use_debit_for_ach');
    if (r.requiresAction) { this.pendingAction = true; this.events.push('payment_intent.requires_action'); return this; }
    this.pendingAction = false;
    if (this.terminal && !this.terminal.retryable) throw new LifecycleError('intent_terminal');
    this.terminal = null;
    const op = this.op('authorize', this.amount, r.now, r.approved > 0 ? 'succeeded' : 'failed');
    if (r.approved === 0) {
      this.terminal = { status: 'failed', reason: 'declined', retryable: r.retryable ?? false };
      this.events.push('payment_intent.payment_failed');
      return this;
    }
    if (r.approved < this.amount && (this.o.policies?.partialAuthorization ?? 'reject') === 'reject') {
      this.op('reversal', r.approved, r.now, 'succeeded', op.id);
      this.terminal = { status: 'failed', reason: 'partial_authorization_rejected', retryable: true };
      this.events.push('payment_intent.payment_failed');
      return this;
    }
    this.addHold(op.id, 'original', r.approved, r.now, 'customer');
    if (this.o.captureMethod === 'automatic') return this.capture(r.approved, { final: true, now: r.now });
    this.events.push(r.approved < this.amount ? 'payment_intent.partially_authorized' : 'payment_intent.authorized');
    return this;
  }

  incrementAuthorization(amount: number, r: { approved: boolean; now: number }) {
    const h = this.requireActiveHold(r.now);
    const op = this.op('incremental_authorization', amount, r.now, r.approved ? 'succeeded' : 'failed', h.op);
    if (!r.approved) throw new LifecycleError('incremental_declined');
    h.amount += amount;
    if (this.o.authorizationType === 'estimated') {
      const v = authorizationValidity(this.network, 'customer', 'estimated');
      h.expiresAt = r.now + v.ms;
    }
    this.events.push('payment_intent.amount_increased');
    return op;
  }

  /**
   * Advance time. Fires AUTHORIZATION_EXPIRING inside the lead time and applies the expiry policy;
   * expires the hold at expires_at. `reauthApproves` is the issuer's answer if a reauthorization is sent.
   */
  tick(now: number, r: { reauthApproves?: boolean; leadMs?: number } = {}) {
    const h = this.activeHold();
    if (!h || this.amountCapturable === 0) return this;
    const lead = r.leadMs ?? 24 * HOUR;
    if (now >= h.expiresAt) {
      h.status = 'expired';
      this.events.push('payment_intent.authorization_expired');
      if (this.amountCaptured === 0) this.terminal = { status: 'canceled', reason: 'authorization_expired' };
      return this;
    }
    if (now >= h.expiresAt - lead) {
      this.events.push('payment_intent.authorization_expiring');
      const policy = this.o.policies?.onAuthorizationExpiry ?? 'notify';
      if (policy === 'reauthorize') this.reauthorize({ approve: r.reauthApproves ?? true, now });
    }
    return this;
  }

  reauthorizationMode(): ReauthMode {
    const m = this.o.policies?.reauthorizationMode ?? 'auto';
    if (m !== 'auto') return m;
    return this.o.funding === 'debit' || this.o.funding === 'prepaid' ? 'reverse_then_reauth' : 'reauth_then_reverse';
  }

  /** Reauthorize the capturable remainder as a merchant-initiated transaction. */
  reauthorize(r: { approve: boolean; now: number; mode?: ReauthMode }) {
    if (!this.o.storedCredentialConsent) throw new LifecycleError('stored_credential_consent_required');
    const old = this.activeHold();
    const remaining = old ? old.amount - old.captured - old.released : 0;
    if (!old || remaining === 0) throw new LifecycleError('nothing_to_reauthorize');
    const mode = r.mode ?? this.reauthorizationMode();
    if (mode === 'reverse_then_reauth') {
      this.op('reversal', remaining, r.now, 'succeeded', old.op, { reason: 'reauthorization' });
      old.released += remaining;
      old.status = 'reversed';
      const op = this.op('reauthorization', remaining, r.now, r.approve ? 'succeeded' : 'failed', old.op, { mode });
      if (!r.approve) {
        this.events.push('payment_intent.reauthorization_failed');
        if (this.amountCaptured === 0) this.terminal = { status: 'canceled', reason: 'authorization_expired' };
        return this;
      }
      this.addHold(op.id, 'reauthorization', remaining, r.now, 'merchant');
    } else {
      const op = this.op('reauthorization', remaining, r.now, r.approve ? 'succeeded' : 'failed', old.op, { mode });
      if (!r.approve) {
        this.events.push('payment_intent.reauthorization_failed'); // old hold is still live until it expires
        return this;
      }
      this.op('reversal', remaining, r.now, 'succeeded', old.op, { reason: 'superseded_by_reauthorization' });
      old.released += remaining;
      old.status = 'superseded';
      this.addHold(op.id, 'reauthorization', remaining, r.now, 'merchant');
    }
    this.events.push('payment_intent.reauthorized');
    return this;
  }

  reverse(r: { amount?: number; now: number }) {
    const h = this.requireActiveHold(r.now);
    const remaining = h.amount - h.captured - h.released;
    const amount = r.amount ?? remaining;
    if (amount > remaining) throw new LifecycleError('amount_exceeds_capturable');
    this.op(amount === remaining ? 'reversal' : 'partial_reversal', amount, r.now, 'succeeded', h.op);
    h.released += amount;
    if (h.amount - h.captured - h.released === 0) {
      h.status = 'reversed';
      if (this.amountCaptured === 0) this.terminal = { status: 'canceled', reason: 'requested_by_customer' };
    }
    return this;
  }

  // ------------------------------------------------------------------ capture
  capture(amount: number, r: { final: boolean; now: number; mcc?: string }) {
    const h = this.requireActiveHold(r.now);
    const remaining = h.amount - h.captured - h.released;
    const tolerance = Math.floor((h.amount * (this.o.policies?.overcaptureTolerancePercent ?? 0)) / 100);
    if (amount > remaining + (r.final ? tolerance : 0)) throw new LifecycleError('amount_exceeds_tolerance');
    const op = this.op('capture', amount, r.now, 'succeeded', h.op, { sequence: this.seq + 1, final: r.final });
    this.seq += 1;
    h.captured += amount;
    this.captures.push({ op: op.id, seq: this.seq, amount, refunded: 0, disputedOpen: 0, chargedBack: 0 });
    const left = h.amount - h.captured - h.released;
    if (r.final && left > 0) {
      this.op('partial_reversal', left, r.now, 'succeeded', h.op, { reason: 'final_capture_release' });
      h.released += left;
      this.events.push('payment_intent.authorization_released');
    }
    this.events.push(this.status === 'partially_captured' ? 'payment_intent.partially_captured' : 'payment_intent.captured');
    this.finality = { status: 'provisional', reversibleUntil: r.now + 120 * DAY };
    return this;
  }

  // ------------------------------------------------------------------ ACH (D86)
  debit(r: { now: number }) {
    if (this.method !== 'ach_debit') throw new LifecycleError('operation_not_supported_on_rail');
    if (this.terminal && !this.terminal.retryable) throw new LifecycleError('intent_terminal');
    this.terminal = null;
    const op = this.op('debit', this.amount, r.now, 'succeeded', undefined, { representment: this.achRepresentments });
    this.seq += 1;
    this.captures.push({ op: op.id, seq: this.seq, amount: this.amount, refunded: 0, disputedOpen: 0, chargedBack: 0 });
    this.finality = { status: 'provisional', reversibleUntil: r.now + 60 * DAY };
    this.events.push('payment_intent.captured');
    return this;
  }

  achReturn(code: string, r: { now: number }) {
    const c = this.captures[this.captures.length - 1];
    if (!c) throw new LifecycleError('nothing_to_return');
    if (code === 'R01' || code === 'R09') {
      this.captures.pop();
      const retryable = this.achRepresentments < 2;
      this.terminal = { status: 'failed', reason: 'insufficient_funds', retryable };
      this.achRepresentments += 1;
      this.finality = { status: 'not_applicable' };
      this.events.push('payment_intent.ach_return');
      return this;
    }
    if (['R05', 'R07', 'R10', 'R11', 'R29'].includes(code)) {
      // unauthorized return: a dispute that is lost on arrival — there is no representment on ACH
      const id = `dp_${this.disputes.length + 1}`;
      this.disputes.push({ id, captureOp: c.op, amount: c.amount - c.refunded, status: 'lost' });
      c.chargedBack += c.amount - c.refunded;
      this.events.push('payment_intent.ach_return', 'dispute.lost');
      return this;
    }
    throw new LifecycleError('unsupported_return_code');
  }

  closeFinalityWindow(now: number) {
    if (this.finality.reversibleUntil !== undefined && now >= this.finality.reversibleUntil) this.finality = { status: 'final' };
    return this;
  }

  // ------------------------------------------------------------------ refunds
  refund(amount: number, r: { now: number; capture?: string }) {
    if (this.captures.length === 0) {
      // before capture a refund is a reversal (docs/05 §7)
      this.reverse({ amount, now: r.now });
      return { converted_to_reversal: true as const };
    }
    const target = r.capture ? this.captures.find((c) => c.op === r.capture) : [...this.captures].reverse().find((c) => refundable(c) > 0);
    if (!target) throw new LifecycleError('nothing_refundable');
    if (amount > refundable(target)) {
      throw new LifecycleError(target.disputedOpen > 0 ? 'refund_blocked_by_dispute' : 'amount_exceeds_refundable');
    }
    const op = this.op('refund', amount, r.now, 'succeeded', target.op);
    target.refunded += amount;
    this.events.push('payment_intent.refund.succeeded');
    return op;
  }

  // ------------------------------------------------------------------ disputes
  openDispute(captureOp: string, amount: number) {
    const c = this.captures.find((x) => x.op === captureOp);
    if (!c) throw new LifecycleError('unknown_capture');
    if (amount > c.amount - c.refunded - c.chargedBack - c.disputedOpen) throw new LifecycleError('dispute_exceeds_undisputed_amount');
    c.disputedOpen += amount;
    const d: Dispute = { id: `dp_${this.disputes.length + 1}`, captureOp, amount, status: 'needs_response' };
    this.disputes.push(d);
    this.events.push('payment_intent.disputed');
    return d.id;
  }

  resolveDispute(id: string, outcome: 'won' | 'lost') {
    const d = this.disputes.find((x) => x.id === id);
    if (!d || d.status !== 'needs_response') throw new LifecycleError('dispute_not_open');
    const c = this.captures.find((x) => x.op === d.captureOp)!;
    c.disputedOpen -= d.amount;
    if (outcome === 'lost') c.chargedBack += d.amount;
    d.status = outcome;
    this.events.push(`dispute.${outcome}`);
    return this;
  }

  // ------------------------------------------------------------------ internals
  private activeHold() { return this.holds.find((h) => h.status === 'active'); }

  private requireActiveHold(now: number) {
    const h = this.activeHold();
    if (!h) throw new LifecycleError('authorization_not_capturable');
    if (now >= h.expiresAt) { h.status = 'expired'; throw new LifecycleError('authorization_not_capturable', 'authorization expired'); }
    return h;
  }

  private addHold(op: string, kind: AuthHold['kind'], amount: number, now: number, initiator: 'customer' | 'merchant') {
    const v = authorizationValidity(this.network, initiator, this.o.authorizationType ?? 'final');
    this.holds.push({ op, kind, amount, captured: 0, released: 0, status: 'active', expiresAt: now + v.ms, basis: v.basis });
  }

  private op(type: OperationType, amount: number, at: number, status: Operation['status'], parent?: string, detail?: Record<string, unknown>) {
    const o: Operation = { id: `op_${++this.opCounter}`, type, amount, at, status, parent, detail };
    this.operations.push(o);
    return o;
  }
}

function refundable(c: Capture) { return c.amount - c.refunded - c.chargedBack - c.disputedOpen; }
function sum(xs: number[]) { return xs.reduce((a, b) => a + b, 0); }
export const time = { DAY, HOUR };
