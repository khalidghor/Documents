/**
 * Order projection (docs/06 §1): the order's payment_status and dispute_status are pure functions of its
 * balance due and its Payment Intents. Same intents in, same order out.
 */
import type { PaymentIntent } from './payment-lifecycle.ts';

export type OrderPaymentStatus =
  | 'unpaid' | 'requires_action' | 'partially_authorized' | 'authorized' | 'partially_collected'
  | 'collected' | 'partially_refunded' | 'refunded' | 'payment_exception';

export type OrderDisputeStatus = 'none' | 'open' | 'won' | 'lost' | 'partially_lost';

export interface OrderView {
  total: number;
  canceled: number;          // canceled lines
  nonPspTenders: number;     // cash, external gift cards
  exceptionOpen?: boolean;   // an authorization expired / capture failed / NSF and the balance is uncovered
}

export function projectPaymentStatus(order: OrderView, intents: PaymentIntent[]): OrderPaymentStatus {
  const balanceDue = order.total - order.canceled - order.nonPspTenders;
  const captured = sum(intents.map((i) => i.amountCaptured));
  const refunded = sum(intents.map((i) => i.amountRefunded));
  const capturable = sum(intents.map((i) => i.amountCapturable));
  const covered = captured + capturable;

  if (refunded > 0 && refunded === captured && captured > 0) return 'refunded';
  if (refunded > 0) return 'partially_refunded';
  if (balanceDue > 0 && covered < balanceDue && (order.exceptionOpen || hasLostCoverage(intents))) return 'payment_exception';
  if (balanceDue > 0 && captured >= balanceDue) return 'collected';
  if (captured > 0) return 'partially_collected';
  if (balanceDue > 0 && capturable >= balanceDue) return 'authorized';
  if (capturable > 0) return 'partially_authorized';
  if (intents.some((i) => i.status === 'requires_action')) return 'requires_action';
  return 'unpaid';
}

export function projectDisputeStatus(intents: PaymentIntent[]): OrderDisputeStatus {
  const ds = intents.flatMap((i) => i.disputeList);
  if (ds.length === 0) return 'none';
  if (ds.some((d) => d.status === 'needs_response')) return 'open';
  const lost = ds.filter((d) => d.status === 'lost').length;
  if (lost === 0) return 'won';
  return lost === ds.length ? 'lost' : 'partially_lost';
}

/** An intent that once held coverage and lost it without collecting (expired, reauth declined, NSF). */
function hasLostCoverage(intents: PaymentIntent[]) {
  return intents.some(
    (i) =>
      i.events.includes('payment_intent.authorization_expired') ||
      i.events.includes('payment_intent.reauthorization_failed') ||
      i.events.includes('payment_intent.ach_return'),
  );
}

function sum(xs: number[]) { return xs.reduce((a, b) => a + b, 0); }
