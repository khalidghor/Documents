/**
 * Two ledgers for a marketplace (docs/08): the acquiring ledger ("where is the money", keyed by payments)
 * and the commerce ledger ("who owes whom", keyed by orders, lines and sellers). Both are double-entry;
 * the control invariant says the platform's merchant payable in the first equals the control account in
 * the second.
 */

export type Direction = 'debit' | 'credit';
export interface Posting { account: string; direction: Direction; amount: number }

export class Ledger {
  private readonly normal = new Map<string, Direction>();
  private readonly postings: { entry: string; p: Posting }[] = [];
  private n = 0;

  readonly name: 'acquiring' | 'commerce';

  constructor(name: 'acquiring' | 'commerce', accounts: Record<string, Direction>) {
    this.name = name;
    for (const [a, d] of Object.entries(accounts)) this.normal.set(a, d);
  }

  post(event: string, lines: Posting[]): string {
    const dr = lines.filter((l) => l.direction === 'debit').reduce((s, l) => s + l.amount, 0);
    const cr = lines.filter((l) => l.direction === 'credit').reduce((s, l) => s + l.amount, 0);
    if (dr !== cr) throw new Error(`${this.name}: ${event} does not balance (${dr} ≠ ${cr})`);
    for (const l of lines) {
      if (!this.normal.has(l.account)) throw new Error(`${this.name}: unknown account ${l.account}`);
      if (l.amount <= 0 || !Number.isInteger(l.amount)) throw new Error(`${this.name}: bad amount ${l.amount}`);
    }
    const id = `${this.name}_je_${++this.n}`;
    for (const p of lines) this.postings.push({ entry: id, p });
    return id;
  }

  /** Balance in the account's normal direction. */
  balance(account: string): number {
    const normal = this.normal.get(account);
    if (!normal) throw new Error(`unknown account ${account}`);
    return this.postings
      .filter((x) => x.p.account === account)
      .reduce((s, x) => s + (x.p.direction === normal ? x.p.amount : -x.p.amount), 0);
  }

  accounts() { return [...this.normal.keys()]; }
}

// ------------------------------------------------------------------ allocation rules
export interface Line { id: string; seller: string; item: number; tax: number; shipping: number; commissionRate: number }
export interface SellerAgreement {
  refundAdminFeeRate: number;     // share of commission the platform keeps on refunds
  refundAdminFeeCap: number;
  commissionOnChargeback: 'retain' | 'refund';
  taxOnChargeback: 'reverse_if_permitted' | 'retain';
  disputeFeeBearer: 'seller' | 'platform';
}

export function commission(line: Line) { return Math.round(line.item * line.commissionRate); }

const c = (account: string, amount: number): Posting => ({ account, direction: 'credit', amount });
const d = (account: string, amount: number): Posting => ({ account, direction: 'debit', amount });
const nonzero = (ps: Posting[]) => ps.filter((p) => p.amount !== 0);

export class Marketplace {
  readonly acquiring: Ledger;
  readonly commerce: Ledger;

  readonly platform: string;
  readonly taxAccount: string;

  constructor(platform: string, sellers: string[], taxAccount = 'tax:payable:marketplace') {
    this.platform = platform;
    this.taxAccount = taxAccount;
    this.acquiring = new Ledger('acquiring', {
      scheme_receivable: 'debit', settlement_cash: 'debit', [`merchant_payable:${platform}`]: 'credit',
      psp_fee_revenue: 'credit', dispute_fee_revenue: 'credit',
    });
    const accts: Record<string, Direction> = {
      psp_receivable: 'debit', commission_revenue: 'credit', processing_fee_expense: 'debit',
      platform_dispute_loss: 'debit', [taxAccount]: 'credit',
    };
    for (const s of sellers) accts[`seller:${s}:pending`] = 'credit';
    this.commerce = new Ledger('commerce', accts);
  }

  private get payable() { return `merchant_payable:${this.platform}`; }

  /** Capture of whole lines (the capture's line allocations), plus the PSP fee on that capture. */
  capture(lines: Line[], fee: number) {
    const gross = lines.reduce((s, l) => s + l.item + l.tax + l.shipping, 0);
    this.acquiring.post('capture.succeeded', [d('scheme_receivable', gross), c(this.payable, gross)]);
    this.acquiring.post('fee.assessed', [d(this.payable, fee), c('psp_fee_revenue', fee)]);
    const credits: Posting[] = [];
    for (const l of lines) {
      credits.push(c(`seller:${l.seller}:pending`, l.item + l.shipping - commission(l)));
      credits.push(c('commission_revenue', commission(l)));
      credits.push(c(this.taxAccount, l.tax));
    }
    this.commerce.post('capture.succeeded', nonzero([d('psp_receivable', gross), ...credits]));
    this.commerce.post('fee.assessed', [d('processing_fee_expense', fee), c('psp_receivable', fee)]);
  }

  /** Refund of a line's item and tax (shipping not refunded); commission refunded less the admin fee. */
  refundLine(line: Line, agreement: SellerAgreement) {
    const amount = line.item + line.tax;
    const comm = commission(line);
    const adminFee = Math.min(Math.round(comm * agreement.refundAdminFeeRate), agreement.refundAdminFeeCap);
    const commissionRefunded = comm - adminFee;
    this.acquiring.post('refund.succeeded', [d(this.payable, amount), c('scheme_receivable', amount)]);
    this.commerce.post('refund.succeeded', nonzero([
      d(`seller:${line.seller}:pending`, line.item - commissionRefunded),
      d('commission_revenue', commissionRefunded),
      d(this.taxAccount, line.tax),
      c('psp_receivable', amount),
    ]));
  }

  /** A lost chargeback on a capture that paid for `line` (item + tax + shipping), allocated by rule. */
  disputeLost(line: Line, disputed: number, fee: number, liable: 'seller' | 'platform', agreement: SellerAgreement) {
    this.acquiring.post('dispute.funds_withdrawn', [d(this.payable, disputed), c('settlement_cash', disputed)]);
    this.acquiring.post('dispute.fee', [d(this.payable, fee), c('dispute_fee_revenue', fee)]);
    const tax = agreement.taxOnChargeback === 'reverse_if_permitted' ? line.tax : 0;
    const comm = agreement.commissionOnChargeback === 'refund' ? commission(line) : 0;
    const bearer = liable === 'seller' ? `seller:${line.seller}:pending` : 'platform_dispute_loss';
    const feeBearer = agreement.disputeFeeBearer === 'seller' && liable === 'seller' ? bearer : 'platform_dispute_loss';
    this.commerce.post('dispute.lost', nonzero([
      d(bearer, disputed - tax - comm),
      d(this.taxAccount, tax),
      d('commission_revenue', comm),
      d(feeBearer, fee),
      c('psp_receivable', disputed + fee),
    ]));
  }

  /** Control invariant: acquiring merchant payable == commerce control account (psp_receivable). */
  reconcile() {
    const acquiring = this.acquiring.balance(this.payable);
    const control = this.commerce.balance('psp_receivable');
    // Σ commerce balances (credit-normal minus debit-normal, excluding the control account) must equal it too
    const others = this.commerce.accounts().filter((a) => a !== 'psp_receivable');
    const sumOthers = others.reduce((s, a) => s + (a === 'processing_fee_expense' || a === 'platform_dispute_loss' ? -1 : 1) * this.commerce.balance(a), 0);
    return { acquiring, control, sumOthers, balanced: acquiring === control && control === sumOthers };
  }
}
