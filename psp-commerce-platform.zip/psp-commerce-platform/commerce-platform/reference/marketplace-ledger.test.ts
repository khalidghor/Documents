import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Marketplace, type Line, type SellerAgreement } from './marketplace-ledger.ts';

// docs/08 §4: MarketCo is MoR, marketplace-facilitator tax, 15% commission, 2.9% + 30¢ per capture.
const A: Line = { id: 'li_1', seller: 'A', item: 6000, tax: 600, shipping: 400, commissionRate: 0.15 };
const B: Line = { id: 'li_2', seller: 'B', item: 4000, tax: 400, shipping: 400, commissionRate: 0.15 };
const agreement: SellerAgreement = {
  refundAdminFeeRate: 0.2, refundAdminFeeCap: 500, commissionOnChargeback: 'retain',
  taxOnChargeback: 'reverse_if_permitted', disputeFeeBearer: 'seller',
};
const fee = (amount: number) => Math.round(amount * 0.029) + 30;

test('worked example: both ledgers balance and reconcile after every step', () => {
  const m = new Marketplace('MarketCo', ['A', 'B']);

  m.capture([A], fee(7000));
  assert.equal(fee(7000), 233);
  assert.equal(m.commerce.balance('seller:A:pending'), 5500);
  assert.ok(m.reconcile().balanced);

  m.capture([B], fee(4800));
  assert.equal(fee(4800), 169);
  assert.ok(m.reconcile().balanced);

  m.refundLine(B, agreement);
  assert.equal(m.commerce.balance('seller:B:pending'), 280);          // 4.00 shipping − 1.20 admin fee
  assert.equal(m.commerce.balance('commission_revenue'), 1020);
  assert.equal(m.reconcile().acquiring, 6998);                          // $69.98
  assert.ok(m.reconcile().balanced);

  m.disputeLost(A, 7000, 1500, 'seller', agreement);
  assert.equal(m.commerce.balance('seller:A:pending'), -2400);         // −$24.00 → recovery waterfall
  assert.equal(m.commerce.balance('tax:payable:marketplace'), 0);
  const r = m.reconcile();
  assert.equal(r.acquiring, -1502);                                     // −$15.02 on both sides
  assert.equal(r.control, -1502);
  assert.ok(r.balanced);
});

test('variant: commission refunded on chargeback moves the loss from the seller to the platform', () => {
  const m = new Marketplace('MarketCo', ['A', 'B']);
  m.capture([A], fee(7000));
  m.disputeLost(A, 7000, 1500, 'seller', { ...agreement, commissionOnChargeback: 'refund' });
  assert.equal(m.commerce.balance('seller:A:pending'), 5500 - 7000);   // 55.00 − (64.00 − 9.00) − 15.00 = −15.00
  assert.equal(m.commerce.balance('commission_revenue'), 0);
  assert.ok(m.reconcile().balanced);
});

test('platform-absorbed dispute leaves the seller whole', () => {
  const m = new Marketplace('MarketCo', ['A']);
  m.capture([A], fee(7000));
  m.disputeLost(A, 7000, 1500, 'platform', { ...agreement, taxOnChargeback: 'retain' });
  assert.equal(m.commerce.balance('seller:A:pending'), 5500);
  assert.equal(m.commerce.balance('platform_dispute_loss'), 8500);
  assert.ok(m.reconcile().balanced);
});

test('an unbalanced entry is rejected', () => {
  const m = new Marketplace('MarketCo', ['A']);
  assert.throws(() => m.commerce.post('bad', [{ account: 'psp_receivable', direction: 'debit', amount: 100 }]), /does not balance/);
});
