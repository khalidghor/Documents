import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PaymentIntent, LifecycleError, time } from './payment-lifecycle.ts';
import { projectPaymentStatus, projectDisputeStatus } from './order-projection.ts';

const { DAY, HOUR } = time;
const T0 = Date.UTC(2026, 10, 2, 14, 0, 0);

function cardIntent(over: Partial<ConstructorParameters<typeof PaymentIntent>[0]> = {}) {
  return new PaymentIntent({
    id: 'pi_1', amount: 11800, method: 'card', network: 'visa', funding: 'credit', captureMethod: 'multi',
    storedCredentialConsent: true, policies: { onAuthorizationExpiry: 'reauthorize' }, now: T0, ...over,
  });
}
const throwsCode = (fn: () => unknown, code: string) =>
  assert.throws(fn, (e: unknown) => e instanceof LifecycleError && e.code === code);

test('authorize → multi-capture → final capture releases nothing left over', () => {
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  assert.equal(pi.status, 'authorized');
  assert.equal(pi.authorization.basis, 'visa.cit.standard');
  pi.capture(7000, { final: false, now: T0 + DAY });
  assert.equal(pi.status, 'partially_captured');
  assert.equal(pi.amountCapturable, 4800);
  pi.capture(4800, { final: true, now: T0 + 2 * DAY });
  assert.equal(pi.status, 'captured');
  assert.deepEqual(pi.captureList.map((c) => c.seq), [1, 2]);
});

test('final capture for less than authorized releases the remainder by partial reversal', () => {
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  pi.capture(10000, { final: true, now: T0 + DAY });
  assert.equal(pi.status, 'captured');
  assert.equal(pi.amountCapturable, 0);
  assert.ok(pi.operations.some((o) => o.type === 'partial_reversal' && o.amount === 1800));
});

test('worked example (docs/05 §10): reauth_then_reverse before expiry keeps one intent and one hold', () => {
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  pi.capture(7000, { final: false, now: T0 + 1 * DAY });
  pi.tick(T0 + 9 * DAY + 1, { reauthApproves: true });               // inside the 24h lead before day 10
  assert.equal(pi.status, 'partially_captured');
  assert.equal(pi.authorization.reauthorizationCount, 1);
  assert.equal(pi.authorization.basis, 'visa.mit.standard');          // reauthorization is an MIT
  const types = pi.operations.map((o) => o.type);
  assert.deepEqual(types.slice(-2), ['reauthorization', 'reversal']); // reauth first, then reverse the old hold
  pi.capture(4800, { final: true, now: T0 + 12 * DAY });              // after the original would have expired
  assert.equal(pi.status, 'captured');
});

test('debit cards default to reverse_then_reauth; a declined reauthorization leaves no hold', () => {
  const pi = cardIntent({ funding: 'debit' }).confirm({ approved: 11800, now: T0 });
  assert.equal(pi.reauthorizationMode(), 'reverse_then_reauth');
  pi.tick(T0 + 9 * DAY + 1, { reauthApproves: false });
  assert.equal(pi.amountCapturable, 0);
  assert.equal(pi.status, 'canceled');
  assert.deepEqual(pi.operations.slice(-2).map((o) => o.type), ['reversal', 'reauthorization']);
  assert.ok(pi.events.includes('payment_intent.reauthorization_failed'));
});

test('credit card: declined reauth keeps the original hold until it expires; capture after expiry is blocked', () => {
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  pi.tick(T0 + 9 * DAY + 1, { reauthApproves: false });
  assert.equal(pi.status, 'authorized');                               // original still live
  pi.tick(T0 + 10 * DAY);
  assert.equal(pi.status, 'canceled');
  assert.equal(pi.lastResult?.reason, 'authorization_expired');
  throwsCode(() => pi.capture(100, { final: true, now: T0 + 10 * DAY + HOUR }), 'authorization_not_capturable');
});

test('reauthorization requires stored-credential consent', () => {
  const pi = cardIntent({ storedCredentialConsent: false }).confirm({ approved: 11800, now: T0 });
  throwsCode(() => pi.reauthorize({ approve: true, now: T0 + 9 * DAY }), 'stored_credential_consent_required');
});

test('partial authorization: rejected by default, accepted for split tender', () => {
  const rejected = cardIntent().confirm({ approved: 8000, now: T0 });
  assert.equal(rejected.status, 'failed');
  assert.equal(rejected.lastResult?.reason, 'partial_authorization_rejected');
  const accepted = cardIntent({ policies: { partialAuthorization: 'accept_and_collect_remainder' } }).confirm({ approved: 8000, now: T0 });
  assert.equal(accepted.status, 'authorized');
  assert.equal(accepted.amountCapturable, 8000);
  assert.ok(accepted.events.includes('payment_intent.partially_authorized'));
});

test('incremental authorization grows the hold; tip within tolerance captures above authorization', () => {
  const pi = cardIntent({ amount: 6420, authorizationType: 'estimated', policies: { overcaptureTolerancePercent: 20 } })
    .confirm({ approved: 6420, now: T0 });
  pi.incrementAuthorization(1000, { approved: true, now: T0 + HOUR });
  assert.equal(pi.amountCapturable, 7420);
  pi.capture(8620, { final: true, now: T0 + 2 * HOUR });              // 7420 + 1200 tip (16%)
  assert.equal(pi.amountCaptured, 8620);
  throwsCode(() => cardIntent({ amount: 1000 }).confirm({ approved: 1000, now: T0 }).capture(1300, { final: true, now: T0 }), 'amount_exceeds_tolerance');
});

test('multiple partial refunds per capture; status moves partially_refunded → refunded', () => {
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  pi.capture(7000, { final: false, now: T0 + DAY });
  pi.capture(4800, { final: true, now: T0 + 2 * DAY });
  const cap2 = pi.captureList[1].op;
  pi.refund(4400, { capture: cap2, now: T0 + 20 * DAY });
  assert.equal(pi.status, 'partially_refunded');
  pi.refund(400, { capture: cap2, now: T0 + 21 * DAY });
  throwsCode(() => pi.refund(1, { capture: cap2, now: T0 + 22 * DAY }), 'amount_exceeds_refundable');
  pi.refund(7000, { now: T0 + 23 * DAY });
  assert.equal(pi.status, 'refunded');
});

test('refund before capture is converted to a reversal', () => {
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  assert.deepEqual(pi.refund(11800, { now: T0 + HOUR }), { converted_to_reversal: true });
  assert.equal(pi.status, 'canceled');
});

test('dispute: refund of disputed amount is blocked; won restores prior state; lost stays disputed', () => {
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  pi.capture(7000, { final: false, now: T0 + DAY });
  pi.capture(4800, { final: true, now: T0 + 2 * DAY });
  pi.refund(4400, { capture: pi.captureList[1].op, now: T0 + 20 * DAY });
  const cap1 = pi.captureList[0].op;
  const dp = pi.openDispute(cap1, 7000);
  assert.equal(pi.status, 'disputed');
  throwsCode(() => pi.refund(100, { capture: cap1, now: T0 + 46 * DAY }), 'refund_blocked_by_dispute');
  pi.resolveDispute(dp, 'won');
  assert.equal(pi.status, 'partially_refunded');                       // restored, by derivation

  const dp2 = pi.openDispute(cap1, 7000);
  pi.resolveDispute(dp2, 'lost');
  assert.equal(pi.status, 'disputed');
  assert.equal(pi.amountChargedBack, 7000);
});

test('ACH: captured on acceptance with a 60-day finality window; R01 is NSF with two re-presentments', () => {
  const pi = new PaymentIntent({ id: 'pi_ach', amount: 4999, method: 'ach_debit', network: 'ach', captureMethod: 'automatic', now: T0 });
  pi.debit({ now: T0 });
  assert.equal(pi.status, 'captured');
  assert.equal(pi.finality.status, 'provisional');
  pi.achReturn('R01', { now: T0 + 3 * DAY });
  assert.equal(pi.status, 'failed');
  assert.equal(pi.lastResult?.retryable, true);
  pi.debit({ now: T0 + 5 * DAY });                                     // re-presentment 1 on the same intent
  pi.achReturn('R01', { now: T0 + 7 * DAY });
  pi.debit({ now: T0 + 15 * DAY });                                    // re-presentment 2
  pi.achReturn('R01', { now: T0 + 17 * DAY });
  assert.equal(pi.lastResult?.retryable, false);                       // Nacha: at most two
  throwsCode(() => pi.debit({ now: T0 + 20 * DAY }), 'intent_terminal');
});

test('ACH unauthorized return (R10) is a dispute lost on arrival; finality becomes final after the window', () => {
  const a = new PaymentIntent({ id: 'pi_a', amount: 4999, method: 'ach_debit', network: 'ach', captureMethod: 'automatic', now: T0 });
  a.debit({ now: T0 }).achReturn('R10', { now: T0 + 40 * DAY });
  assert.equal(a.status, 'disputed');
  const b = new PaymentIntent({ id: 'pi_b', amount: 4999, method: 'ach_debit', network: 'ach', captureMethod: 'automatic', now: T0 });
  b.debit({ now: T0 }).closeFinalityWindow(T0 + 61 * DAY);
  assert.equal(b.finality.status, 'final');
  throwsCode(() => b.reverse({ now: T0 + DAY }), 'authorization_not_capturable'); // no reversal on ACH
});

test('order projection follows the intents (docs/06)', () => {
  const order = { total: 11800, canceled: 0, nonPspTenders: 0 };
  const pi = cardIntent().confirm({ approved: 11800, now: T0 });
  assert.equal(projectPaymentStatus(order, [pi]), 'authorized');
  pi.capture(7000, { final: false, now: T0 + DAY });
  assert.equal(projectPaymentStatus(order, [pi]), 'partially_collected');
  pi.capture(4800, { final: true, now: T0 + 2 * DAY });
  assert.equal(projectPaymentStatus(order, [pi]), 'collected');
  pi.refund(4400, { capture: pi.captureList[1].op, now: T0 + 20 * DAY });
  assert.equal(projectPaymentStatus(order, [pi]), 'partially_refunded');
  const dp = pi.openDispute(pi.captureList[0].op, 7000);
  assert.equal(projectDisputeStatus([pi]), 'open');
  pi.resolveDispute(dp, 'won');
  assert.equal(projectDisputeStatus([pi]), 'won');
});

test('order projection: expired authorization with nothing captured is a payment exception', () => {
  const order = { total: 11800, canceled: 0, nonPspTenders: 0 };
  const pi = cardIntent({ policies: { onAuthorizationExpiry: 'notify' } }).confirm({ approved: 11800, now: T0 });
  pi.tick(T0 + 10 * DAY);
  assert.equal(projectPaymentStatus(order, [pi]), 'payment_exception');
});

test('order projection: retail split tender — gift card + partially approved card + cash', () => {
  const order = { total: 15000, canceled: 0, nonPspTenders: 2000 };
  const gift = new PaymentIntent({ id: 'pi_gc', amount: 5000, method: 'card', network: 'visa', captureMethod: 'automatic', now: T0 })
    .confirm({ approved: 5000, now: T0 });
  const card = new PaymentIntent({ id: 'pi_card', amount: 10000, method: 'card', network: 'visa', captureMethod: 'manual',
    policies: { partialAuthorization: 'accept_and_collect_remainder' }, now: T0 }).confirm({ approved: 8000, now: T0 });
  assert.equal(projectPaymentStatus(order, [gift, card]), 'partially_collected');
  card.capture(8000, { final: true, now: T0 });
  assert.equal(projectPaymentStatus(order, [gift, card]), 'collected');
});
