# 01 · The resource model

> One durable object per purchase, driven by the platform through as many attempts as it takes, reported as one thing — and an optional commercial object above it that knows *what* was bought, *from whom*, and *who owes what to whom*.

This chapter is the map. Every later chapter zooms into one box on it.

## 1. The identity hierarchy

ST-003 §24 settles the hierarchy before the contract is published (D85). This package adopts it as written and adds the commerce layer above it.

```
Order (ord_)                       what was bought, from which sellers, on what terms
 ├── Seller order (so_)            the slice of the order one seller is responsible for
 ├── Line item (li_)               one sellable thing, with modifiers, discounts, tax lines, seller
 ├── Fulfillment group (fg_)       how and when a set of lines reaches the buyer
 ├── Collection plan               how the order total will be collected (now, on shipment, deposit, split tender…)
 └── Payment Intent (pi_)          one obligation to collect, in one method — many per order
      ├── Operation (op_)          one instruction: authorize, reauthorize, capture, refund, reversal…
      │    └── Attempt (att_)      one dispatch to one acquirer or rail
      │         └── External ref   network transaction id, ARN, ACH trace, BNPL order id
      ├── Dispute (dp_)            the network or provider says the payer is contesting money
      └── Dispute alert (dpa_)     a pre-dispute signal (Ethoca, CDRN, RDR, Order Insight, inquiry)

Ledger entries (je_)               two ledgers: acquiring (money) and commerce (who owes whom)
Execution plan (exec_id@version)   a reference carried on every Attempt — not a level
Decision record (dec_)             a reference carried on every Attempt — propensity, fallback, rejected
```

Three rules hold the tree together:

1. **An identifier names exactly one thing.** The order is the commercial transaction; the Payment Intent is the obligation to collect; the operation is the instruction (and carries the idempotency key); the attempt is the dispatch. Nothing in the API ever uses one id for two of these.
2. **Intent is immutable; execution is versioned** (ST-003 A1). The amount, currency, method and mandate on a Payment Intent change only through an explicit, versioned *amendment* (`intent_version`). How the platform tries — which acquirer, which credential, how many retries, a reauthorization — never edits the intent.
3. **Lineage is complete from Order to ledger.** Every ledger entry references the event that caused it and, where one exists, the operation, the attempt, the order line and the seller. The nine questions in ST-003 §32 can be answered from the record alone.

## 2. Resources at a glance

| Resource | Prefix | Created by | Mutable by merchant? | Purpose |
|---|---|---|---|---|
| Catalog item / variant | `prd_` / `var_` | Merchant or seller | Yes (versioned) | What can be sold: SKUs, modifiers, price books, tax codes |
| Order | `ord_` | Merchant, checkout session, POS, agent | Yes, until locked by its status | The commercial transaction |
| Seller order | `so_` | Platform, derived from order lines | No (derived) | One seller's slice: lines, fees, tax responsibility, payout |
| Payment Intent | `pi_` | Merchant, order, session | Amendments only (versioned) | Durable obligation to collect, any method |
| Operation | `op_` | Merchant call or platform policy | No | One instruction with its idempotency key |
| Attempt | `att_` | Platform only | No | One dispatch; read by advanced clients |
| Dispute | `dp_` | Network/provider via platform | Evidence and acceptance only | Contested money and its resolution |
| Dispute alert | `dpa_` | Alert networks via platform | Resolve/decline | Pre-dispute deflection |
| Seller | `sel_` | Platform | Yes | A party that sells on a marketplace, with liability settings |
| Allocation | `alc_` | Platform, from rules | No (derived; adjustable by adjustment) | Who earns what share of a payment line |
| Transfer / payout | `tr_` / `po_` | Platform | No | Movement of funds between balances / to a bank |
| Ledger entry | `je_` | Platform only, from journal | Never | Double-entry truth, two ledgers |
| Credential insight | `ci_` | Merchant / platform | No | What the platform knows about a credential |
| Credential registration | `crg_` | Merchant | Cancel only | Enrol a credential for funds / lifecycle notifications |
| Funds signal | `fsg_` | Platform | No | "This credential can probably be retried now" |

## 3. Four state models, never collapsed

ST-003 §28 insists on four separate state models. This package keeps them separate on every resource and adds a fifth for commerce.

| Model | Where it lives | Example values | Who reads it |
|---|---|---|---|
| **Commerce** | `order.status`, `order.fulfillment_status` | `confirmed`, `in_progress`, `partially_fulfilled`, `completed` | Merchant, buyer, seller |
| **Payment** (ten states) | `payment_intent.status` | `requires_action`, `processing`, `authorized`, `partially_captured`, `captured`, `failed`, `canceled`, `partially_refunded`, `refunded`, `disputed` | Every merchant and every agent |
| **Operation and attempt** | `operation.status`, `attempt.outcome` | `succeeded`, `failed`; `approved`, `partially_approved`, `declined`, `timeout`, `unknown` | Advanced clients, operations |
| **Rail** | `attempt.rail_state` | `presented`, `cleared`, `settled`; `in_return_window`, `returned` | Operations, reconciliation, disputes |
| **Financial** | `payment_intent.funds`, ledger | `receivable`, `pending`, `available`, `reserved`, `paid_out`, `returned` | Finance, treasury, sellers via balances |

The rule that follows: **the Payment Intent's state stops changing at capture while the financial state moves four or more times** (settlement, availability, payout, chargeback). Funds join the intent through the financial model, never by inventing more payment states.

## 4. How the order sits on the Payment Intent

The order never moves money itself. It owns a **collection plan** that says how its balance will be collected, and it creates Payment Intents to execute that plan.

```mermaid
flowchart LR
  subgraph Order["Order ord_ · $118.00"]
    L1["li_1 · Headphones · seller A · $60"]
    L2["li_2 · Case · seller B · $40"]
    L3["li_3 · Shipping · $8"]
    T["Tax · $10 · marketplace facilitator"]
  end
  CP["Collection plan<br/>authorize now, capture per shipment"]
  Order --> CP
  CP --> PI1["pi_1 · card · $118.00<br/>capture_method: multi"]
  CP -. split tender .-> PI0["pi_0 · gift card · $0 (unused)"]
  PI1 --> OP1["op_1 AUTHORIZE $118"]
  PI1 --> OP2["op_2 CAPTURE $70.00 (seq 1, seller A shipment)"]
  PI1 --> OP3["op_3 CAPTURE $48.00 (seq 2, final, seller B shipment)"]
  OP1 --> A1["att_1 acquirer A · declined (soft)"]
  OP1 --> A2["att_2 acquirer B · approved"]
```

* **Payment allocations** (`payment_intent.allocations[]`) say which order lines each Payment Intent pays for. They are what lets a refund, a dispute or a marketplace payout be attributed to the right seller and the right tax line without guessing.
* An order can hold **many Payment Intents** (split tender, deposit then balance, re-collection after an expired authorization, an exchange that adds money) and a Payment Intent belongs to **at most one order**.
* A Payment Intent can exist **without an order** — a merchant with its own OMS integrates at the intent level only, and passes `order_reference` for lineage (the "OMS branch rule").

## 5. Method versus rail

ST-003 §09: the customer picks the **method**; the platform picks the **rail**; the attempt records which.

| Method (`payment_method.type`) | Rails the platform may choose | Has an authorization? | Finality |
|---|---|---|---|
| `card` (credit) | Visa, Mastercard, Amex, Discover | Yes | At settlement; disputable for months |
| `card` (debit) | Card network, or a PIN/PINless debit network (Reg II) | Yes | As above |
| `ach_debit` | ACH, same-day ACH | No (account validation instead) | When the return window closes; `captured` on acceptance (D86) |
| `bank_transfer` / `pay_by_bank` | RTP, FedNow, open banking, ACH fallback | Consent | Immediately (RTP/FedNow) |
| `bnpl` | The provider's own funding arrangement | Yes, held by the provider | Provider-defined; disputes run through the provider |
| `wallet` | The funding instrument underneath (network token or bank) | As underneath | As underneath |
| `gift_card` / `store_credit` | Internal stored-value ledger | Reservation | Immediate (internal) |
| `agent_mandate` | Whatever credential the mandate permits | Yes | As underneath |

A rail cannot be enabled until it declares seven things (ST-003 gate G2): its states, reversibility, finality point, return window, where authentication sits, recovery actions and dispute rights. Those declarations are what the lifecycle chapter reads to decide, for example, that an ACH debit has no reversal after submission.

## 6. Where each concern is decided

| Concern | Decided by | Recorded on |
|---|---|---|
| What is sold, at what price, with which tax code | Catalog and order | Order line |
| Who is the merchant of record, who is liable for tax, refunds and disputes | Marketplace configuration (fund-flow model + rules) | Seller order, allocation |
| Which methods are offered, in what order | Session (decision with evidence) | Session decision record |
| Which rail, credential, acquirer, authentication | Decision Platform inside policy | Attempt (`decision_ref`, `exec_id`) |
| Whether and when to retry or reauthorize | Execution plan's attempt strategy, inside network rules | Attempt `origin` |
| When money is available, held, paid out | Funds management from the ledger | Ledger, payout |
| Who pays for a lost dispute | Dispute allocation rules | Dispute `allocation`, commerce ledger |

## 7. Naming note

ST-003 Option A names the external resource **Payment** and keeps **Payment Intent** internal. This package uses `payment_intent` as the external name because that is the brief. Nothing in the schema depends on the word; if Option A holds, rename the path segment and the `object` value and nothing else changes. Do **not** publish both names — that is finding 8 ("two intents") again.
