# 09 · Credential and Payments Intelligence

> Given a credential — a PAN on the PCI host, or a payment method, network token, fingerprint or BIN anywhere else — tell the merchant (or the platform's own decision points) what it is, what it will cost, how risky it is, how likely it is to be approved, and what to do to get the best outcome. Every answer carries its provenance, its freshness and an honest interval — or says it does not know.

This is EA-001 §12's "payment instrument intelligence", exposed as a product. It reuses the vault's credential model (`docs/vault/CREDENTIAL-PLATFORM.md` at the repository root) and the Decision Platform's records.

## 1. What it answers

| Section (`include[]`) | Question | Example fields |
|---|---|---|
| `bin` | What is this card? | brand, network(s), funding (credit/debit/prepaid), product (classic, signature, world elite, commercial purchasing), issuer country & currency, regulated (Durbin) flag, commercial flag, reloadable, virtual, PAN length, co-badged debit networks |
| `issuer` | Who issued it and how do they behave? | issuer name/ID, country, supports partial auth, incremental auth, account updater participation, network token support, 3DS 2.x version & frictionless rate, typical response time, recent approval trend (anomaly flag from payment intelligence) |
| `tokens` | What credentials exist for it? | network token eligibility/status, PAR, wallet tokens seen, token lifecycle events |
| `lifecycle` | Is it still good? | expiry, account updater result (new PAN/expiry, closed, contact cardholder), last successful authorization age, last decline class |
| `cost` | What will it cost here? | predicted interchange + scheme fees per eligible rail and acquirer (credit vs. regulated debit vs. PIN-less debit), L2/L3 eligibility and saving, cross-border and FX fees, expected total cost with interval |
| `risk` | Is it dangerous? | early-warning signals (below), card-testing velocity, fraud-report history on our network, BIN-level fraud rate, risk band |
| `disputes` | How likely is a dispute, and can we win? | BIN/issuer/product dispute rate (by reason family), friendly-fraud propensity band, representment win rate for this issuer by reason |
| `approval` | Will it be approved? | predicted approval probability for the given context, per strategy option (PAN vs. network token, acquirer A vs. B, 3DS vs. exemption), with interval and `insufficient_evidence` when support is thin |
| `strategy` | What should we do? | recommended credential, authentication action, routing preference, message enrichment, retry policy, alternative methods to offer — each with expected uplift, interval, and a `decision_ref` |
| `funds` | Will it have money? | NSF likelihood band now, best next retry window, active funds signal (see [10](10-nsf-signals-and-retries.md)) |

## 2. Inputs and context

```jsonc
POST /pci/v1/credential_insights            // PAN allowed only here (PCI host)
{
  "card": { "number": "4111111111111111", "exp_month": 12, "exp_year": 2029 },
  "context": {
    "amount": 11800, "currency": "USD",
    "merchant_account": "acct_...", "mcc": "5732",
    "channel": "ecommerce", "initiator": "customer",       // customer | merchant | agent
    "stored_credential": "first",                          // none | first | subsequent
    "recurring": false,
    "customer": { "id": "cus_...", "tenure_days": 410 },
    "device": { "ip_country": "US", "fingerprint": "dfp_..." },
    "shipping_country": "US",
    "candidate_acquirers": ["acq_A", "acq_B"]
  },
  "include": ["bin", "issuer", "cost", "risk", "disputes", "approval", "strategy", "funds"],
  "tokenize": true                                          // also return a pm_ so the PAN never travels again
}
```

Outside the PCI host, the same request takes one of `payment_method`, `network_token`, `credential_fingerprint` or `bin` (6–8 digits). With only a BIN, sections that need the credential (`lifecycle`, `funds`, credential-level `risk`) are returned as `unavailable` with a reason — never guessed.

## 3. Response shape

```jsonc
{
  "id": "ci_7Hq...", "object": "credential_insight",
  "credential": { "fingerprint": "cfp_9a...", "payment_method": "pm_...", "bin": "41111111", "last4": "1111" },
  "bin": { "brand": "visa", "funding": "credit", "product": "visa_signature", "commercial": false,
           "regulated_debit": false, "issuer_country": "US", "co_badged_networks": [],
           "source": "network_bin_table", "as_of": "2026-11-20" },
  "issuer": { "name": "Example Bank", "id": "iss_...", "supports": { "partial_authorization": true,
              "incremental_authorization": true, "account_updater": true, "network_tokens": true },
              "three_ds": { "version": "2.2", "frictionless_rate": 0.93 },
              "approval_trend": { "status": "normal", "detector": "approval_drop_v2" } },
  "cost": { "options": [
      { "rail": "visa", "acquirer": "acq_A", "credential": "network_token",
        "expected_cost": { "amount": 241, "interval": [228, 255] }, "components": { "interchange": 199, "scheme": 17, "psp": 25 } },
      { "rail": "visa", "acquirer": "acq_B", "credential": "pan",
        "expected_cost": { "amount": 252, "interval": [237, 268] } } ],
    "level3_saving": { "eligible": false } },
  "risk": { "band": "low", "score": 0.07,
            "early_warning": [
              { "signal": "network_fraud_report", "present": false, "window_days": 180, "source": "tc40_safe_on_our_volume" },
              { "signal": "card_testing_velocity", "present": false, "source": "consortium_on_our_network" },
              { "signal": "issuer_confirmed_fraud_alert", "present": false, "source": "ethoca_verifi" },
              { "signal": "account_compromise_flag", "status": "not_available", "reason": "not_received_by_acquirer" } ] },
  "disputes": { "bin_dispute_rate_bps": { "estimate": 41, "interval": [33, 50] },
                "friendly_fraud_band": "medium", "issuer_representment_win_rate": { "not_received": 0.64, "fraud": 0.38 } },
  "approval": { "probability": { "estimate": 0.946, "interval": [0.931, 0.958] },
                "by_option": [ { "option": "network_token@acq_A", "estimate": 0.957 },
                               { "option": "pan@acq_B", "estimate": 0.934 } ],
                "model": "approval_v7", "support": "adequate" },
  "strategy": {
    "decision_ref": "dec_ci_...", "propensity_logged": true,
    "recommendations": [
      { "decision_point": "credential", "action": "use_network_token", "expected_uplift_bps": 230, "interval_bps": [140, 320] },
      { "decision_point": "authentication", "action": "frictionless_3ds", "rationale": "liability shift at low friction for this issuer" },
      { "decision_point": "routing", "action": "prefer_acq_A" },
      { "decision_point": "message", "action": "send_stored_credential_first_indicator" } ] },
  "funds": { "nsf_likelihood_band": "low", "active_signal": null },
  "freshness": { "computed_at": "...", "valid_until": "..." },
  "disclosure_tier": "merchant_standard"
}
```

## 4. Early-warning signals — what exists and what does not

Honesty first: an acquirer/PSP does **not** see everything an issuer sees. Each signal declares its source and whether we actually receive it.

| Signal | Source | Available to a PSP? |
|---|---|---|
| Fraud reports on transactions we processed | Visa TC40 / Mastercard SAFE (Fraud and Loss Database) | Yes, for our own volume, delayed (days to weeks) |
| Confirmed fraud / dispute-in-progress alerts | Ethoca, Verifi CDRN | Yes, for enrolled merchants' transactions |
| Card-testing and velocity patterns | Our own consortium across all merchants on the platform | Yes — the strongest real-time signal we own |
| Prior disputes on the same credential across our merchants | Our dispute data, keyed by credential fingerprint | Yes, **as a band**, governed by the usage policy and consent-holder rules (no raw cross-merchant history) |
| Account compromise lists (issuer-side, e.g. CAMS/ADC) | Network to issuers | Generally **no** — modelled as `not_available` until a programme agreement says otherwise |
| Account status (open/closed) | $0 account verification; account updater | Yes, at the cost of a verification |
| Issuer-side intelligence | Within a bank-owned PSP | Only within what the information barrier (D35) permits — default `not_available` |
| Bank-account risk (ACH) | Account validation, account-owner match, returned-entry history | Yes, through validation providers and our own return history |

## 5. How approval and strategy are computed

* **Approval probability** is a calibrated model over attempt outcomes on the platform's own volume, with features from BIN, issuer, credential type, MCC, amount band, channel, initiator, authentication, acquirer, time of day and recent issuer health. It reports an interval and the support behind it. When the context sits where the model has little data, it returns `support: insufficient` and **no point estimate** — PD-002 §12's "refuse before you answer".
* **Strategy** is the Decision Platform's answer at each decision point for this context, evaluated in *advisory* mode: same strategies, same policies, same record (with propensity, fallback and what was rejected), but nothing is dispatched. When the merchant later confirms a Payment Intent, the live decision may differ (newer data, different context) and the attempt's `decision_ref` says so.
* **Cost** comes from the versioned cost table (interchange programmes, scheme fees, PSP pricing) per eligible rail × acquirer × credential, including regulated-debit and PIN-less debit routing alternatives.
* **Disputes** combine BIN/issuer/product rates with the merchant's own history; representment win rates are by issuer and reason.

## 6. Governance

| Rule | Why |
|---|---|
| PAN accepted only on the PCI host; everywhere else references only | PCI scope |
| Cross-merchant facts are returned as bands, never as raw events | Consent-holder rules (CMP §6) and competition law |
| Every field carries `source`, `as_of` and, for estimates, an interval | Merchants and agents must know what is a fact and what is a model |
| Purpose-declared access (`purpose: authorization_strategy | risk_review | analytics`) | Usage policy (CMP §7): default deny, logged |
| Models that influence authorization or decline are under model-risk governance | ST-001 §09 |
| Insights requested per credential are metered and rate-limited | Prevents BIN-probing and card-testing via the insight API itself |
| `risk` and `disputes` sections require the `intelligence.risk` entitlement | Commercial packaging and abuse control |

## 7. Where it is used

* By the merchant before checkout: offer the right methods (e.g. show BNPL when approval probability for a card is low), pre-fill authentication preferences, choose to collect a deposit.
* By the merchant's ops: explain declines, prioritize dunning, set fraud review.
* By the platform itself: the same signals are features in the live decision points — the API is a view onto them, not a second system.
* By agents: the MCP tool `credential_insights_get` (tokens or BIN only, never PANs) lets an agent decide whether to ask the user for a different card before trying.
