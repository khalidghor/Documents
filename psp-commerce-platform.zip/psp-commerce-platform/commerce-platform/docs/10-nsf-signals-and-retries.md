# 10 · NSF signals, credential registration and smart retries

> Insufficient funds is the most common recoverable decline in recurring and merchant-initiated payments. Retrying blindly burns network retry allowances, annoys issuers and costs fees; not retrying loses revenue. The platform registers credentials for funds and lifecycle notifications, learns when money is likely to be there, and tells merchants — or retries for them — at the right moment, inside every network and Nacha limit.

## 1. The loop

```mermaid
sequenceDiagram
  participant M as Merchant
  participant PI as Payment Intent
  participant CR as Credential registration
  participant SIG as Signal sources
  participant NET as Network / ACH
  M->>PI: confirm (MIT, subscription renewal)
  PI->>NET: authorize
  NET-->>PI: decline 51 (NSF) / MAC 25 / R01
  PI-->>M: payment_intent.retry_scheduled (managed) or payment_failed (retryable)
  M->>CR: POST /v1/credential_registrations {payment_method, purpose: nsf_recovery}
  CR->>SIG: enrol credential (network programme, open banking consent, internal models)
  SIG-->>CR: funds signal (e.g. payroll deposit observed / issuer advice window opened)
  CR-->>M: webhook credential.funds_signal {recommended_retry_at, confidence}
  alt managed retries
    CR->>PI: retry now (origin: scheduled_retry)
  else merchant-managed
    M->>PI: POST /confirm (re-confirm retryable failed intent)
  end
  PI->>NET: authorize (within retry limits)
  NET-->>PI: approved
  PI-->>M: payment_intent.captured
```

## 2. Credential registration (`crg_`)

A registration enrols one credential for one purpose with one or more **signal programmes**.

```jsonc
POST /v1/credential_registrations
{
  "payment_method": "pm_...",
  "purposes": ["nsf_recovery", "lifecycle_updates"],
  "programmes": ["network_funds_advice", "account_updater", "token_lifecycle", "open_banking_balance", "internal_model"],
  "consent": { "type": "stored_credential_agreement", "reference": "mdt_...@3" },
  "related_payment_intent": "pi_...",
  "expires_at": "2027-02-01T00:00:00Z"
}
```

| Programme | What it gives | Who operates it | Status in this design |
|---|---|---|---|
| `account_updater` | New PAN/expiry, closed account, contact cardholder | Visa Account Updater, Mastercard Automatic Billing Updater | Real programmes |
| `token_lifecycle` | Network token updates (reissue, suspend, delete) | Visa Token Service, Mastercard MDES | Real programmes |
| `network_funds_advice` | Issuer/network advice on when to retry | Mastercard Merchant Advice Codes on declines (e.g. 24–30 "retry after…"); any network or issuer real-time funds-availability notification service the PSP contracts for | MACs are real; a push "funds now available" service is **a programme agreement to negotiate with each network** — the API is designed for it, the source is pluggable |
| `open_banking_balance` | Balance / income events from the payer's bank, with consent | Open-banking aggregators (US: data-access under the payer's consent) | Real, consent-dependent, mostly for bank-account methods |
| `ach_account_signals` | Account status, returned-entry history | Account validation providers; our own return history | Real |
| `internal_model` | Predicted best retry time from our own history: issuer, BIN, payday cycles, time of day, prior recoveries | Us | Always available |

Registrations are listed, paused and canceled through the API; they expire with the consent that permits them.

## 3. Funds signals (`fsg_`)

```jsonc
{
  "id": "fsg_...", "object": "funds_signal",
  "registration": "crg_...", "payment_method": "pm_...",
  "source": "internal_model",                // network_funds_advice | open_banking_balance | ach_account_signals | internal_model | issuer_direct
  "type": "retry_window_opened",             // retry_window_opened | funds_likely_available | do_not_retry | credential_updated
  "recommended_retry_at": "2026-11-28T09:00:00-05:00",
  "window_ends_at": "2026-11-29T23:59:59-05:00",
  "confidence": { "estimate": 0.68, "interval": [0.59, 0.76] },
  "basis": ["issuer_payday_cycle", "prior_recovery_same_credential"],
  "network_constraints": { "retries_used": 3, "retries_allowed": 15, "window": "30d" },
  "related_payment_intents": ["pi_..."],
  "created_at": "..."
}
```

Webhooks: `credential.funds_signal`, `credential.updated` (account updater / token lifecycle), `payment_intent.retry_scheduled`, `payment_intent.retry_succeeded`, `payment_intent.retries_exhausted`.

## 4. Rules the retry engine never breaks

| Rule source | Constraint (defaults — verify before production) | How enforced |
|---|---|---|
| Visa decline categories | Category 1 (issuer will never approve: e.g. 04, 07, 12, 14, 15, 41, 43, 46, 57, R0, R1, R3): **no** reattempt. Categories 2–4 (cannot approve now, data quality, generic — NSF `51` is category 2): up to **15 reattempts in 30 days** per credential/merchant, fees beyond | `retry-policy.yaml`; counter per (merchant, credential) |
| Mastercard Merchant Advice Codes | MAC 01 (updated info needed) → use account updater before retry; MAC 02 → retry later; **MAC 03 → never retry**; MAC 21 → recurring canceled, stop the series; MAC 24–30 → retry no earlier than 1h / 24h / 2d / 4d / 6d / 8d / 10d; excessive-attempt fees apply | `retry-policy.yaml` |
| Amex / Discover | Retry limits per their rules | `retry-policy.yaml` |
| Nacha | R01/R09 (insufficient/uncollected funds): **at most two re-presentments within 180 days** of the original settlement date; re-presented entries flagged `RETRY PYMT` | `retry-policy.yaml → ach` |
| Nacha | R02, R03, R04, R05, R07, R08, R10, R11, R16, R20, R29: no re-presentment | As above |
| Consent | Retries are MITs under the original stored-credential agreement or mandate; the schedule must not exceed what the customer agreed (e.g. one charge per billing period) | Mandate check before every attempt |
| Customer experience | Max holds per day on debit/prepaid; no retries in local night hours unless the signal is strong | Merchant preference |

## 5. Managed vs. merchant-managed

| Mode | Intent status after NSF | Who triggers the retry | Merchant sees |
|---|---|---|---|
| `managed_retries: true` | `processing` (`RETRY_SCHEDULED` internally) with `retry_schedule[]` | The platform, on a funds signal or model window | `payment_intent.retry_scheduled`, then `captured` or `retries_exhausted` → `failed` |
| `managed_retries: false` | `failed` with `retryability.retryable: true`, `retry_after`, `attempts_remaining_under_network_rules` | The merchant, by re-confirming the same intent | `payment_intent.payment_failed`, `credential.funds_signal` |

Managed mode is a decision point like any other: the schedule is chosen by a strategy, logged with propensity, and measured against a holdout (some NSF intents retried on the static schedule) so the recovery uplift is a measured number, not a claim.

## 6. Metrics

* Recovery rate within 7/14/30 days, vs. the holdout.
* Attempts per recovery (lower is better — fewer issuer hits).
* Network retry-limit breaches (target zero) and excessive-retry fees.
* Signal precision: share of signals followed by an approval within the window, by source.
* Customer complaints / disputes on recovered payments (a guardrail: recovery that produces "canceled recurring" disputes is not recovery).
