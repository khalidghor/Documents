# 03 · The Payment Intent resource

> A durable commitment to collect an amount, in one method, under one mandate and one authentication context — created once, confirmed once, and driven by the platform through as many operations and attempts as it takes. Ten states, the same meaning for every method.

This chapter specifies the resource. How it moves through time — authorization, expiry, reauthorization, captures, refunds, disputes — is [05 · Payment lifecycle](05-payment-lifecycle.md).

## 1. Principles carried from ST-003

| # | Principle | What it means on this resource |
|---|---|---|
| A1 | Intent is immutable; execution is versioned | `amount`, `currency`, `payment_method`, `mandate` change only by amendment (`intent_version`); retries, reroutes and reauthorizations never edit them |
| A3 | Internal states are many; external states are ten | Fifteen internal states map onto the ten; internal states are never serialized |
| A4 | Unknown is a state with an owner | A timeout after dispatch leaves the intent in `processing` with an owned recovery case — never an empty response |
| — | Authentication binds to the intent | A 3DS result carries forward to every later attempt (until it is no longer valid for the amount or acquirer) |
| — | Idempotency on every mutating call | The operation id carries the key; a retry after a timeout returns the same intent |
| A2 | The client picks the method; the platform picks the rail | `payment_method` on the intent; `rail` on the attempt |

## 2. The ten states

```mermaid
stateDiagram-v2
  [*] --> requires_action: needs customer (3DS, redirect, BNPL, bank consent, card on terminal)
  [*] --> processing: confirmed, no action needed
  requires_action --> processing: action completed
  requires_action --> canceled: abandoned / expired
  processing --> requires_action: step-up requested
  processing --> authorized: authorization approved (manual capture)
  processing --> captured: approved + automatic capture, or ACH accepted (D86)
  processing --> failed: declined / not retryable / budget exhausted
  failed --> processing: re-confirm (only if retryable and within window)
  authorized --> partially_captured: non-final capture
  authorized --> captured: final capture
  authorized --> canceled: void / authorization expired without reauthorization
  partially_captured --> partially_captured: further non-final capture
  partially_captured --> captured: final capture (remainder released)
  captured --> partially_refunded: partial refund
  partially_captured --> partially_refunded: refund against a capture
  partially_refunded --> partially_refunded: further partial refund
  partially_refunded --> refunded: cumulative refunds = captured
  captured --> refunded: full refund
  captured --> disputed: dispute opened
  partially_refunded --> disputed: dispute opened
  disputed --> captured: dispute won (restores prior state)
  disputed --> partially_refunded: won, prior state was partially_refunded
  disputed --> disputed: lost (terminal for the dispute)
```

| State | Meaning — the same for every method | Card | ACH debit | BNPL | RTP / FedNow |
|---|---|---|---|---|---|
| `requires_action` | The customer (or their agent) must do something before the platform can proceed | 3DS challenge; present card at terminal | Micro-deposit / instant verification | Redirect to provider | Bank consent (open banking) |
| `processing` | The platform is working; nothing for the merchant to do. Includes owned unknown outcomes and scheduled retries | Dispatched, timed out and recovering, retry scheduled | Submitted, awaiting acceptance | Provider decisioning | Instructed |
| `authorized` | Money is **promised, not moved**. A hold exists and can be captured until `authorization.expires_at` | Issuer approved | — (ACH has no authorization) | Provider approved the plan | — |
| `partially_captured` | Some of the authorization captured; the remainder is still capturable | Multi-capture | — | Provider partial capture | — |
| `captured` | Money will move / has moved; `finality` says how final it is | Captured, awaiting clearing | Accepted by ODFI (D86), in return window | Captured; provider pays merchant | Settled and final |
| `failed` | The platform could not collect. `retryability` says if a re-confirm can succeed | Declined | Rejected pre-submission | Provider declined | Rejected |
| `canceled` | Will not collect. `cancellation_reason` includes `authorization_expired` | Voided / expired | Canceled before submission | Canceled | — |
| `partially_refunded` | Some captured money returned to the payer | Partial refund(s) | Partial credit entry | Provider partial refund | Partial return credit |
| `refunded` | All captured money returned | Full refund | Full credit | Full refund | Full return |
| `disputed` | The payer is contesting money through the network or provider | Chargeback | Unauthorized return (R05/R07/R10/R11/R29) | Provider dispute | Return request with fraud claim |

### Rules about states

1. **No generic success.** `authorized` and `captured` stay distinct; settlement lives on `funds`, never on `status`.
2. **`failed` is terminal unless the canonical result says it is retryable.** If `last_result.retryability.retryable = true` and `retry_window_ends_at` is in the future, the merchant (or an agent) may re-confirm the same intent — no new intent, no second identity. Managed retries (NSF schedules) keep the intent in `processing` with `retry_schedule` populated instead.
3. **An expired authorization cancels the intent only when nothing was captured and no reauthorization is permitted.** Otherwise the platform reauthorizes inside the intent (state stays `authorized` / `partially_captured`); see [05](05-payment-lifecycle.md) §4.
4. **`disputed` reflects an open dispute.** When a dispute is won the intent returns to the state it held before; when lost, the intent stays `disputed` and `amount_charged_back` records the loss. A second dispute on the same intent (e.g. a different capture) re-enters `disputed`.
5. **Refunds and disputes are in the external status** (this package resolves the open question in DOC-000 §05 that way, because agents and merchants act on both). Their detail lives on operations and disputes.

## 3. Internal states (never serialized)

The fifteen internal states of PD-001 §14 and the `src/domain/states.ts` mapping are kept. This package adds four lifecycle states, each mapped:

| Internal state | External | Added here? |
|---|---|---|
| `AUTHORIZATION_DISPATCHED`, `AUTHORIZATION_UNKNOWN`, `PROCESSOR_TIMEOUT`, `NETWORK_TIMEOUT` | `processing` | — |
| `STEP_UP_PENDING` | `requires_action` | — |
| `STAND_IN_APPROVED` | `authorized` | — |
| `REVERSAL_PENDING`, `RECOVERY_HELD`, `SUPERVISOR_CASE_OPEN`, `COMPENSATION_IN_PROGRESS` | `processing` | — |
| `REVERSAL_CONFIRMED`, `REVERSAL_FAILED` | `failed` | — |
| `CLEARING_MISMATCH`, `ORPHAN_AUTHORIZATION`, `LEDGER_BREAK` | `captured` | — |
| `AUTHORIZATION_EXPIRING` | `authorized` / `partially_captured` (unchanged) | **Yes** — reauthorization window open |
| `REAUTHORIZATION_IN_FLIGHT` | unchanged | **Yes** — new authorization dispatched, old one still held |
| `RETRY_SCHEDULED` | `processing` | **Yes** — NSF / soft-decline managed retry |
| `CAPTURE_PENDING_SETTLEMENT_CHECK` | `captured` | **Yes** — capture submitted after expiry; misuse-of-authorization risk |

## 4. Shape

Abbreviated; the full schema is `PaymentIntent` in [`openapi/schemas/payment-intents.yaml`](../openapi/schemas/payment-intents.yaml).

```jsonc
{
  "id": "pi_3Qx9...",
  "object": "payment_intent",
  "intent_version": 1,
  "livemode": false,
  "status": "partially_captured",
  "order_id": "ord_8Kd2...",              // null when the merchant has its own OMS
  "order_reference": null,                // the merchant's own order id, if no Order
  "amount": 11800, "currency": "USD",
  "amount_details": { "tax": 1000, "shipping": 800, "tip": 0, "surcharge": 0, "discount": 0,
                      "line_items_level3": true },
  "payment_method": { "id": "pm_...", "type": "card",
                      "card": { "brand": "visa", "funding": "credit", "last4": "4242", "country": "US",
                                "network_token": true } },
  "capture_method": "multi",              // automatic | manual | multi
  "confirmation": { "confirmed_at": "...", "channel": "web", "initiator": "customer",
                    "stored_credential": { "usage": "first", "reason": null } },
  "mandate": null,                        // mdt_...@version for MIT, ACH, BNPL, agents
  "session": "ses_...",
  "customer": "cus_...",
  "merchant_account": "acct_merchant_...",
  "on_behalf_of": null,                   // seller / sub-merchant when it is the settlement merchant
  "allocations": [ { "order_line_id": "li_1", "seller_id": "sel_A", "amount": 7000 },
                   { "order_line_id": "li_2", "seller_id": "sel_B", "amount": 4800 } ],

  "authorization": {
    "status": "active",                   // none | pending | active | expiring | expired | reversed | partially_reversed | superseded
    "type": "estimated",                  // final | estimated | pre_authorization | incremental_eligible
    "amount_authorized": 11800,
    "amount_capturable": 4800,
    "authorized_at": "2026-11-02T14:01:07Z",
    "expires_at": "2026-11-12T14:01:07Z",
    "expiry_basis": "visa.cit.standard",  // which rule produced expires_at
    "reauthorization_count": 0,
    "current_authorization_operation": "op_1",
    "history": [ { "operation": "op_1", "amount": 11800, "status": "active" } ]
  },
  "amount_captured": 7000,
  "amount_refunded": 0,
  "amount_reversed": 0,
  "amount_disputed": 0,
  "amount_charged_back": 0,
  "amount_net": 7000,                     // captured − refunded − charged back (before fees)
  "captures": { "count": 1, "final_capture_received": false, "next_sequence": 2 },

  "finality": { "status": "provisional", "final_at": null,
                "reversible_until": "2027-04-01T00:00:00Z",
                "reversal_mechanisms": ["refund", "chargeback"] },
  "funds": { "status": "pending", "settlement_date": "2026-11-04", "available_on": "2026-11-06",
             "payout": null },

  "last_result": { "outcome": "approved", "decided_by": "issuer", "reason": "approved",
                   "class": "success", "retryability": null },
  "next_action": null,
  "policies": { "on_authorization_expiry": "reauthorize",
                "reauthorization_mode": "reauth_then_reverse",
                "partial_authorization": "reject",
                "managed_retries": true },
  "cancellation_reason": null,
  "created_at": "...", "updated_at": "...",
  "metadata": {}
}
```

### 4.1 Authorization block

The authorization block is what most PSP APIs leave to the merchant's database. It answers, without a guide: *is there a hold, how much can I still capture, and when does it stop being safe to capture?*

* `expires_at` is computed from the **authorization validity rules** in [`config/authorization-validity.yaml`](../config/authorization-validity.yaml) — network, CIT/MIT, MCC, authorization type, card-present or not. The platform never guesses: `expiry_basis` names the rule.
* `amount_capturable` = authorized − captured − reversed. It drops to zero on expiry; it never goes negative.
* `history[]` keeps every authorization the intent has held (original, incremental, reauthorization) with its network transaction id, so a capture can reference the right one and so the dispute evidence shows the chain.

### 4.2 Finality block (D86)

`finality` is projected from the financial state and the rail's declarations. It is how an ACH debit can be `captured` on acceptance (not `processing` for sixty days) while being honest that it can still be returned:

| Method | `finality.status` after capture | `reversible_until` | `reversal_mechanisms` |
|---|---|---|---|
| Card | `provisional` | Last dispute filing date (typically 120 days from processing or delivery; longer for some reasons) | `refund`, `chargeback` |
| ACH debit (consumer) | `provisional` | 2 banking days for administrative returns; 60 calendar days for unauthorized returns (R10/R11) | `refund`, `ach_return` |
| RTP / FedNow | `final` | — | `refund`, `return_request` (receiver may decline) |
| BNPL | `provisional` | Provider dispute window | `refund`, `provider_dispute` |

### 4.3 Canonical result and retryability

Every terminal-ish outcome carries one canonical result (PD-001 §16): `outcome`, `decided_by` (`issuer`, `authentication`, `policy`, `risk`, `screening`, `technical`, `provider`), a `reason` from one enumeration, a `class` (`success`, `soft`, `hard`, `technical`), and a `retryability` block:

```json
"retryability": {
  "retryable": true,
  "retry_after": "2026-11-15T09:00:00Z",
  "retry_window_ends_at": "2026-12-01T00:00:00Z",
  "conditions": ["same_credential_ok", "funds_signal_recommended"],
  "network_advice": { "source": "mastercard_mac", "code": "25", "meaning": "retry after 24 hours" },
  "attempts_remaining_under_network_rules": 14
}
```

Processor codes never reach merchants; the network advice is summarized because merchants and agents need it to stay inside retry rules.

## 5. Operations on the intent

| Call | Creates operation | Allowed in states |
|---|---|---|
| `POST /v1/payment_intents` | — (intent) | — |
| `POST /v1/payment_intents/{id}/confirm` | `authorize` (or `charge` for automatic capture; `debit` for ACH) | `requires_action`, new, `failed` if retryable |
| `POST …/capture` | `capture` (`final_capture`, `sequence`, `fulfillment_group_id`) | `authorized`, `partially_captured` |
| `POST …/increment_authorization` | `incremental_authorization` | `authorized`, `partially_captured` (method + MCC must support it) |
| `POST …/reauthorize` | `reauthorization` (+ `reversal` per mode) | `authorized`, `partially_captured`, within the policy window |
| `POST …/reverse` | `partial_reversal` / `reversal` | `authorized`, `partially_captured` |
| `POST …/cancel` | `reversal` (void) | `requires_action`, `processing` (before dispatch), `authorized`, `failed` |
| `POST …/refunds` | `refund` | `captured`, `partially_captured`, `partially_refunded`, `disputed` (only for undisputed amount) |
| `POST …/amend` | — (new `intent_version`) | Before `captured`; amount changes may require `increment_authorization` |
| `GET …/operations`, `GET …/attempts` | — | Always |
| `GET …/decisions` | — ("why and why not") | Always |

## 6. Methods beyond card

The same object carries every method. What changes is which operations are legal (from the rail's declarations) and how `finality` reads.

| Method | Confirm does | Capture | Reverse / void | Refund | Dispute arrives as |
|---|---|---|---|---|---|
| Card | Authorization | Clearing (one or many) | Full or partial authorization reversal | Credit / refund authorization | Chargeback (Visa VCR, Mastercard, Amex, Discover) |
| ACH debit | Account validation (WEB debits), then submit debit entry | Automatic on acceptance (D86) | Cancel before submission only | Credit entry (or merchant-issued reversal within 5 banking days for duplicates/errors) | Unauthorized return (R05, R07, R10, R11, R29) |
| RTP / FedNow (request for payment) | RfP sent; payer approves; credit received | Automatic on receipt | — | Return credit | Return request |
| Open banking / pay by bank | Consent + payment initiation | On settlement | — | Refund via rail | Provider/rail complaint |
| BNPL | Provider authorization (redirect, `requires_action`) | Provider capture (supports partial/multiple) | Provider release | Provider refund (adjusts the buyer's plan) | Provider dispute (provider mediates) |
| Wallet | As the underlying funding credential (network token or bank) | As underlying | As underlying | As underlying | As underlying |
| Gift card / store credit | Reservation on the stored-value ledger | Redemption | Release | Re-credit | — |

## 7. What the merchant never has to do

* Link a decline, a step-up and a reroute: one intent, many attempts.
* Remember when an authorization expires or decide how to reauthorize: `authorization.expires_at` and `policies.on_authorization_expiry`.
* Poll after a timeout: unknown outcomes are owned by the recovery supervisor, and the intent reports `processing` until resolved.
* Count retries against network limits: `retryability.attempts_remaining_under_network_rules`.
* Work out whether money moved: `status`, `finality` and `funds` say so separately.
