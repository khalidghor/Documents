# 00 · Strategy and positioning — what this package is for

> Build the order and payment objects that the best omnichannel merchants, marketplaces, PayFacs, checkouts and agents would choose over Stripe's and Adyen's — and be honest about where they already lead.

## 1. The bet

ST-003 ("The Case for Intent") argues that the next decade of payments is about **intent**, not transactions: one durable object per purchase that the platform drives to an outcome across methods, rails, acquirers, retries and days — and proves it drove well. This package turns that argument into four buildable things:

1. **An Order resource** for commerce structure (catalog, lines, modifiers, sellers, fulfillment, returns, tax liability) that QSR, e-retail, retail, marketplaces and PayFacs can all use without building their own ledger.
2. **A Payment Intent resource** — one obligation to collect, ten states for every method (card, ACH, BNPL, RTP/FedNow, open banking, wallets, stored value, agent mandates).
3. **Operations and Attempts** — authorization, incremental, reauthorization, reversal, capture (single/multi), refund — as children of the intent, with lineage, and a full lifecycle that includes expiry, disputes and pre-disputes.
4. **Credential & Payments Intelligence** — insight on any credential, and NSF recovery with funds signals inside network rules.

Two ledgers (acquiring and commerce), a configuration model, an MCP server, agent skills and a developer portal make them usable.

## 2. Where Stripe and Adyen are today, and where this design aims to beat them

| Dimension | Stripe | Adyen | This design | Honest status |
|---|---|---|---|---|
| Durable payment object | PaymentIntent (since 2019) | Payments API + sessions; no single intent object across methods | Payment Intent with ten method-neutral states, `authorization`, `finality`, `funds` blocks | Parity on concept; ahead on explicit expiry/finality/funds blocks |
| Commercial order object | Orders API (beta, retired); Checkout Sessions with line items | Line items on payments; no order resource with lifecycle | Full Order with five status fields, sellers, fulfillment-driven capture, returns | Ahead, if built |
| Expiring authorizations | Merchant must track `capture_before`; extended authorization on eligible cards | Merchant tracks; adjust/extend APIs | Platform-owned expiry with policy (`reauthorize`/`notify`/`cancel`), two reauthorization modes, recorded decision | Ahead |
| Multi-capture | Supported on eligible cards | Supported (partial captures) | Supported with sequence, fulfillment groups, line allocations | Parity + line attribution |
| Refunds vs disputes | Separate objects | Separate | Refunds per capture; refunds blocked on disputed amounts; alert-driven refunds link to the alert | Parity + safety rule |
| Pre-dispute | Integrated with some alert networks; Smart Disputes | RevenueProtect, dispute alerts | Alerts as first-class resources; RDR rules generated from the same policy; CE 3.0 auto-assembly | Parity; ahead only with execution |
| Marketplace fund flows | Connect: direct, destination, separate charges & transfers, `on_behalf_of` | Adyen for Platforms: split instructions, balance accounts, `platformChargebackLogic` | Six named fund flows mapped to both; rules engine for dispute allocation with simulation; two reconciled ledgers | Parity on flows; ahead on rule simulation and the commerce ledger keyed by order lines |
| Marketplace tax liability | Stripe Tax (facilitator support) | Partner-based | Per-line liability determination, ledgered by liable party | Design parity; execution depends on the tax engine partner |
| Decisions and proof | Adaptive Acceptance, opaque | RevenueAccelerate, opaque | Decision records with propensity, fallback and rejected options; holdout-measured value | Ahead (the claim CI-001 says survives) |
| Credential intelligence | Radar signals, card metadata | Card BIN lookup, RevenueProtect signals | One insight API: BIN, issuer, cost, risk, disputes, approval with intervals, strategy | Ahead on breadth and honesty (intervals, refusals) |
| NSF recovery | Smart Retries (Billing) | Auto Rescue | Credential registrations + funds signals + managed retries inside Visa/MC/Nacha rules, measured against a holdout | Parity; ahead if network funds programmes are secured |
| Agents | Agentic Commerce Protocol, MCP server | Agentic pilots | Agents as a channel on the same Order/Intent; MCP server with money-movement guards; skills | Parity |
| Bank-owned advantages | — | — | Own liquidity, payouts on RTP/FedNow, issuer-side intelligence within the information barrier (D35) | Only if D35 allows it |

The comparison column for competitors is a summary of publicly described capabilities and will drift; re-check it before using it externally.

## 3. Decisions this package takes (and you can overturn)

| # | Decision | Alternative | Why this one |
|---|---|---|---|
| P1 | External resource named `payment_intent` (the brief), not `payment` (ST-003 Option A) | Option A | The brief asked for it; the schema is name-independent. Publish only one |
| P2 | Refunds and disputes **are** in the ten external states | Keep them off the status (DOC-000 §05 open question) | Agents and merchants act on both |
| P3 | A won dispute restores the prior state; a lost one leaves `disputed` | Return to `captured` with `amount_charged_back` | "Captured" after a lost chargeback misleads |
| P4 | Authorization expiry cancels the intent only when nothing was captured and no reauthorization is permitted | Always cancel (Stripe-like) | Keeps the purchase's identity through backorders |
| P5 | Two reauthorization modes, chosen per intent (`auto`: debit/prepaid → reverse-then-reauth) | One mode | Credit and debit fail differently |
| P6 | Partial authorization modelled (`reject` / `accept_and_collect_remainder` / `accept_and_reduce`) | Leave unmodelled | ST-003 §07 names it a gap |
| P7 | `failed` is re-confirmable when `retryability.retryable` | Terminal; new intent per retry | One identity per purchase |
| P8 | ACH `captured` on acceptance with a finality block | `processing` through the return window | D86's proposal |
| P9 | The order has five status fields | One combined status | Five different questions |
| P10 | Two ledgers with a control-account invariant | One ledger with seller sub-accounts | Different keys (payment vs. line), different owners, same truth |
| P11 | Dispute allocation is a signed, simulated rule set, first match wins | Fixed per-seller liability flag | The market's strategies need predicates |
| P12 | No PAN in the MCP server, ever | PAN tools for agents | PCI scope |

## 4. Open items before anyone builds this

1. **Network and Nacha rule values** in `config/` are marked `verify_before_production`. Confirm with scheme compliance.
2. **Network funds-availability notifications**: the API is ready; whether Visa/Mastercard offer a push programme for this use is a commercial negotiation. Until then, MACs, open banking and the internal model carry it.
3. **Tax regimes**: confirm every regime and threshold with tax counsel; choose the tax-engine partner.
4. **Information barrier (D35)**: decide which issuer-side signals, if any, may reach credential intelligence.
5. **Option A vs. this package's naming (P1)** — settle before the contract is published (D85).
6. **Data classification and retention per domain** (ST-003 §31 gap) — `platform.yaml` has placeholders only.
7. **Sandbox fidelity**: test clocks and scenario cards are specified, not built; they are what makes the lifecycle learnable.
