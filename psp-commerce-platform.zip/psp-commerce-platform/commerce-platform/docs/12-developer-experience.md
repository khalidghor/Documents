# 12 · Developer experience — the Payments Developer Portal (PDP)

> ST-003 §33: a domain model does not by itself produce a Stripe-class developer experience. This chapter is the portal's information architecture, the API conventions every resource follows, the event catalog, the sandbox, and how time-dependent lifecycles (expiry, disputes, NSF) are made testable in minutes.

## 1. Portal information architecture

```
Payments Developer Portal
├── Get started
│   ├── Quickstart: accept a payment in 10 minutes (Payment Intent + hosted session)
│   ├── Quickstart: create and pay an order (Order → Payment Intent)
│   ├── Quickstart: marketplace in an afternoon (sellers, allocations, payouts)
│   └── Keys, modes, API versions
├── Concepts
│   ├── The resource model (01)               ├── Payment lifecycle (05)
│   ├── Orders (02)                           ├── How payments move orders (06)
│   ├── Payment Intents (03)                  ├── Disputes (07)
│   ├── Operations & attempts (04)            ├── Marketplaces & ledgers (08)
│   └── Four state models                     └── Credential intelligence (09), NSF (10)
├── Guides by industry (11): QSR · e-retail · retail · marketplace · PayFac · enterprise · agentic
├── API reference (generated from openapi/*.yaml — never hand-written)
│   Orders · Catalog · Payment Intents · Operations · Attempts · Disputes · Dispute alerts ·
│   Sellers · Allocations · Ledgers · Transfers · Payouts · Credential insights · Registrations · Funds signals ·
│   Capabilities ("can I?") · Events & webhooks · Test helpers
├── Events & webhooks: catalog, payloads, signing, replay
├── Errors: canonical result codes, retryability, error types
├── Testing: test cards, test bank accounts, scenario cards, test clocks, simulators
├── SDKs & tools: Node, Python, Java, Go, .NET, iOS, Android, CLI, Postman, MCP server, agent skills
├── Changelog & versioning
└── Status & support
```

The portal is generated: API reference from the OpenAPI files; event payloads from the same schemas; error tables from the canonical-result registry; test scenarios from the sandbox's scenario registry. A field that is not in the spec does not exist.

## 2. Conventions every endpoint follows

| Convention | Rule |
|---|---|
| Base URLs | `https://api.<psp>.com/v1` · PCI host `https://pci.<psp>.com/pci/v1` (the only place a PAN is accepted) · sandbox `https://sandbox.api.<psp>.com/v1` |
| Auth | `Authorization: Bearer sk_live_…` / `sk_test_…`; restricted keys with per-resource scopes; OAuth for platforms acting for connected accounts (`On-Behalf-Of: acct_…`) |
| Versioning | Date versions (`Psp-Version: 2026-11-15`), pinned per account at first call; additive changes are not versioned; breaking changes ship behind a new date with a migration guide and a compatibility window |
| Idempotency | `Idempotency-Key` **required** on every POST; 24h replay of the original response; same key + different body → `409 idempotency_conflict` |
| Concurrency | Orders are versioned; `If-Match: <version>` on updates; `409 version_conflict` on mismatch |
| IDs | Prefixed, opaque, ≤ 64 chars (`ord_`, `pi_`, `op_`, `att_`, `dp_` …) |
| Money | Integer minor units + ISO-4217 currency; decimal quantities as strings |
| Time | RFC 3339 UTC; local times include offset where business-meaningful (pickup windows) |
| Expansion | `expand[]=operations.attempts`, `expand[]=payments` up to 3 levels |
| Pagination | Cursor (`starting_after`, `ending_before`, `limit ≤ 100`), `has_more` |
| Filtering | `created[gte]`, `status`, `order_id`, `seller_id` … documented per list |
| Errors | `{ error: { type, code, message, param, request_id, result?, doc_url } }`; `type ∈ invalid_request, authentication, permission, idempotency, conflict, rate_limit, api` and payment results carried as a canonical `result` |
| Metadata | 50 keys × 500 chars on every resource; never used by the platform for decisions |
| Rate limits | Per key and per resource family; `429` with `Retry-After` |
| Request IDs | `Request-Id` on every response; quoted in logs and support |

## 3. The canonical result (errors that mean the same thing everywhere)

```json
{
  "outcome": "declined",
  "decided_by": "issuer",
  "reason": "insufficient_funds",
  "class": "soft",
  "retryability": { "retryable": true, "retry_after": "2026-11-28T09:00:00Z", "attempts_remaining_under_network_rules": 14 },
  "customer_message_key": "card_declined_try_again_later",
  "network_advice": { "source": "mastercard_mac", "code": "25" }
}
```

One `reason` enumeration covers every method (`insufficient_funds` is the same for a card `51`, an ACH `R01` and a BNPL "limit exceeded"). Processor codes are never exposed; `network_advice` is summarized because merchants must obey it.

## 4. Webhooks

* At-least-once, signed (`Psp-Signature: t=…, v1=HMAC-SHA256`), monotonic `sequence` per resource, idempotent `event.id`.
* Retries with exponential backoff for 3 days; dead-letter; **replay** from the portal or `POST /v1/events/{id}/redeliver`.
* Thin events with `data.object` snapshot and `data.previous_attributes`; `cause` links an order event to the payment event that produced it.

## 5. Event catalog

| Family | Events |
|---|---|
| Order | `order.created`, `order.placed`, `order.confirmed`, `order.on_hold`, `order.updated`, `order.payment_status_changed`, `order.payment_attention_required`, `order.payment_exception`, `order.fulfillment_updated`, `order.completed`, `order.canceled`, `order.expired`, `order.return_created`, `order.return_received`, `order.refunded`, `order.dispute_updated`, `order.closed` |
| Payment Intent | `payment_intent.created`, `.requires_action`, `.processing`, `.authorized`, `.partially_authorized`, `.amount_increased`, `.authorization_expiring`, `.reauthorized`, `.reauthorization_failed`, `.authorization_expired`, `.authorization_released`, `.partially_captured`, `.captured`, `.capture_failed`, `.payment_failed`, `.retry_scheduled`, `.retry_succeeded`, `.retries_exhausted`, `.canceled`, `.refund.created`, `.refund.succeeded`, `.refund.failed`, `.partially_refunded`, `.refunded`, `.disputed`, `.dispute.closed`, `.finality_changed`, `.funds.available`, `.ach_return` |
| Dispute | `dispute_alert.created`, `dispute_alert.resolved`, `dispute.inquiry_opened`, `dispute.created`, `dispute.updated`, `dispute.evidence_requested_from_seller`, `dispute.evidence_submitted`, `dispute.won`, `dispute.lost`, `dispute.pre_arbitration`, `dispute.closed` |
| Marketplace | `seller.created`, `seller.updated`, `seller.requirements_due`, `allocation.created`, `balance.available`, `transfer.created`, `transfer.reversed`, `payout.paid`, `payout.failed`, `seller.negative_balance`, `reserve.updated` |
| Intelligence | `credential.updated`, `credential.funds_signal`, `credential_registration.expired`, `issuer.approval_anomaly` |
| Advanced | `operation.created`, `operation.succeeded`, `operation.failed`, `attempt.completed` (opt-in) |

## 6. Sandbox — making time-dependent lifecycles testable

Payments lifecycles take days to months. The sandbox makes them take seconds.

| Tool | Endpoint | Use |
|---|---|---|
| **Test clocks** | `POST /v1/test_helpers/test_clocks`, `…/{id}/advance` | Attach orders/intents to a clock; advance 9 days to trigger `authorization_expiring` and reauthorization; advance 45 days for dispute windows |
| **Scenario cards** | Test PANs (see repository README) + scenario tokens like `pm_card_reauth_declines`, `pm_card_nsf_then_funds_day_3`, `pm_card_partial_auth_80pct`, `pm_card_dispute_not_received` | Deterministic outcomes for every branch in chapter 05 |
| **Dispute simulator** | `POST /v1/test_helpers/payment_intents/{id}/dispute {reason, network, stage}` | Create alerts, chargebacks, pre-arbitration |
| **Alert simulator** | `POST /v1/test_helpers/dispute_alerts {source: ethoca|cdrn|rdr}` | Test prevention rules |
| **ACH returns** | `POST /v1/test_helpers/payment_intents/{id}/ach_return {code: R01}` | NSF and unauthorized returns |
| **Funds signals** | `POST /v1/test_helpers/credential_registrations/{id}/signal` | Exercise managed retries |
| **Settlement & payouts** | `POST /v1/test_helpers/settlements/run` | Move funds to available, run payouts, see both ledgers |
| **Unknown outcomes** | Scenario card `timeout_then_approved` | See recovery own a timeout |

Every sandbox scenario is also a **contract test**: the SDKs' test suites run them nightly against the sandbox.

## 7. SDKs, CLI and tooling

* Generated SDKs (Node, Python, Java, Go, .NET, Ruby, PHP) from the OpenAPI files, hand-finished for idempotency helpers, webhook verification, pagination iterators, and typed events.
* Mobile SDKs (iOS, Android) and web elements for sessions (card, wallet, bank, BNPL), 3DS and redirects.
* Terminal SDK for card-present (sessions with `channel: terminal`).
* CLI: `psp listen` (forward webhooks to localhost), `psp trigger payment_intent.authorization_expiring`, `psp clocks advance`, `psp logs tail`.
* Postman collection and OpenAPI files downloadable from the portal.
* **MCP server and agent skills** — [13](13-mcp-and-skills.md).

## 8. How DX is measured

Time to first successful payment (sandbox), time to first live payment, time to production for each playbook, webhook delivery success, support tickets per 1,000 integrations, and SDK error rates by `code` (a code that many integrators trip on is a design bug, not a documentation bug).
