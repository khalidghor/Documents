# 11 · Industry playbooks — the same resources, five businesses

> One Order, one Payment Intent, one set of operations. What differs by industry is the **collection plan**, the **capture trigger**, the **authorization type** and a few profile defaults. Each playbook is a recipe of API calls with the states you will see. JSON request bodies for each are in [`examples/`](../examples).

Profiles are set by `order.industry_profile` and expand to defaults in [`config/order-profiles.yaml`](../config/order-profiles.yaml).

---

## 1. QSR — order-ahead, drive-thru, table service, delivery

| Default | Value |
|---|---|
| Collection plan | `pay_now` (counter, kiosk, app order-ahead), `authorize_then_capture_on_close` (table service, bar tabs) |
| Authorization type | `estimated` where tips are expected |
| Capture trigger | On order close (after tip) or immediately |
| Overcapture tolerance | Per network rules for MCC 5812/5813/5814 (commonly 20% for tips) |
| Offline | Store-and-forward allowed below a floor amount; deferred authorization risk tracked |

**Order-ahead in the app (pickup at 12:15)**

1. `POST /v1/orders` with lines and nested modifiers (`Burger → no onions; Combo → Drink → Large → Diet`), `fulfillment_groups: [{method: pickup_in_store, promised_at: 12:15, location_id}]`, `collection_plan: pay_now`.
2. `POST /v1/orders/{id}/place` → the order creates `pi_` and returns its `client_secret`; the app confirms with a wallet → intent `captured`, order `confirmed`, kitchen ticket fired at `promised_at − prep_time` (by station from `kitchen_station` attributes).
3. Item unavailable → `POST /v1/orders/{id}/amend` cancels the line → automatic partial refund (captured) → order `partially_refunded`.

**Table service with tip**

1. Open check: `POST /v1/orders` (`authorize_then_capture_on_close`), card dipped → `authorized` $64.20 (estimated).
2. Guests add dessert → `amend` adds lines; if over tolerance, `increment_authorization`.
3. Tip entered on the receipt → `POST /v1/orders/{id}/close {tip: 1200}` → capture $76.20 (within tolerance) → `captured`; tip credited to `tips:payable:staff` in the commerce ledger.

**Third-party delivery (aggregator)**: the aggregator is a **channel** (`channel.type: marketplace_partner`) — if the aggregator is MoR, the restaurant receives an order with `collection_plan: externally_collected` and the payment is a non-PSP tender recorded on the order. If the restaurant is MoR (white-label delivery), it is an ordinary intent with `fulfillment.method: delivery_third_party` and a delivery fee line payable to the courier.

**Split the bill by guest**: one order, several intents, each allocated to the guest's lines (or to equal shares), each captured independently.

---

## 2. E-retail — split shipments, backorders, pre-orders

| Default | Value |
|---|---|
| Collection plan | `authorize_then_capture_on_fulfillment` |
| Capture method | `multi` |
| Authorization type | `estimated` (if eligible) else `final` per network |
| Expiry policy | `reauthorize` (stored-credential consent collected at checkout) |
| Partial authorization | `reject` |

**Split shipment + backorder** — exactly the walkthrough in [05](05-payment-lifecycle.md) §10: capture seq 1 on the first shipment, reauthorize the remainder before expiry, capture seq 2 final on the last shipment.

**Pre-order (ships in 6 weeks)**: `verify_now_charge_later` → `$0` verification on confirm (stored credential `first`), order `confirmed`, `payment_status: unpaid`; at release, the collection plan creates an MIT intent with `automatic` capture. The order gets `payment_exception` if it declines, and NSF retry rules apply.

**Return by mail**: `POST /v1/orders/{id}/returns` (lines, reason) → label → on receipt `POST /v1/returns/{id}/receive {condition}` → refund plan executes partial refund(s) against the capture(s) that paid for the lines.

**BOPIS**: fulfillment `pickup_in_store`; capture on handover (`POST /v1/orders/{id}/fulfillments/{fg}/complete`); unclaimed after N days → cancel lines → reversal.

---

## 3. Retail — card present, multi-tender, layaway, exchanges

| Default | Value |
|---|---|
| Collection plan | `pay_now` with `split_tender` |
| Partial authorization | `accept_and_collect_remainder` |
| Capture | `automatic` (sale) |
| Offline | Store-and-forward per terminal profile |

**Multi-tender**: order total $150 → gift card intent captures $50 → card intent is partially approved for $80 → POS prompts → cash $20 recorded as a tender → order `collected` (see [06](06-order-payment-reflection.md) §3).

**Return without receipt**: lookup by card fingerprint (the credential intelligence fingerprint — never the PAN) finds the original order → refund to the original method; if none is found, merchant policy issues store credit (stored-value liability in the commerce ledger).

**Uneven exchange**: return line + new line on the same order → net difference collected (new intent) or refunded (refund operation).

**Layaway**: `deposit_then_balance` → deposit intent `captured` now, balance intent created at pickup (or by schedule under a mandate); cancellation refunds the deposit less a policy fee.

---

## 4. Marketplace

| Default | Value |
|---|---|
| Fund flow | `platform_mor_separate_transfers` (or per seller) |
| Collection plan | `authorize_then_capture_on_fulfillment` per seller order |
| Capture | `multi`, one capture per seller shipment |
| Disputes | Allocation rules ([08](08-marketplace-and-ledgers.md) §5) |
| Tax | Facilitator determination per line |

Calls: create sellers (`POST /v1/sellers`, KYB via onboarding link) → create the order with `seller_id` on each line → the platform derives `seller_orders[]` with commission and tax responsibility → sellers fulfil their own groups (captures per group) → seller balances pending → available after delivery + delay → payouts. Refunds and disputes follow lines to sellers. See the worked ledger example in [08](08-marketplace-and-ledgers.md) §4.

---

## 5. PayFac / ISV platform

`fund_flow: payfac_submerchant`; each sub-merchant is onboarded (`POST /v1/sellers` with `role: submerchant`), has its own MID/descriptor; intents carry `on_behalf_of: sel_…`; platform fees via `application_fee` allocations; the PayFac is liable for sub-merchant negative balances; orders optional.

---

## 6. Enterprise omnichannel (with its own OMS)

Integrate at the Payment Intent level with `order_reference`; optionally mirror the OMS order into the Order resource (lines and fulfillment events only) to gain line-level refunds, dispute evidence and allocation, without moving the OMS. The same customer pays in-store (terminal session → intent), online (web session → intent) and via an agent (agent session → intent); one customer and one credential across channels, because the vault keys credentials to the consent holder, not the channel.

---

## 7. Agentic checkout

An agent creates the order through the MCP server or the API under a delegated mandate; `order.buyer_agent = {agent_id, mandate: mdt_…@v}`; constraint binding checks the mandate's scope and headroom before any attempt; step-up above the mandate's threshold sends the intent to `requires_action` with `action.type: consumer_confirmation`; the purchase evidence record holds the authority record for any later dispute.
