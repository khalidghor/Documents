# 08 · Marketplaces, two ledgers, tax liability and dispute allocation

> A marketplace needs two answers that a payments API alone cannot give: **where is the money** (the acquiring ledger) and **who owes what to whom** (the commerce ledger). The first is keyed by payments; the second by orders, line items and sellers. They reconcile to each other through one control account, every day, to the cent.

## 1. Parties and roles

| Role | Who | Examples of what it decides |
|---|---|---|
| **PSP** (us) | Acquirer / payment facilitator of record; operates both ledgers | Pricing, reserves, network compliance, KYC/KYB |
| **Platform / marketplace** | Our client operating the marketplace or SaaS platform | Commission, fees, promotions, dispute policy, payout schedule |
| **Seller** (`sel_`) | A business selling through the platform | Its catalog, fulfillment, returns; responds to disputes when asked |
| **Merchant of record (MoR)** | The party legally selling to the buyer; on the statement descriptor; contracts with the cardholder | Determined by the fund-flow model |
| **Settlement merchant** | The party whose MID the transaction is processed under | Determines interchange profile, descriptor, network liability |
| **Liable party** | Who bears refunds, disputes and negative balances *in fact* | Configured per fund-flow model and rules |
| **Tax-liable party** | Who must collect and remit sales tax / VAT for a line | Determined per line and jurisdiction |

## 2. Fund-flow models

Every platform account picks one default model; it can be overridden per seller or per order. The names are ours; the right column maps them to what the market already knows.

| Model (`fund_flow`) | MoR | Settlement merchant | Disputes debited from | Refunds funded by | Negative balances | Equivalent elsewhere |
|---|---|---|---|---|---|---|
| `platform_mor_separate_transfers` | Platform | Platform | Platform balance; recovered from seller by rule (transfer reversal) | Platform; recovered from seller by rule | Platform | Stripe Connect *separate charges and transfers* |
| `platform_mor_destination` | Platform | Platform | Platform; auto-reversal of the seller transfer by rule | Platform, reversal of transfer | Platform | Stripe Connect *destination charges* |
| `seller_mor_on_behalf_of` | Seller | Seller (descriptor, MCC, country) | Seller balance | Seller | Platform (contractually liable to PSP) | Stripe Connect *destination charges with on_behalf_of* |
| `seller_mor_direct` | Seller | Seller | Seller | Seller | Seller, then platform per agreement | Stripe Connect *direct charges* |
| `split_at_authorization` | Platform or seller (per `liable_account`) | Platform | Per `chargeback_logic` | Per split | Liable account | Adyen for Platforms *split instructions* with `platformChargebackLogic` |
| `payfac_submerchant` | Sub-merchant | Sub-merchant under the PayFac MID | Sub-merchant | Sub-merchant | PayFac (liable to the acquirer) | Classic PayFac / ISV |

Two consequences drive the rest of the design:

1. **The fund-flow model decides who is debited first; the rules decide who bears it last.** A platform-MoR marketplace is debited first for every chargeback (it is the merchant), and then recovers from the seller according to its allocation rules. A seller-MoR marketplace is the reverse.
2. **Payment allocations must exist at capture time.** Without knowing which lines (and therefore which sellers) a capture paid for, nothing downstream can be attributed. That is why `payment_intent.allocations[]` is populated from the order and why multi-capture carries line allocations.

## 3. The two ledgers

### 3.1 Acquiring ledger — "where is the money"

Owned by the PSP, per legal entity. Derived from the payment journal (never written directly). Keyed by **merchant account × currency × availability**. It is the PD-001 §12 ledger.

| Account | Normal balance | Moves on |
|---|---|---|
| `scheme_receivable` | Dr | Capture (Dr), settlement (Cr), refund (Cr-side payable) |
| `settlement_cash:<bank>` | Dr | Network/acquirer settlement, payouts, chargeback debits |
| `merchant_payable:<acct>:pending/available/reserved` | Cr | Capture (Cr), fees (Dr), refunds (Dr), disputes (Dr), payouts (Dr) |
| `interchange_and_scheme_fees` | Dr | Clearing |
| `psp_fee_revenue` | Cr | Per pricing plan |
| `dispute_fee_revenue` | Cr | Chargeback fees |
| `merchant_reserve:<acct>` | Cr | Rolling / fixed reserves |
| `negative_balance_receivable:<acct>` | Dr | When a merchant payable goes below zero |

### 3.2 Commerce ledger — "who owes what to whom"

Owned by the PSP **on behalf of the platform**; one book per platform account. Derived from order, allocation and payment events. Keyed by **party × purpose × currency**. Its total equals the platform's `merchant_payable` in the acquiring ledger (the control account).

| Account | What it holds |
|---|---|
| `psp_receivable` | Mirror of the platform's merchant payable at the PSP (the control account) |
| `seller:<id>:pending` | Earned but not yet available to the seller (awaiting delivery, hold period, settlement) |
| `seller:<id>:available` | Payable to the seller on the next payout |
| `seller:<id>:reserve` | Held against future refunds/disputes (rolling or fixed) |
| `seller:<id>:dispute_hold` | Funds frozen for an open dispute allocated to the seller |
| `seller:<id>:receivable` | Negative balance owed by the seller to the platform |
| `platform:commission_revenue` | Commission and platform fees |
| `platform:processing_fee_expense` | PSP fees borne by the platform |
| `platform:promotion_expense` | Promotions funded by the platform |
| `platform:dispute_loss` | Disputes the platform absorbs |
| `tax:<jurisdiction>:payable:<liable_party>` | Tax collected, by who must remit it |
| `tips:payable:<recipient>` | Pass-through gratuities (QSR, delivery) |
| `buyer:store_credit`, `buyer:gift_card` | Stored-value liabilities |

### 3.3 The control invariant

```
acquiring.merchant_payable(platform)  ==  Σ commerce ledger balances (all accounts except psp_receivable)
                                      ==  commerce.psp_receivable
```

checked continuously and at every UTC day close. A break opens a reconciliation case; it is never "plugged".

## 4. Worked example — both ledgers, to the cent

**Setup.** Platform *MarketCo* is MoR (`platform_mor_separate_transfers`). The buyer ships to a US state with a marketplace-facilitator law, so MarketCo is tax-liable. Commission 15% of item price. Seller-charged shipping passes to the seller. PSP pricing 2.9% + $0.30 per capture, borne by MarketCo. Refund policy: commission refunded less a 20% admin fee (cap $5). Chargeback policy for seller-fulfilled "not received": seller liable, fee passed to seller, commission retained, tax reversed.

**Order** `ord_8Kd2` = $118.00

| Line | Seller | Item | Tax 10% | Shipping | Capture |
|---|---|---|---|---|---|
| li_1 Headphones | A | 60.00 | 6.00 | 4.00 | 70.00 (seq 1) |
| li_2 Case | B | 40.00 | 4.00 | 4.00 | 48.00 (seq 2, final) |

### Step 1 · Capture 1 ($70.00) and fee ($2.33)

| Ledger | Dr | Cr | Amount |
|---|---|---|---|
| Acquiring | scheme_receivable | merchant_payable:MarketCo | 70.00 |
| Acquiring | merchant_payable:MarketCo | psp_fee_revenue | 2.33 |
| Commerce | psp_receivable | seller:A:pending | 55.00 (60 + 4 − 9) |
| Commerce | psp_receivable | platform:commission_revenue | 9.00 |
| Commerce | psp_receivable | tax:US-XX:payable:marketplace | 6.00 |
| Commerce | platform:processing_fee_expense | psp_receivable | 2.33 |

### Step 2 · Capture 2 ($48.00) and fee ($1.69)

| Ledger | Dr | Cr | Amount |
|---|---|---|---|
| Acquiring | scheme_receivable | merchant_payable:MarketCo | 48.00 |
| Acquiring | merchant_payable:MarketCo | psp_fee_revenue | 1.69 |
| Commerce | psp_receivable | seller:B:pending | 38.00 (40 + 4 − 6) |
| Commerce | psp_receivable | platform:commission_revenue | 6.00 |
| Commerce | psp_receivable | tax:US-XX:payable:marketplace | 4.00 |
| Commerce | platform:processing_fee_expense | psp_receivable | 1.69 |

### Step 3 · Partial refund of li_2 ($44.00 = item 40 + tax 4; shipping not refunded)

Admin fee = min(20% × 6.00, 5.00) = 1.20, so commission refunded = 4.80.

| Ledger | Dr | Cr | Amount |
|---|---|---|---|
| Acquiring | merchant_payable:MarketCo | scheme_receivable (refund) | 44.00 |
| Commerce | seller:B:pending | psp_receivable | 35.20 (40 − 4.80) |
| Commerce | platform:commission_revenue | psp_receivable | 4.80 |
| Commerce | tax:US-XX:payable:marketplace | psp_receivable | 4.00 |

Seller B is left with 2.80 (= 4.00 shipping − 1.20 admin fee). MarketCo kept 1.20 of B's commission.

**Control check after step 3.**
Acquiring: 70 − 2.33 + 48 − 1.69 − 44 = **69.98**.
Commerce: A 55.00 + B 2.80 + commission 10.20 + tax 6.00 − fees 4.02 = **69.98** ✓

### Step 4 · Chargeback lost on capture 1 ($70.00 + $15.00 fee), seller A liable

| Ledger | Dr | Cr | Amount |
|---|---|---|---|
| Acquiring | merchant_payable:MarketCo | settlement_cash (network debit) | 70.00 |
| Acquiring | merchant_payable:MarketCo | dispute_fee_revenue | 15.00 |
| Commerce | seller:A:pending | psp_receivable | 64.00 (70 − tax 6; commission retained) |
| Commerce | tax:US-XX:payable:marketplace | psp_receivable | 6.00 (reversed where the jurisdiction permits) |
| Commerce | seller:A:pending | psp_receivable | 15.00 (fee passed through) |

Seller A: 55.00 − 79.00 = **−24.00** → the recovery waterfall (§5.4) moves it to `seller:A:receivable` and recovers it from A's reserve and future sales.

**Control check after step 4.** Acquiring: 69.98 − 85.00 = **−15.02**. Commerce: −24.00 + 2.80 + 10.20 + 0.00 − 4.02 = **−15.02** ✓ (MarketCo's negative balance at the PSP is covered by its other sales or its reserve.)

The same example is executed as a test in [`reference/marketplace-ledger.test.ts`](../reference/marketplace-ledger.test.ts).

### Variant — commission refunded on chargeback

With `commission_on_chargeback: refund`, step 4 debits seller A 55.00 + 15.00 = 70.00, commission 9.00, tax 6.00. Seller A ends at −15.00; MarketCo's commission falls to 1.20. Platforms choose; the ledger does not care, but the choice must be in the seller agreement.

## 5. Dispute allocation — the rules engine

### 5.1 Strategies in the market, and how each is expressed here

| Strategy | Where it comes from | Rule expression |
|---|---|---|
| **Platform absorbs** | Platforms that own risk decisions and the customer relationship (some delivery apps, platform-MoR marketplaces for fraud) | `liable: platform` |
| **Pass through to the seller of the disputed lines** | Most marketplaces for product disputes | `liable: seller_of_lines` |
| **Pro rata by split** | Adyen `deductAccordingToSplitRatio` | `liable: pro_rata_by_allocation` |
| **Designated liable account** | Adyen `deductFromLiableAccount`; Stripe direct charges | `liable: liable_account` |
| **Single account** | Adyen `deductFromOneBalanceAccount` | `liable: account, account: <id>` |
| **By reason code** | Fraud → whoever made the risk/authentication decision; not-received → whoever fulfilled; not-as-described → seller; credit-not-processed → whoever held the refund obligation; processing error → platform | `when: reason in […]` |
| **By fulfillment** | Marketplace-fulfilled (platform warehouse) → platform; seller-fulfilled → seller | `when: fulfillment.by = marketplace` |
| **Guarantee programmes** | A-to-z / money-back / purchase-protection style: the platform covers sellers who met conditions (tracking uploaded, shipped on time, signature over a threshold) | `when: seller.protection_eligible and evidence.has(tracking)` → `liable: platform` |
| **Threshold / tier** | Platform absorbs small disputes (cheaper than recovery) or for top-tier sellers | `when: amount <= 2500 or seller.tier = gold` |
| **Fee separate from amount** | Fee to platform, amount to seller (or the reverse) | `fee_bearer: platform \| seller \| liable` |
| **Who responds** | Platform responds with seller evidence on request; seller responds directly; collaborative with SLA and default | `responder: platform \| seller \| platform_with_seller_evidence` |

### 5.2 Rule format

Rules are an ordered list; the first match wins; a default rule is mandatory. They are versioned, signed and simulated before publication (`POST /v1/dispute_allocation_rules/simulate` replays the last 90 days of disputes and shows who would have borne what).

```yaml
# config/marketplace/dispute-allocation-rules.yaml (excerpt)
- id: dar_fraud_platform_decisioned
  when:
    reason.category: fraud
    payment.risk_decision_owner: platform        # the platform's risk/3DS policy approved it
  then: { liable: platform, responder: platform, fee_bearer: platform }

- id: dar_not_received_marketplace_fulfilled
  when: { reason.category: not_received, fulfillment.by: marketplace }
  then: { liable: platform, responder: platform, fee_bearer: platform }

- id: dar_not_received_seller_fulfilled
  when: { reason.category: not_received, fulfillment.by: seller }
  then:
    liable: seller_of_lines
    responder: platform_with_seller_evidence
    seller_evidence_sla: 5d
    on_seller_no_response: accept_and_charge_seller
    fee_bearer: seller
    hold: { when: dispute_opened, amount: disputed_amount }
```

### 5.3 What "seller of lines" means when a dispute spans sellers

A dispute names one capture; a capture may pay for lines of several sellers (single-capture orders). The allocation uses the capture's `line_allocations`:

1. If `disputed_lines` is known (from Order Insight data, or the merchant's matching), only those lines' sellers are liable.
2. Otherwise, pro rata by each seller's share of the capture.
3. Tax and shipping follow their line; platform fees follow the fee rule.

### 5.4 Recovery waterfall (negative seller balances)

When a liable seller's balance cannot cover a loss:

1. `seller:<id>:available`
2. `seller:<id>:pending` (future earnings already captured)
3. `seller:<id>:reserve`
4. Net against the next payouts (`seller:<id>:receivable`, recovered first from each future capture)
5. Debit the seller's bank account (only with a debit mandate on file)
6. Platform absorbs to `platform:dispute_loss`; collections case opened

The platform is always liable to the PSP for its own negative merchant payable — the waterfall governs only how the platform recovers from sellers.

## 6. Tax liability

### 6.1 The determination

For **each line and each jurisdiction**, the tax module (adapter over a tax engine such as Avalara, Vertex or an in-house engine) returns:

| Field | Values |
|---|---|
| `liable_party` | `seller`, `marketplace_facilitator`, `deemed_supplier` (platform), `buyer_reverse_charge`, `none` |
| `collected_by` | `platform`, `seller` |
| `remitted_by` | `platform`, `seller` |
| `invoice_issuer` | Who must issue the tax invoice |
| `rate`, `taxable_amount`, `tax_amount`, `inclusive` | From the engine |
| `rule_ref` | The jurisdiction rule that decided liability |

Inputs: ship-to, ship-from, seller establishment and registrations, platform registrations, product tax code, B2B (tax id) or B2C, consignment value (imports), who fulfils, and whether the platform "facilitates" the sale under that jurisdiction's definition.

### 6.2 Regimes the defaults cover (verify with tax counsel per jurisdiction)

| Regime | Platform is liable when | Notes |
|---|---|---|
| US marketplace facilitator laws (every state with a sales tax, plus DC) | It facilitates the sale and crosses the state's threshold | Seller is relieved for those sales; platform collects, remits and reports |
| EU VAT e-commerce package (2021) | Imports ≤ €150 consignments to consumers; or EU supplies by non-EU-established sellers to consumers | Platform is the deemed supplier; IOSS for imports |
| UK | Goods in the UK sold by overseas sellers to consumers; imports ≤ £135 | Platform is deemed supplier |
| Australia | Low-value imported goods ≤ A$1,000 to consumers; some digital supplies | Platform liable for GST |
| India | E-commerce operators collect tax at source (TCS) under GST on seller supplies | Withholding, not full liability |
| Canada | Platform operators for certain GST/HST and provincial supplies by non-registered sellers | Federal and provincial rules differ |

Configured in [`config/marketplace/tax-responsibility.yaml`](../config/marketplace/tax-responsibility.yaml). This package is a model, not tax advice.

### 6.3 Ledger consequences

* Tax collected is credited to `tax:<jurisdiction>:payable:<liable_party>`. If the seller is liable, it is paid out with the seller's funds (and reported); if the platform is liable, it is retained and remitted by the platform.
* **Refunds** reverse the tax on the refunded lines (credit note).
* **Lost chargebacks**: some jurisdictions permit a tax adjustment (bad debt / returned-sale relief) and some do not; the rule decides between `reverse_if_permitted` and `retain`.
* **Commission** is the platform's supply to the seller and may itself be subject to VAT/GST (often reverse-charged B2B across borders).
* **Information reporting**: US Form 1099-K (thresholds in config — they have changed repeatedly), EU DAC7 seller reporting, and equivalents — produced from the commerce ledger by seller and year.

## 7. Payouts, reserves and holds

* **Payout schedule** per seller: daily / weekly / on delivery confirmation; `delay_days` after capture or after delivery.
* **Reserves**: rolling (x% for n days), fixed (minimum balance), or event-based (dispute ratio breach, new seller, high-risk category). Reserves move `available → reserve` in the commerce ledger; the acquiring ledger is unchanged until the platform's own reserve moves.
* **Holds**: `dispute_hold` for open disputes (by rule), `fulfillment_hold` until delivery confirmation (common for new sellers), `compliance_hold` (KYC refresh).
* **Transfers** (`tr_`) move value between commerce-ledger parties (platform → seller); **payouts** (`po_`) move value out of the PSP to a bank account and touch both ledgers.

## 8. PayFacs and ISVs

A PayFac uses the same machinery with `fund_flow: payfac_submerchant`: each sub-merchant is a seller-like party with its own KYB, MCC, descriptor and liability; the commerce ledger is the PayFac's sub-merchant ledger; the PayFac is liable to us for every negative sub-merchant balance. The order resource is optional for them; the allocation is one sub-merchant per intent (`on_behalf_of`).
