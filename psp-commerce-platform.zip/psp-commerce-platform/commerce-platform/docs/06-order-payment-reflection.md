# 06 · How the payment lifecycle reflects on the order

> The order never reads a processor code and never decides how to retry. It subscribes to its Payment Intents' events and projects them onto its own five status fields, its timeline and its commerce ledger — deterministically, so the same events always produce the same order.

## 1. The projection rule

The order's `payment_status`, `settlement_status` and `dispute_status` are **pure functions** of:

1. the order's balance due (total − canceled lines − non-PSP tenders),
2. the set of Payment Intents on the order and their allocations,
3. each intent's amounts (`amount_authorized` live, `amount_captured`, `amount_refunded`, `amount_charged_back`), `status`, `funds.status` and open disputes.

`status` and `fulfillment_status` are driven by fulfillment and staff actions, but **payment events can move them** in four cases: placement (pending → confirmed), payment exceptions (→ on_hold), cancellation through payment failure, and closure (dispute window elapsed).

The reference implementation of the projection is [`reference/order-projection.ts`](../reference/order-projection.ts), with tests for every row below.

```
payment_status =
  if Σ refunded > 0 and Σ refunded = Σ captured and Σ captured > 0          → refunded
  elif Σ refunded > 0                                                         → partially_refunded
  elif uncovered_balance > 0 and an exception is open                         → payment_exception
  elif Σ captured ≥ balance_due and balance_due > 0                           → collected
  elif Σ captured > 0                                                         → partially_collected
  elif Σ live capturable ≥ balance_due                                        → authorized
  elif Σ live capturable > 0                                                  → partially_authorized
  elif any intent requires_action                                             → requires_action
  else                                                                        → unpaid
```

## 2. The reflection matrix

Each row: a Payment Intent event → what the order does. "Policy" refers to the collection plan.

### 2.1 Authorization phase

| Intent event | Order `status` | `payment_status` | Other effects |
|---|---|---|---|
| `payment_intent.requires_action` | `pending` (or stays) | `requires_action` | Checkout surfaces the action; inventory hold extended to the action's expiry |
| `payment_intent.processing` | unchanged | unchanged | Nothing for the merchant to do; UI shows "processing" |
| `payment_intent.authorized` (covers balance) | `pending → confirmed` | `authorized` | Inventory hold converted to allocation; kitchen ticket fired (QSR); seller orders released to sellers |
| `payment_intent.authorized` partial (`partial_authorization: accept`) | stays `pending` | `partially_authorized` | POS/checkout prompts for next tender; new intent for the remainder |
| `payment_intent.payment_failed` retryable | stays `pending` | `unpaid` | Checkout offers retry or another method; order hold continues until `pending_expires_at` |
| `payment_intent.payment_failed` not retryable, no other tender | `pending → canceled` after hold expires (or `expired`) | `unpaid` | Inventory released |
| Risk review (intent `processing` with `review` next action) | `on_hold` | unchanged | Fulfillment blocked until release |
| `payment_intent.amount_increased` (incremental) | unchanged | recomputed | Amendment recorded on order version |

### 2.2 Authorization expiry and reauthorization

| Intent event | Order `status` | `payment_status` | Other effects |
|---|---|---|---|
| `payment_intent.authorization_expiring` (policy `notify`) | unchanged | unchanged | `order.payment_attention_required`; merchant may ship now, reauthorize, or cancel lines |
| `payment_intent.reauthorized` | unchanged | unchanged (`authorized` / `partially_collected`) | Timeline entry with both authorizations; nothing else — the purchase did not change |
| `payment_intent.reauthorization_failed` (old hold still live) | unchanged | unchanged | `order.payment_attention_required` with deadline = old `expires_at` |
| `payment_intent.authorization_expired`, remainder not covered | `confirmed/in_progress → on_hold` | `payment_exception` | Unfulfilled lines blocked; collection plan step `collect_new_payment` may email a pay link, or create an MIT intent if a mandate exists; `fulfillment` told not to ship |
| `payment_intent.canceled` (`authorization_expired`, nothing captured) | `on_hold` → `canceled` if the plan says `cancel_order_lines` | `unpaid` | Inventory released; seller orders canceled |

### 2.3 Capture phase

| Intent event | Order `status` | `payment_status` | Other effects |
|---|---|---|---|
| `payment_intent.partially_captured` | `in_progress` | `partially_collected` | Commerce ledger: seller pending balance credited for the captured lines; tax liability recognized for those lines |
| `payment_intent.captured` (covers balance) | `in_progress → completed` when all lines fulfilled | `collected` | `settlement_status: discharging` |
| `payment_intent.capture_failed` | `on_hold` | `payment_exception` | Fulfillment told the goods shipped without collection (exception queue) |
| `payment_intent.authorization_released` (final capture smaller) | unchanged | recomputed | Canceled lines' allocations released |
| Funds `available` for all captures, all seller payouts sent | unchanged | unchanged | `settlement_status: settled` |

### 2.4 Refund phase

| Intent event | Order | `payment_status` | Other effects |
|---|---|---|---|
| `payment_intent.refund.created` (pending) | `return.refund_status: pending` | unchanged | — |
| `payment_intent.refund.succeeded` partial | `fulfillment_status: partially_returned` (if a return) | `partially_refunded` | Commerce ledger: seller debited per allocation; tax liability reversed for refunded lines; commission refunded per seller agreement |
| `payment_intent.refund.succeeded` final | `returned` if all lines returned | `refunded` | — |
| `payment_intent.refund.failed` (`fallback_required`) | return `refund_status: action_required` | unchanged | Refund plan's fallback: store credit / alternate method; customer notified |

### 2.5 Dispute phase

| Intent / dispute event | Order `dispute_status` | Order `status` | Commerce ledger and marketplace |
|---|---|---|---|
| `dispute_alert.created` | `alerted` | unchanged | Dispute-prevention policy evaluated (may auto-refund → 2.4) |
| `dispute.inquiry_opened` | `inquiry` | unchanged | Evidence auto-assembled from order |
| `dispute.created` (`needs_response`) | `open` | if `closed`, reopens to `completed` (with `reopened_reason: dispute`) | Allocation rules decide the liable party; seller funds moved to *dispute hold* per rule |
| `dispute.evidence_submitted` | `open` | — | — |
| `dispute.won` | `won` | `completed` / `closed` restored | Hold released to seller balance |
| `dispute.lost` / `accepted` | `lost` or `partially_lost` | unchanged | Loss posted to the liable party; fee per fee rule; recovery waterfall if the seller balance is negative |
| `payment_intent.ach_return` (R10/R11 unauthorized) | `lost` | `on_hold` if goods not yet shipped | As lost; no representment on ACH |

### 2.6 NSF and managed retries

| Intent event | Order | Notes |
|---|---|---|
| `payment_intent.retry_scheduled` (NSF, managed) | `payment_status: payment_exception` with `expected_resolution_at` | Subscriptions: next shipment held, service continues per merchant policy |
| `credential.funds_signal` → retry succeeded | back to `collected` | Exception cleared, timeline shows the signal that triggered it |
| Retry budget exhausted | `on_hold` → merchant dunning policy | Network and Nacha limits respected |

## 3. Multi-intent orders

When an order holds several intents (split tender, deposit + balance, re-collection), each intent is projected through its **allocations**:

* A refund of line `li_2` draws on the intent(s) whose allocations include `li_2`, in the order of the refund plan (default: reverse tender order — refund the card before the gift card, or the opposite if the merchant prefers to return stored value first).
* A dispute on one intent affects only the lines allocated to that intent.
* `payment_status` aggregates across intents; `payment_exception` is raised if **any** uncovered balance exists.

Example — retail split tender, $150 basket, gift card $50 + card $100 (card partially approved for $80, then cash $20):

| Tender | Intent | Status | Allocation |
|---|---|---|---|
| Gift card | `pi_gc` | `captured` $50 | lines pro rata 33.3% |
| Card | `pi_card` | `captured` $80 (partial approval accepted) | 53.3% |
| Cash | non-PSP tender on the order | recorded $20 | 13.3% |
| **Order** | — | `payment_status: collected` | Σ = $150 |

## 4. Why the order does not get its own payment retries

It is tempting to let the order "retry payment" by creating new intents. The platform keeps that to one case — **re-collection after an intent is canceled or failed beyond retry** — because everything else (soft declines, reauthorization, NSF retries, rerouting) belongs on the existing intent, where the network chain, the authentication and the evidence live. An order with five intents for one card purchase is the transaction-API pathology ST-003 exists to remove.

## 5. Order closure

An order closes when **all** of:

* every line is fulfilled, canceled or returned;
* every intent is terminal or `captured`/`partially_refunded`/`refunded` with funds settled;
* the merchant's return window has elapsed;
* every seller order has been paid out (marketplace);
* `dispute_window_closes_at` (max over captures) has passed with no open dispute — or the merchant chose `close_on_completion` and accepts that a late dispute reopens it.

Closing is reversible only by a dispute; everything else after closure is an exception case.
