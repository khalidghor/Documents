# 02 · The Order resource

> The order is the commercial truth: what was bought, from whom, for how much, with what tax and discounts, delivered how — and how its balance will be collected. It is built on Payment Intents; it never moves money itself.

The Order is **optional** (ST-003 §07, the OMS branch rule). Enterprises with an OMS can integrate at the Payment Intent level and pass an `order_reference`. Everyone else — small business, QSR, marketplaces, PayFacs, agentic checkouts, a hosted checkout — uses the Order, because it is what makes split tender, split shipment, marketplace allocation, line-level refunds and line-level disputes possible without the merchant building a ledger.

## 1. What an order must be able to express

The design was tested against these use cases. Each one is a worked example in [11 · Industry playbooks](11-industry-playbooks.md).

| Industry | Use cases the model must carry |
|---|---|
| **QSR** | Combos and nested modifiers ("no onions", "extra shot", "size: large"); kitchen-station routing; order-ahead with a pickup time; drive-thru and kiosk; tip added after authorization; bar tabs with incremental authorization; pay-at-counter split by guest; third-party delivery (aggregator as channel, not seller); offline (store-and-forward) authorizations; loyalty redemption |
| **E-retail** | Cart → checkout → order; split shipments from several warehouses (multi-capture); backorders and pre-orders (authorization expiry, reauthorization, $0 verification then charge); BOPIS and curbside; subscriptions and replenishment; returns by mail with partial refunds; exchanges; gift cards and store credit; promotions funded by different parties |
| **Retail (card present)** | Basket at POS; multi-tender (cash + gift card + card); EMV, contactless, PIN debit; layaway (deposit then balance); returns without receipt; unreferenced refunds; even and uneven exchanges; endless aisle (order in store, ship from DC); offline mode |
| **Marketplace / platform** | Lines from several sellers in one checkout; commission and fee schedules; marketplace-facilitator tax; seller-funded vs marketplace-funded promotions; per-seller fulfillment; per-seller refunds; dispute pass-through rules; seller payouts and reserves |
| **PayFac / ISV** | Sub-merchant as merchant of record; platform fees; onboarding and risk per sub-merchant; liability waterfall |
| **Agentic** | An agent creates the order under a delegated mandate; the order records the instruction reference and the authority evidence; the mandate bounds the collection plan |

## 2. Anatomy

```
Order
├── identity           id, version, merchant_account, platform_account, channel, industry_profile, external refs
├── parties            customer (or guest), buyer agent (mandate ref), sellers (derived), staff (server, cashier)
├── line_items[]       product/variant/sku, quantity, unit price, modifiers[], bundle components[], discounts[],
│                      tax_lines[], seller_id, fulfillment_group_id, quantities (ordered/fulfilled/canceled/returned/refunded)
├── adjustments        order-level discounts[], fees[] (service, delivery, bag, surcharge), tips[], shipping_lines[]
├── tax                tax_lines[] with jurisdiction, rate, liable_party, collected_by, remitted_by, inclusive flag
├── totals             subtotal, discounts, tax, fees, tips, shipping, total; authorized, collected, refunded, disputed, balance_due
├── fulfillment_groups[]  method, location, promised window, lines, shipments[], capture_trigger, status
├── collection_plan    strategy, schedule[], tenders[], expiry and reauthorization policy
├── payments[]         Payment Intent refs with allocations[] (which lines each one pays for)
├── tenders[]          non-PSP tenders recorded on the order: cash, external gift card, check, house account
├── seller_orders[]    derived: one per seller, with commission, tax responsibility, liability settings
├── returns[]          RMAs: lines, reason, condition, disposition, refund plan, exchange links
├── statuses           status, payment_status, fulfillment_status, settlement_status, dispute_status
└── timeline[]         every event that changed the order, with its cause (payment event, fulfillment, staff action)
```

The JSON Schema is `Order` in [`openapi/schemas/orders.yaml`](../openapi/schemas/orders.yaml); the tables are in [`data-model/schema.sql`](../data-model/schema.sql) under the `commerce` schema.

### 2.1 Line items

A line item is one sellable thing at one price. Everything a refund, a dispute, a tax remittance or a payout needs to attribute money correctly lives on it.

| Field | Why it is there |
|---|---|
| `type` | `product`, `service`, `gift_card` (a liability, not revenue), `deposit`, `fee`, `shipping`, `tip`, `bundle`, `custom` |
| `catalog` | `product_id`, `variant_id`, `sku`, `catalog_version` — the price and tax code are snapshotted onto the line; later catalog edits never change a placed order |
| `quantity`, `unit_price`, `unit_of_measure` | Decimal quantity for weighed goods (deli, fuel); `unit_price` in minor units at catalog precision |
| `modifiers[]` | Nested: a modifier can carry its own price, quantity, tax code and child modifiers (QSR "combo → drink → size → extra shot") |
| `components[]` | Bundle composition with allocated price per component, so a partial return of a bundle can be priced |
| `discounts[]` | Each with `funded_by` (`merchant`, `marketplace`, `seller`, `manufacturer`, `split`) — essential for the commerce ledger |
| `tax_lines[]` | Per jurisdiction, with `liable_party`; see [08 · Marketplace and ledgers](08-marketplace-and-ledgers.md) |
| `seller_id` | The seller responsible for the line; `null` for single-merchant orders |
| `fulfillment_group_id` | Which fulfillment delivers it; drives capture-on-shipment |
| `quantities` | `ordered`, `allocated`, `fulfilled`, `canceled`, `returned`, `refunded` — refunds are bounded by these, not by money alone |
| `attributes` | `digital`, `age_restricted`, `hazmat`, `perishable`, `kitchen_station`, `requires_id`, `prescription` |
| `status` | `open`, `allocated`, `in_fulfillment`, `fulfilled`, `canceled`, `returned`, `partially_returned` |

### 2.2 Fulfillment groups

| Method | Industry | Capture trigger (default) |
|---|---|---|
| `ship` | E-retail, marketplace | On shipment of the group (multi-capture) |
| `pickup_in_store` / `curbside` | E-retail, retail, QSR | On handover |
| `dine_in` / `takeout` / `drive_thru` / `counter` | QSR | On order close (after tip) |
| `delivery_first_party` / `delivery_third_party` | QSR, grocery | On dispatch or on delivery (merchant choice) |
| `digital` | All | Immediately |
| `service_appointment` | Services | On completion, or a deposit at booking |
| `carry_out` | Retail POS | Immediately (sale) |

Each group carries `promised_at` / `promised_window`, `location_id`, `shipments[]` (carrier, tracking, delivered_at, proof of delivery — dispute evidence), and `status`.

### 2.3 The collection plan

The collection plan is the bridge from commerce to payments. It is declared once and executed by the platform.

| Strategy | What the platform does | Typical use |
|---|---|---|
| `pay_now` | One Payment Intent, automatic capture | Digital goods, QSR counter, POS sale |
| `authorize_then_capture_on_fulfillment` | One Payment Intent, `capture_method: multi`; capture per fulfillment group as it ships; final capture releases the remainder | E-retail, marketplace |
| `authorize_then_capture_on_close` | Authorize at open; incremental authorizations; capture with tip at close | Bar tabs, table service, hotel, car rental |
| `deposit_then_balance` | Intent 1 for the deposit; intent 2 (MIT, stored credential) for the balance on a schedule | Layaway, made-to-order furniture, services |
| `installments` | One intent per installment under a mandate | Merchant-funded installments |
| `bnpl` | One intent with `payment_method.type: bnpl`; the provider pays the merchant and collects from the buyer | Pay-later |
| `split_tender` | Ordered tenders: gift card, store credit, loyalty, then card for the remainder | Retail, e-retail |
| `pay_at_pickup` / `pay_on_delivery` | Order confirmed with no intent; intent created at handover | Order-ahead, COD markets |
| `verify_now_charge_later` | $0 verification (stored credential consent), intent created at release | Pre-orders, try-before-you-buy |
| `invoice` | Intent created with a hosted payment link and due date | B2B, services |

Collection-plan options that matter for the lifecycle:

* `authorization_expiry_policy`: `reauthorize` (default when the customer consented to a stored credential), `notify`, `cancel_order_lines`, `collect_new_payment`.
* `reauthorization_mode`: `reauth_then_reverse` or `reverse_then_reauth` — see [05 · Payment lifecycle](05-payment-lifecycle.md) §4.
* `partial_authorization`: `accept_and_collect_remainder` (retail split tender) or `reject` (e-retail default).
* `overcapture_tolerance`: e.g. 20% for tips in table-service restaurants, subject to network rules.
* `release_on_cancel`: whether canceling lines releases the authorization hold immediately (partial reversal) or at the final capture.

## 3. Statuses

An order has five status fields because it is five different questions. Collapsing them is how commerce platforms end up with `status: "partially_shipped_refund_pending"`.

### 3.1 `status` — the commercial lifecycle

```mermaid
stateDiagram-v2
  [*] --> draft
  draft --> pending: place
  draft --> expired: hold expires
  pending --> confirmed: collection plan satisfied for placement
  pending --> on_hold: risk review / payment requires action
  on_hold --> confirmed: released
  on_hold --> canceled: rejected
  pending --> canceled: customer or merchant cancels
  confirmed --> in_progress: first line enters fulfillment
  in_progress --> completed: all lines fulfilled or canceled, balance collected
  confirmed --> canceled: all lines canceled before fulfillment
  completed --> closed: return window and dispute window elapsed or settled
  in_progress --> on_hold: payment exception (expired auth, failed capture)
  closed --> [*]
  canceled --> [*]
  expired --> [*]
```

| Status | Meaning | Mutable? |
|---|---|---|
| `draft` | Cart / open ticket. Lines and prices can change; an inventory hold may exist | Fully |
| `pending` | Placed; the collection plan's placement condition is not yet met (e.g. 3DS, BNPL redirect, ACH validation) | Lines locked; customer details editable |
| `on_hold` | Placed but blocked: risk review, payment exception, address verification | Only by resolving the hold |
| `confirmed` | Placement condition met (authorized, paid, or confirmed with pay-at-pickup) | Lines may be canceled or amended (amendment creates a new order version and, if needed, an incremental authorization or a new intent) |
| `in_progress` | At least one line is in fulfillment | Unfulfilled lines may be canceled |
| `completed` | Every line is fulfilled or canceled, and the collectable balance is collected | Returns and refunds only |
| `closed` | Past the return window and the dispute window, or explicitly closed; the order is immutable apart from disputes arriving late | Disputes only |
| `canceled` | Nothing will be fulfilled; every authorization released or refunded | No |
| `expired` | A draft or pending order whose hold or payment window lapsed | No |

### 3.2 `payment_status` — the collection lifecycle

This is the projection of every Payment Intent on the order onto one value. It is the `Order` state set of PD-001 §03 (`CREATED`, `COLLECTING`, `PARTIALLY_COLLECTED`, `FULLY_COLLECTED`, …) refined to carry authorization and post-collection states.

| `payment_status` | Derived when |
|---|---|
| `unpaid` | No intent has reached `authorized` or `captured`; nothing collected |
| `requires_action` | The intent that the placement condition depends on is `requires_action` |
| `authorized` | Σ capturable authorizations ≥ balance due; nothing captured yet |
| `partially_authorized` | Some, not all, of the balance is authorized (split tender in progress; partial authorization accepted) |
| `partially_collected` | 0 < collected < total due |
| `collected` | Collected = total due (after line cancellations) |
| `partially_refunded` | Some collected money refunded; order not fully refunded |
| `refunded` | Everything collected has been refunded |
| `payment_exception` | An authorization expired without reauthorization, a capture failed, or an ACH debit returned NSF — and the balance is no longer covered |

`dispute_status` is kept apart from `payment_status` because a dispute contests money that *was* collected; the order's collection did not un-happen.

### 3.3 The other three

* `fulfillment_status`: `unfulfilled`, `partially_fulfilled`, `fulfilled`, `partially_returned`, `returned`, `canceled`.
* `settlement_status`: `unsettled`, `discharging` (captured, awaiting settlement or seller payouts), `settled` (all captured money settled and all seller obligations discharged) — the PD-001 `DISCHARGING`/`SETTLED` states.
* `dispute_status`: `none`, `alerted` (pre-dispute alert received), `inquiry`, `open`, `won`, `lost`, `partially_lost`.

How each Payment Intent event moves these five fields is the subject of [06 · How the payment lifecycle reflects on the order](06-order-payment-reflection.md).

## 4. Amendments and versioning

An order is versioned (`order.version`, optimistic concurrency via `If-Match`). Every change after placement is an **amendment** with a reason and an actor:

| Amendment | Payment consequence |
|---|---|
| Cancel a line before fulfillment | Partial reversal of the authorization (if `release_on_cancel: immediate`) or reduce the final capture |
| Add a line / upsize | Incremental authorization if the method and MCC support it; else a new Payment Intent for the difference |
| Change price (price match, goodwill) | Reduce capture, or refund after capture |
| Substitute an item (grocery) | Capture the actual amount; within overcapture tolerance or with incremental authorization |
| Add a tip | Capture above authorization within tolerance (table service), or incremental authorization |
| Change fulfillment method / address | Re-run tax; may change seller of record for tax; may change capture trigger |

The Payment Intent's own `amount` follows its rule (A1): an amendment creates `intent_version + 1` with the reason, and the operations that follow reference that version. History is never rewritten.

## 5. Returns and exchanges

A return (`returns[]`, prefix `rma_`) names lines and quantities, reason, condition, and disposition (restock, refurbish, destroy, return-to-seller). Its **refund plan** decides:

* the amount per line (unit price less allocated discounts, plus the line's tax, plus shipping if the policy refunds it, less restocking fee);
* the **refund route**: original payment method (default, and required by many network rules for card), store credit, gift card, or an alternate method when the original cannot receive credit (closed account, expired BNPL plan);
* which Payment Intent and, for multi-capture intents, which capture each refund draws on (proportional to the allocations, LIFO, or explicit);
* in a marketplace, which seller balance is debited (the seller of the line, unless the platform's policy absorbs it).

An **exchange** is a return plus a new line on the same order (even exchange: no money moves; uneven: a new intent for the difference or a refund for the surplus). Exchanges keep one order so dispute evidence shows the customer received a replacement.

## 6. Events

Order events are emitted in addition to (and correlated with) Payment Intent events. The full catalog is in [12 · Developer experience](12-developer-experience.md) §5. The ones every integration handles:

`order.created`, `order.placed`, `order.confirmed`, `order.on_hold`, `order.updated` (amendment), `order.fulfillment_updated`, `order.payment_status_changed`, `order.payment_exception`, `order.completed`, `order.canceled`, `order.return_created`, `order.refunded`, `order.dispute_updated`, `order.closed`.

Every order event carries `cause` — the Payment Intent event, fulfillment event or staff action that produced it — so an integrator can always answer "why did my order move?".

## 7. What the order deliberately does not do

* **It does not choose the rail, acquirer, credential or authentication.** Those are platform decisions on the attempt.
* **It does not retry payments.** It declares a policy (reauthorize, notify, cancel lines); the platform executes it on the Payment Intent.
* **It does not hold balances.** Seller balances, reserves and payouts are the commerce ledger's; the order references them.
* **It does not replace an OMS for enterprises that have one.** Inventory, warehouse orchestration and carrier booking stay in the merchant's systems; the order receives their events (`fulfillment_updated`) because the payment lifecycle depends on them.
