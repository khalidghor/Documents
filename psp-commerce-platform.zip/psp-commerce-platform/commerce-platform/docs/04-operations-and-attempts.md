# 04 · Operations and Attempts — authorization, capture, refund and everything between

> An **operation** is one instruction the merchant (or the platform's policy) gave: *authorize this*, *capture that*, *refund this much*. An **attempt** is one dispatch of that instruction to one acquirer or rail. Every retry of an instruction shares its operation; every try is its own attempt.

ST-003 finding 2: today's API makes captures, refunds and verifications *siblings* joined by `parentTransactionId`, so lineage lives in the merchant's database. Here they are **children of the Payment Intent**, typed, with parents.

## 1. Operation types

| `type` | Parent | Money effect | Card | ACH | BNPL | Notes |
|---|---|---|---|---|---|---|
| `verify` | — | None ($0 or network account verification) | ✓ | Account validation | — | Establishes stored-credential consent; feeds credential intelligence |
| `authorize` | — | Hold (promise) | ✓ | — | ✓ | First authorization on the intent |
| `incremental_authorization` | `authorize` / `reauthorization` | Increases hold | ✓ (eligible MCCs) | — | Provider-dependent | Same network transaction chain |
| `reauthorization` | Previous authorization | New hold for the remaining amount | ✓ | — | Provider re-auth | Supersedes the previous authorization; see lifecycle §4 |
| `partial_reversal` | An authorization | Reduces hold | ✓ | — | Provider release | Releases open-to-buy when lines are canceled or the final capture is smaller |
| `reversal` | An authorization | Releases hold fully | ✓ (void) | Cancel before submission | Provider cancel | Must be sent promptly when an authorization will not be used |
| `capture` | An authorization | Moves money (clearing) | ✓ multi-capture with sequence | — | Provider capture | `sequence`, `final_capture`, `fulfillment_group_id` |
| `charge` | — | Auth + capture in one | ✓ (sale / single message) | — | ✓ | Automatic capture |
| `debit` | — | Moves money | — | ✓ | — | ACH debit entry; `captured` on acceptance |
| `refund` | A capture / charge / debit | Returns money | ✓ (with refund authorization where required) | Credit entry | Provider refund | Many partial refunds per capture |
| `refund_reversal` | A refund | Cancels a pending refund | ✓ before submission | ✓ before submission | Provider-dependent | Rare; used for mistaken refunds |
| `return_request` | A credit received | Asks payer's bank to return | — | — | — | RTP/FedNow; receiver may decline |

Disputes are **not** operations: the merchant does not instruct them, the network does. They are their own resource ([07](07-disputes.md)), linked to the capture they contest. Responding to a dispute is an action on the dispute.

## 2. Operation shape

```jsonc
{
  "id": "op_2",
  "object": "payment_operation",
  "payment_intent": "pi_3Qx9...",
  "intent_version": 1,
  "type": "capture",
  "parent_operation": "op_1",                       // the authorization it draws on
  "amount": 7000, "currency": "USD",
  "status": "succeeded",                            // pending | processing | requires_action | succeeded | failed | canceled
  "idempotency_key": "ship-ord_8Kd2-fg_1",
  "initiated_by": "merchant",                       // merchant | platform_policy | customer | agent | dispute_prevention | recovery
  "reason": "fulfillment",
  "capture": { "sequence": 1, "final_capture": false, "fulfillment_group_id": "fg_1",
               "line_allocations": [ { "order_line_id": "li_1", "amount": 7000 } ] },
  "attempts": ["att_3"],
  "result": { "outcome": "approved", "decided_by": "technical", "reason": "captured", "class": "success" },
  "external_references": [ { "type": "network_transaction_id", "value": "VISA-381234567890123", "scope": "visa" } ],
  "created_at": "...", "completed_at": "..."
}
```

Refund operations add:

```jsonc
"refund": {
  "reason": "returned_goods",          // requested_by_customer | returned_goods | price_adjustment | duplicate | fraudulent | dispute_prevention | order_canceled | goodwill
  "capture_operation": "op_2",         // which capture this refund draws on (multi-capture intents)
  "return_id": "rma_1",
  "line_allocations": [ { "order_line_id": "li_1", "quantity": 1, "amount": 6600, "tax": 600 } ],
  "destination": "original_method",    // original_method | store_credit | alternate_method
  "dispute_alert": null                // dpa_ if this refund resolves a pre-dispute alert
}
```

## 3. Attempt shape

Attempts are written only by the platform. Advanced clients read them; ordinary clients never need to.

```jsonc
{
  "id": "att_2",
  "object": "payment_attempt",
  "operation": "op_1",
  "payment_intent": "pi_3Qx9...",
  "sequence": 2,
  "origin": "processor_substitution",   // initial | step_up_auth | credential_substitution | processor_substitution |
                                        // network_substitution | enriched_retry | scheduled_retry | reauthorization |
                                        // recovery_inquiry | late_response
  "rail": "visa",                       // visa | mastercard | amex | discover | star | pulse | nyce | accel | ach |
                                        // same_day_ach | rtp | fednow | open_banking | bnpl:<provider> | stored_value
  "acquirer": "acq_B",
  "merchant_account_ref": "mid_B_1001",
  "credential": { "type": "network_token", "reference": "crd_...", "cryptogram": "present" },
  "authentication": { "method": "3ds2", "eci": "05", "liability_shift": true, "exemption": null,
                      "bound_from": "att_1" },
  "amount": 11800,
  "outcome": "approved",                // approved | partially_approved | declined | error | timeout | unknown
  "amount_approved": 11800,
  "result": { "outcome": "approved", "decided_by": "issuer", "reason": "approved", "class": "success" },
  "rail_state": "approved",
  "external_references": [ { "type": "network_transaction_id", "value": "...", "scope": "visa" },
                           { "type": "authorization_code", "value": "A1B2C3" } ],
  "exec_id": "exec_card_auth", "plan_version": 12, "decision_ref": "dec_...",
  "timings": { "dispatched_at": "...", "responded_at": "...", "platform_latency_ms": 31, "network_latency_ms": 412 },
  "created_at": "..."
}
```

`origin` is how the merchant (and the evidence record) sees *why* an attempt exists. `exec_id`, `plan_version` and `decision_ref` say *which logic* produced it and *what else was possible* (`GET /v1/payment_intents/{id}/decisions`).

## 4. Rules the platform enforces

1. **One open authorization operation at a time per intent** (except during `reauth_then_reverse`, where the superseded hold coexists until its reversal is confirmed).
2. **No second acquirer while the first outcome is unknown** unless reversal advice to the first has been sent and the plan's recovery budget allows it (ST-003 §29). Duplicate-authorization detection is the backstop, not the control.
3. **Captures draw on a specific authorization.** A capture after a reauthorization references the new authorization's network transaction id; a capture after expiry without reauthorization is blocked by default (`capture_after_expiry: block`) because it invites misuse-of-authorization fees and "no authorization" chargebacks.
4. **Σ captures ≤ Σ live authorizations + tolerance.** Tolerance comes from network rules for the MCC (tips) and from `overcapture` entitlement.
5. **Σ refunds per capture ≤ that capture's amount − amount charged back on it.** Refunds on an amount under open dispute are rejected (`refund_blocked_by_dispute`) — refunding and losing the chargeback pays the customer twice.
6. **A final capture triggers a partial reversal of any uncaptured remainder** (unless the rail releases it implicitly), so the cardholder's open-to-buy is restored promptly.
7. **Reversal before refund.** Canceling an uncaptured amount is a reversal, never a refund.
8. **Every mutating operation carries an idempotency key.** Same key + same body returns the original operation; same key + different body is `idempotency_conflict`.
9. **Operations are append-only.** A mistaken capture is corrected by a refund, not by editing the capture.

## 5. Status mapping from operations to the intent

| Operation event | Intent status after |
|---|---|
| `authorize` approved, manual/multi capture | `authorized` |
| `authorize` partially approved, `partial_authorization: accept…` | `authorized` with `amount_authorized < amount`; order goes `partially_authorized` |
| `authorize` declined, not retryable | `failed` |
| `authorize` timeout after dispatch | `processing` (owned recovery) |
| `charge` approved / `debit` accepted | `captured` |
| `capture` succeeded, `final_capture: false`, remainder > 0 | `partially_captured` |
| `capture` succeeded, final or nothing remaining | `captured` |
| `reversal` succeeded with nothing captured | `canceled` |
| `refund` succeeded, Σ refunds < captured | `partially_refunded` |
| `refund` succeeded, Σ refunds = captured | `refunded` |
| `refund` failed (closed account) | Unchanged; refund `failed` with `fallback_required`; order notified |

## 6. Reading the lineage

```
pi_3Qx9  $118.00  captured → partially_refunded
├─ op_1  authorize            $118.00  succeeded
│   ├─ att_1  initial               visa · acq_A  declined (soft: issuer_unavailable)
│   └─ att_2  processor_substitution visa · acq_B approved   NTI 381234567890123
├─ op_2  capture  seq 1        $70.00  succeeded   fg_1 (seller A)
│   └─ att_3                         acq_B         approved
├─ op_3  capture  seq 2 final  $48.00  succeeded   fg_2 (seller B)
│   └─ att_4                         acq_B         approved
└─ op_4  refund   of op_3      $44.00  succeeded   rma_1, li_2 × 1 + tax
    └─ att_5                         acq_B         approved (refund authorization)
```

That tree is what `GET /v1/payment_intents/{id}?expand[]=operations.attempts` returns, and what the MCP tool `payment_intents_get_lineage` renders for an agent.
