# 13 · MCP server and agent skills

> Agents read the API as their user interface (ST-003 §05). The MCP server exposes the same resources — not a second "agent API" — with tool annotations that tell an agent what is read-only, what moves money, and what needs a human. Skills teach an agent (or a developer's coding assistant) the procedures: how to integrate, how to operate the lifecycle, how to answer a dispute, how to configure a marketplace.

## 1. The MCP server

* Location: [`mcp/`](../mcp) — a dependency-free TypeScript server (`server.ts`, Node 22.18+) speaking MCP over stdio (JSON-RPC 2.0: `initialize`, `tools/list`, `tools/call`, `resources/list`, `resources/read`, `prompts/list`, `prompts/get`).
* Tools are declared in [`mcp/tools.json`](../mcp/tools.json); each maps to one REST call. The server is a thin, policy-enforcing proxy: it never holds business logic.
* Configuration via environment: `PSP_API_BASE` (default sandbox), `PSP_API_KEY` (restricted key recommended), `PSP_ALLOW_LIVE` (must be `true` to use a live key), `PSP_ALLOW_MONEY_MOVEMENT` (default `false` — money-moving tools refuse unless enabled), `PSP_ON_BEHALF_OF` (platform acting for a seller).

### 1.1 Tool families

| Family | Tools (excerpt) | Annotations |
|---|---|---|
| Orders | `orders_create`, `orders_get`, `orders_list`, `orders_amend`, `orders_place`, `orders_cancel`, `orders_fulfill_group`, `orders_create_return`, `orders_timeline` | create/amend: not destructive; cancel: destructive |
| Catalog | `catalog_search`, `catalog_get_product`, `catalog_price_quote` | read-only |
| Payment Intents | `payment_intents_create`, `payment_intents_get`, `payment_intents_list`, `payment_intents_confirm`, `payment_intents_capture`, `payment_intents_increment_authorization`, `payment_intents_reauthorize`, `payment_intents_cancel`, `payment_intents_refund`, `payment_intents_get_lineage`, `payment_intents_explain_decisions` | capture/refund/cancel/reauthorize: money movement — require `confirm: true` and an idempotency key |
| Disputes | `disputes_list`, `disputes_get`, `disputes_draft_evidence`, `disputes_submit_evidence`, `disputes_accept`, `dispute_alerts_list`, `dispute_alerts_resolve` | submit/accept: destructive, human confirmation recommended |
| Marketplace | `sellers_list`, `sellers_get`, `allocations_preview`, `ledger_balances`, `ledger_entries_list`, `dispute_rules_simulate`, `payouts_list` | read-only except none |
| Intelligence | `credential_insights_get` (**payment method, token, fingerprint or BIN only — never a PAN**), `credential_registrations_create`, `funds_signals_list` | — |
| Platform | `capabilities_can_i` (the "can I?" check), `events_list` | read-only |
| Sandbox | `test_clocks_advance`, `test_simulate_dispute`, `test_simulate_ach_return`, `test_simulate_funds_signal` | sandbox keys only |

### 1.2 Safety rules enforced by the server

1. **No PAN ever.** Any argument matching a Luhn-valid 13–19 digit sequence is rejected before it leaves the process (`pan_not_allowed_in_mcp`).
2. **Money movement is opt-in twice**: the server must be started with `PSP_ALLOW_MONEY_MOVEMENT=true`, and each call must carry `confirm: true`. Without both, the tool returns a dry-run description of what it would do.
3. **Idempotency by default**: if the agent omits `idempotency_key`, the server derives one from the tool name + canonical arguments, so an agent retrying a timed-out call cannot double-capture.
4. **Live mode is explicit**: a `sk_live_` key is refused unless `PSP_ALLOW_LIVE=true`.
5. **Mandates bound agents**: when acting for a consumer, the agent passes `mandate`; the API (not the MCP server) enforces scope and headroom, and the purchase evidence record captures the agent identity.
6. **Outputs are summarized for agents**: lineage and decision explanations return compact trees, not raw attempt dumps; PII is masked per the key's disclosure tier.

### 1.3 Resources and prompts

* Resources: `psp://docs/{chapter}` (these docs), `psp://openapi/{domain}` (the specs), `psp://config/{file}` (the configuration reference).
* Prompts: `explain_payment` (lineage + why), `reconcile_order` (order vs. intents vs. ledger), `prepare_dispute_response`, `diagnose_declines`.

### 1.4 Using it

```bash
cd commerce-platform/mcp
PSP_API_BASE=http://localhost:4242/v1 PSP_API_KEY=sk_test_... node server.ts      # stdio
```

Claude Code / Claude Desktop configuration:

```json
{ "mcpServers": { "psp-commerce": {
    "command": "node", "args": ["commerce-platform/mcp/server.ts"],
    "env": { "PSP_API_BASE": "https://sandbox.api.example-psp.com/v1", "PSP_API_KEY": "sk_test_..." } } } }
```

## 2. Agent skills

Skills live in [`skills/`](../skills), one folder each with a `SKILL.md` (YAML front matter: `name`, `description`) — the format Claude Code and the Agent SDK load. They are procedures, not reference: each says when to use it, the steps, the checks, and the mistakes to avoid, and points at the MCP tools.

| Skill | Use it when | What it does |
|---|---|---|
| `psp-order-checkout-integration` | Building a checkout, POS or app on the Order + Payment Intent resources | Chooses the collection plan for the industry, generates the order payload, wires webhooks, sets up the sandbox scenarios to test |
| `psp-payment-lifecycle-operations` | Operating payments: captures, reauthorizations, refunds, expiring authorizations | Reads lineage, decides the safe operation, respects the rules in chapter 05 §12 |
| `psp-dispute-management` | Responding to alerts and disputes | Assembles evidence, estimates win likelihood, decides accept/represent, respects deadlines; marketplace allocation awareness |
| `psp-marketplace-ledger-setup` | Configuring a marketplace or PayFac | Picks a fund-flow model, writes dispute allocation and tax rules, simulates them, explains both ledgers |
| `psp-credential-intelligence-and-retries` | Improving approval and recovery | Uses insights to pick strategies; sets up registrations and NSF retries inside network limits |

## 3. Why there is no separate "agent API"

ST-003 A11: agents are a channel, not a product. The MCP tools call exactly the endpoints a developer calls, the agent's purchase is an ordinary Order and Payment Intent with `channel: agent` and a mandate, and every capability shipped to the API is available to agents on the day it ships.
