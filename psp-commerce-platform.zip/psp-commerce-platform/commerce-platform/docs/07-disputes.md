# 07 · Disputes and pre-disputes

> A dispute is the network (or BNPL provider, or ACH return) telling us the payer contests money that was captured. It is its own resource, linked to the exact capture it contests, the order lines that capture paid for and — in a marketplace — the seller who is liable. Pre-dispute alerts are separate resources, because most never become disputes.

The lifecycle mechanics (states, network flows, effect on the intent) are in [05 · Payment lifecycle](05-payment-lifecycle.md) §8–9. This chapter specifies the resources, the automation and the evidence model.

## 1. Resources

### 1.1 Dispute (`dp_`)

```jsonc
{
  "id": "dp_1", "object": "dispute",
  "payment_intent": "pi_3Qx9...", "operation": "op_2",     // the capture being contested
  "order_id": "ord_8Kd2...",
  "network": "visa", "network_flow": "visa_collaboration",   // visa_allocation | visa_collaboration | mastercard | amex | discover |
                                                               // ach_unauthorized_return | bnpl_provider | instant_return_request
  "reason": { "network_code": "13.1", "category": "product_not_received",
              "canonical": "not_received" },                  // fraud | authorization | processing_error | not_received |
                                                               // not_as_described | credit_not_processed | canceled_recurring |
                                                               // duplicate | incorrect_amount | other
  "stage": "chargeback",                                      // inquiry | chargeback | pre_arbitration | arbitration
  "status": "needs_response",                                 // needs_response | under_review | won | lost | accepted | expired | withdrawn
  "amount": 7000, "currency": "USD",
  "disputed_lines": [ { "order_line_id": "li_1", "amount": 7000 } ],
  "funds": { "withdrawn": 7000, "fee": 1500, "reinstated": 0 },
  "evidence_due_by": "2026-12-17T23:59:59Z",
  "liability": { "authentication_liability_shift": false, "ce3_eligible": false,
                 "assessment": "merchant_liable_unless_delivery_proven" },
  "allocation": { "rule": "dar_not_received_seller_fulfilled", "liable_party": "seller",
                  "seller_id": "sel_A", "responder": "platform_with_seller_evidence",
                  "fee_bearer": "seller", "hold_applied": 7000 },
  "evidence": { "status": "draft", "auto_assembled": ["shipment_tracking", "proof_of_delivery", "order_receipt"],
                "requested_from_seller": { "requested_at": "...", "due_by": "..." } },
  "win_likelihood": { "estimate": 0.71, "interval": [0.62, 0.79], "model": "dispute_win_v4" },
  "history": [ { "stage": "chargeback", "status": "needs_response", "at": "..." } ],
  "related_alerts": ["dpa_1"],
  "created_at": "..."
}
```

### 1.2 Dispute alert (`dpa_`)

```jsonc
{
  "id": "dpa_1", "object": "dispute_alert",
  "source": "ethoca",                          // ethoca | verifi_cdrn | visa_rdr | visa_order_insight | mastercard_consumer_clarity | retrieval_request | amex_inquiry
  "type": "dispute_notification",              // fraud_confirmed | dispute_notification | data_request | auto_resolved
  "payment_intent": "pi_3Qx9...", "operation": "op_2",
  "match_confidence": "exact",                 // exact (ARN/NTI) | probable (amount, date, last4) | none
  "amount": 7000,
  "status": "action_required",                 // action_required | refunded | declined | resolved_by_rule | data_shared | expired
  "respond_by": "2026-11-23T12:00:00Z",
  "recommended_action": { "action": "decline_and_prepare_evidence", "reason": "delivered_with_signature",
                          "decision_ref": "dec_..." },
  "resolution": null
}
```

## 2. Automation: who does what by default

| Step | Default automation | Configurable in |
|---|---|---|
| Match alert/dispute to intent and capture | ARN / network transaction id exact match; probable match by amount, date, last4, MID with a human queue for ambiguity | — |
| Decide on a pre-dispute alert | Rules: refund if amount ≤ threshold and reason ∈ {fraud_confirmed, not_received without tracking}; else decline and pre-assemble evidence | `dispute-policy.yaml → prevention` |
| Configure RDR | Issuer-side rules generated from the same policy, published to Visa RDR | `dispute-policy.yaml → rdr` |
| Respond to Order Insight / Consumer Clarity queries | Always share order details (lines, delivery, receipt, merchant contact) — data only, no refund | `dispute-policy.yaml → data_sharing` |
| Assemble evidence | From the order and intent: receipt, line items, AVS/CVV, 3DS result, device/IP, delivery tracking & POD, refund ARNs, terms accepted, prior undisputed transactions (CE 3.0), agent authority record | `dispute-policy.yaml → evidence` |
| Accept vs. represent | Accept when expected value of representment < 0 (win likelihood × amount − effort cost − fee risk) or evidence missing | `dispute-policy.yaml → representment` |
| Submit before deadline | Auto-submit at `deadline − buffer` if evidence is complete; otherwise accept at deadline − buffer to avoid losing the right to choose | `dispute-policy.yaml` |
| Pre-arbitration | Re-evaluate with the issuer's new information; never auto-escalate to arbitration (fees) without a human or explicit rule | `dispute-policy.yaml → arbitration` |
| Marketplace allocation | Dispute allocation rules ([08](08-marketplace-and-ledgers.md) §5) | `config/marketplace/dispute-allocation-rules.yaml` |

## 3. Evidence model

Evidence is assembled into typed items, each with provenance, so it can be reused across networks and audited:

| Evidence type | Source in this platform | Defends |
|---|---|---|
| `receipt` | Order lines, totals, tax, merchant descriptor | All |
| `authentication` | Attempt: 3DS ECI, CAVV presence, liability shift, exemption | Fraud (Visa 10.4, MC 4837) |
| `ce3_prior_transactions` | Credential history: ≥2 undisputed captures 120–365 days old with matching IP/device + one of account/shipping address | Visa 10.4 |
| `avs_cvv` | Attempt results | Fraud |
| `device_and_ip` | Session | Fraud |
| `shipment_tracking`, `proof_of_delivery` | Fulfillment groups / shipments | Not received |
| `product_description`, `terms_accepted`, `return_policy` | Catalog snapshot on the line, checkout terms version | Not as described, cancellation |
| `refund_record` | Refund operations with ARN | Credit not processed, duplicate |
| `cancellation_record` | Subscription / mandate history | Canceled recurring |
| `customer_communication` | Merchant-supplied | All |
| `service_usage` | Merchant-supplied (logins, downloads, redemptions) | Digital goods |
| `agent_authority` | Purchase evidence record: agent id, mandate@version, instruction hash, step-up | Agentic purchases |
| `seller_statement` | Seller, through the seller portal / API | Marketplace |

## 4. Funds and ledger effects

| Event | Acquiring ledger | Commerce ledger (marketplace) |
|---|---|---|
| Chargeback received | Dr merchant payable / Cr settlement cash (network debit); Dr merchant payable / Cr dispute fee revenue | Dr liable party (or `dispute_hold` if rule says hold first) / Cr PSP receivable |
| Won | Reverse both (fee per policy — some acquirers refund it on win) | Release hold back to the seller's balance |
| Lost | — (already withdrawn) | Final posting to liable party; fee to fee bearer; tax reversal per tax rule |
| Pre-arbitration lost / arbitration | Second debit and arbitration fee | As per the arbitration rule (often the platform, by default) |

## 5. Monitoring

Per merchant, sub-merchant and seller, daily:

* dispute count and ratio (disputes / settled transactions, by count and value);
* fraud-report ratio (TC40/SAFE) where available to us as acquirer;
* the VAMP-style combined ratio and the Mastercard ECM/EFM thresholds, as configured;
* prevention effectiveness: alerts → refunds, alerts → disputes avoided, RDR auto-resolutions;
* representment win rate by reason and by evidence type (feeds `win_likelihood`).

Breaching a warning threshold raises `merchant.dispute_ratio_warning` and, for marketplace sellers, may trigger a reserve increase or listing restrictions by rule.
