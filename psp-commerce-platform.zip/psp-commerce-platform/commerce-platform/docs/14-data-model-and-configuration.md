# 14 · The application data model and its configuration

> One database model for the whole application — tenancy, catalog, commerce, payments, disputes, both ledgers, marketplace, tax, intelligence, configuration and the platform plumbing — validated by loading it into PostgreSQL 16 and posting the worked marketplace example into it.

Files: [`data-model/schema.sql`](../data-model/schema.sql) (DDL), [`data-model/ERD.md`](../data-model/ERD.md) (relationships), [`data-model/DATA-DICTIONARY.md`](../data-model/DATA-DICTIONARY.md) (every column, generated), [`data-model/seed-worked-example.sql`](../data-model/seed-worked-example.sql) (both ledgers, reconciled).

## 1. Schemas

| Schema | Holds | System of record for | Owner (ST-001 group) |
|---|---|---|---|
| `tenancy` | Legal entities, accounts (platform → merchant → seller), MIDs, locations, terminals, keys, access grants | Who is who, under which PSP entity | Client platform |
| `catalog` | Products, variants, modifier groups, price books | What can be sold | Commerce platform |
| `customer` | Customers, payment methods (vault references), versioned mandates | Consent and credentials *references* (the vault holds secrets) | Credential platform |
| `commerce` | Orders, versions, lines, modifiers, bundles, discounts, fees, tips, tax lines, fulfillment, shipments, tenders, returns, seller orders, timeline | The commercial transaction | Commerce platform |
| `payments` | Payment intents, intent versions, allocations, operations, line allocations, attempts, external references, decision records, recovery cases, retry schedules | The obligation to collect and every try at it | Processing platform |
| `disputes` | Disputes, lines, stage history, evidence, alerts | Contested money | Payment resolution |
| `ledger` | Accounts, journal entries, postings (both ledgers), balances view, reconciliation runs | Financial truth | Money movement |
| `marketplace` | Commission plans, seller agreements, allocations, transfers, payouts, reserves, dispute rule sets, negative-balance cases | Who owes whom | Money movement + Commerce platform |
| `tax` | Registrations, determinations, remittance periods | Who must remit what | Commerce platform (with tax partner) |
| `intelligence` | Issuers, BIN ranges, insights, credential signals, registrations, programmes, funds signals, retry counters | What we know about credentials | Payment intelligence |
| `config` | Versioned signed configuration documents, entitlements | What exists, is bought, permitted and chosen | Governance and data |
| `platform` | Events, outbox, webhook endpoints and deliveries, idempotency keys, audit log, test clocks | The external contract's plumbing | Developer platform |

82 tables and views. Every tenant-scoped table carries `account_id`; row-level security policies filter by the accounts the caller may act for.

## 2. Invariants enforced by the database

| Invariant | How |
|---|---|
| Every journal entry balances | Deferred constraint trigger `ledger.assert_balanced` |
| Ledger is append-only | `BEFORE UPDATE OR DELETE` triggers raise |
| Ledger derivation is idempotent | `UNIQUE (ledger, source_event_id, event_type)` |
| One operation per idempotency key per intent | `UNIQUE (payment_intent_id, idempotency_key)` |
| Capture sequences are unique per intent | Partial unique index on `capture_sequence` |
| Refunds + chargebacks never exceed captures | `CHECK` on `payment_intent` |
| Fulfilled + canceled ≤ ordered; refunded ≤ ordered | `CHECK` on `line_item` |
| Attempt sequences are unique per operation | `UNIQUE (operation_id, sequence)` |
| One published configuration per document and scope | Partial unique index |
| No PAN anywhere | No column can hold one; BIN-8 is the longest card prefix outside the vault |

Invariants that span services (the control-account reconciliation between the two ledgers, the order projection, network retry limits) are enforced by the application and checked by `ledger.reconciliation_run` and `intelligence.retry_counter`.

## 3. Read and write paths

* **Writes** go through the API → domain service → transactional outbox (`platform.outbox`) → journal. The ledgers are **derived** from the journal by idempotent consumers; nothing writes to `ledger.*` from a request handler.
* **The order projection** (`commerce.order.payment_status`, totals) is recomputed from intents on every payment event; the reference algorithm is `reference/order-projection.ts`.
* **Hot-path reads** (authorization) never touch this database for configuration — they read signed snapshots compiled from `config.document`.
* **Partitioning** (production): `payments.attempt`, `payments.operation`, `ledger.posting`, `platform.event` and `platform.webhook_delivery` by month; `commerce."order"` by account hash for the largest tenants.

## 4. Configuration

All configuration lives in [`config/`](../config) as YAML sources of signed documents. The guide is [`config/README.md`](../config/README.md); the essentials:

* **Authority levels** (regulator → network → PSP → platform → PayFac → merchant → seller → learned strategy). Lower levels narrow; they never widen.
* **What each file controls**: authorization validity; lifecycle policy (reauthorization, partial authorization, capture tolerance, refunds, unknown outcomes, ACH finality); retry limits; dispute policy; rail declarations; industry profiles; credential intelligence; marketplace fund flows, commission, payouts, reserves; dispute allocation rules; tax responsibility; entitlements and packages; platform conventions and retention.
* **Change lifecycle**: draft → validate (including cross-level conflicts) → simulate (for money-affecting rule sets) → approve by change tier → publish signed → expose by predicate → measure against the holdout.
* **Per-request overrides** live on the resource (`payment_intent.policies`, `order.collection_plan`) and are bounded by the same rules.

## 5. Running it locally

```bash
# 1. Database (PostgreSQL 16)
createdb psp && psql -d psp -f commerce-platform/data-model/schema.sql
psql -d psp -f commerce-platform/data-model/seed-worked-example.sql      # prints the reconciled balances

# 2. Regenerate the data dictionary after schema changes
python3 commerce-platform/scripts/gen_data_dictionary.py "dbname=psp"

# 3. Reference model and MCP server tests
npm run commerce:test
```
