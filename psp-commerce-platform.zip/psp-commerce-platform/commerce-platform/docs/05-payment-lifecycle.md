# 05 · The full payment lifecycle, from a Payment Intent's point of view

> This is the logical view asked for: authorization → expiry → reauthorization (or reversal then reauthorization) → single or multiple captures → single or multiple partial refunds → pre-dispute → dispute → disposition — expressed as operations and attempts on **one** Payment Intent, with the four state models kept apart, and then reflected onto the order (next chapter).

Read it in order the first time. Each section has: the **situation**, the **mechanics** (what operations and attempts the platform creates), the **states** (payment / authorization / financial), and the **rules** (network, rail and platform) that bound it.

Network rule values quoted here are defaults carried in [`config/`](../config) and **must be confirmed against the current Visa Core Rules, Mastercard Transaction Processing Rules, Amex/Discover operating regulations and Nacha Operating Rules before production**. They change at least twice a year.

---

## 0. The whole picture on one page

```mermaid
flowchart TD
  C[Create intent] --> CF{Confirm}
  CF -->|needs 3DS / redirect / consent| RA[requires_action]
  RA --> P
  CF --> P[processing<br/>attempts, retries, recovery]
  P -->|declined, not retryable| F[failed]
  P -->|approved, manual or multi| AU[authorized<br/>hold, expires_at]
  P -->|approved, automatic| CAP[captured]
  AU -->|incremental| AU
  AU -->|expiring| RE{Reauthorize?}
  RE -->|reauth then reverse| AU
  RE -->|reverse then reauth| AU
  RE -->|not permitted / declined| EX[canceled: authorization_expired<br/>or remainder released]
  AU -->|void| CN[canceled]
  AU -->|partial capture seq n| PC[partially_captured]
  PC -->|capture seq n+1| PC
  PC -->|final capture + release remainder| CAP
  AU -->|final capture| CAP
  CAP -->|partial refund| PR[partially_refunded]
  PR -->|partial refund| PR
  PR -->|last refund| RF[refunded]
  CAP -->|full refund| RF
  CAP -. pre-dispute alert .-> AL[alert → refund or decline]
  AL -.-> PR
  CAP -->|chargeback| D[disputed]
  PR -->|chargeback| D
  D -->|won| CAP
  D -->|lost| DL[disputed · lost]
```

Underneath that diagram, four clocks run independently:

| Clock | Starts | Ends | Configured in |
|---|---|---|---|
| Authorization validity | Authorization approved | `authorization.expires_at` | `authorization-validity.yaml` |
| Capture / clearing deadline | Authorization | Network clearing deadline (after which late-presentment rules apply) | `authorization-validity.yaml` |
| Refund eligibility | Capture | Merchant policy (return window) — networks do not cap refund age, but refunds to closed accounts fail | `payment-lifecycle-policy.yaml → refunds` |
| Dispute window | Processing (or expected delivery) date | Network filing limit (typically 120 days; up to 540 days for some reasons) | `dispute-policy.yaml` |
| ACH return window | Settlement | 2 banking days (most returns); 60 calendar days (unauthorized consumer) | `rails.yaml` |

---

## 1. Authorization

### Situation
A buyer checks out. The order's collection plan says *authorize now, capture on fulfillment*.

### Mechanics
1. `POST /v1/payment_intents` (or the order creates it) → intent with `capture_method: manual | multi`.
2. `POST …/confirm` → operation `op_1 type=authorize`.
3. The execution plan runs: screening ∥ constraint binding (mandate) ∥ credential resolution → risk → **joint credential × acquirer decision** → authentication (after the acquirer is known, so liability binds to the right MID) → enrichment → dispatch (attempt `att_1`).
4. If the issuer soft-declines and the attempt strategy allows it: another attempt on the same operation (`origin: processor_substitution`, `credential_substitution`, `step_up_auth`, …). If a step-up is needed, the intent goes `requires_action`; on completion the authentication result binds to the **intent** and is reused by every later attempt.

### Authorization types

| `authorization.type` | When | Network notes |
|---|---|---|
| `final` | Amount is known and will be captured within days (digital goods, most retail) | Lower interchange on some programmes; must capture the exact amount; validity is short |
| `estimated` / `pre_authorization` | Amount may change (split shipments, tips, hospitality, fuel, grocery substitution) | Enables incremental authorizations and longer validity in eligible MCCs |
| `incremental_eligible` | Hospitality, car rental, transit, bar tabs | Incrementals chain to the original network transaction id |

### Partial authorization (the gap ST-003 §07 names)

An issuer may approve less than requested (prepaid and debit cards especially). `attempt.outcome = partially_approved`, `amount_approved < amount`.

| `policies.partial_authorization` | Platform behaviour | Order reflection |
|---|---|---|
| `reject` (default for e-retail) | Immediately reverse the partial approval; operation `failed` with reason `partial_authorization_rejected` | `payment_status: unpaid`; customer asked for another method |
| `accept_and_collect_remainder` (retail, QSR split tender) | Intent `authorized` with `amount_authorized < amount`; `next_action: collect_remainder` | Order `partially_authorized`; POS prompts for a second tender, which becomes a second intent |
| `accept_and_reduce` (only with customer consent, e.g. gift-card balance) | Amend intent to the approved amount (`intent_version + 1`) | Order lines reduced or balance due increases |

### States after authorization

| Payment | Authorization | Financial |
|---|---|---|
| `authorized` | `active`, `amount_capturable = amount_authorized` | `none` (no ledger movement; an *authorized* projection only) |

---

## 2. Incremental authorization

### Situation
A bar tab grows; a hotel stay is extended; a grocery order's substitution costs more.

### Mechanics
`POST …/increment_authorization {amount: 2500}` → operation `incremental_authorization`, parent = current authorization. Approved → `amount_authorized += 2500`, `amount_capturable += 2500`. Most networks **reset or extend validity** on an approved incremental in eligible MCCs; `expires_at` is recomputed from the rule named in `expiry_basis`.

If the MCC or the issuer does not support incrementals, the platform returns `incremental_not_supported` and the caller (or the order's policy) chooses: capture within tolerance, or create a second intent for the difference.

---

## 3. Authorization expiry

### Situation
The order is backordered. The authorization approved on day 0 will expire before the goods ship.

### Validity defaults (verify before production)

| Network | Authorization | Default validity |
|---|---|---|
| Visa | Customer-initiated, standard | 10 calendar days |
| Visa | Merchant-initiated | 5 calendar days |
| Visa | Estimated / incremental — lodging, car rental, cruise | 31 days |
| Visa | Extended authorization (where available, fee applies) | Up to 30 days |
| Mastercard | Final / undefined | 7 calendar days |
| Mastercard | Pre-authorization | 30 calendar days |
| Amex | Standard | 7 days (longer for certain travel/lodging) |
| Discover | Standard | 10 days (30 for some T&E) |
| BNPL | Provider-specific | Typically 7–30 days (e.g. many providers ~28 days) — contract value |

Capturing after expiry is not impossible — the network may still clear it — but it exposes the merchant to misuse-of-authorization / processing-integrity fees, to "no authorization" and "late presentment" chargebacks, and the issuer may have already released the hold (so the cardholder's funds may be gone). That is why the platform's default is **reauthorize before expiry or block the capture**.

### The expiry timeline the platform runs

```
t0 ───────────── authorized ─────────────── t_exp − lead ──── t_exp
                                                 │               │
                                  AUTHORIZATION_EXPIRING          │
                                  webhook: payment_intent.authorization_expiring
                                  policy evaluated ───────────────┤
                                                                  └─ expired if nothing happened
```

`lead` comes from `authorization-validity.yaml → defaults.expiring_lead_time` (default 24h, or 48h for MIT on weekends). At `t_exp − lead` the platform evaluates `policies.on_authorization_expiry`:

| Policy | Meaning | Requires |
|---|---|---|
| `reauthorize` | Platform reauthorizes the capturable remainder automatically | Stored-credential consent (CIT with `stored_credential.usage=first` or a mandate); method supports MIT; amount ≤ original (or within an approved amendment) |
| `notify` | Webhook only; merchant decides (call `/reauthorize`, capture now, or let it expire) | — |
| `cancel` | Let it expire; on expiry, intent `canceled` (`authorization_expired`) if nothing captured; else remainder released | — |
| `capture_available` | Capture what is fulfilled now (non-final), reauthorize the rest | Multi-capture |

---

## 4. Reauthorization — two modes, and why both exist

A reauthorization is a **new authorization operation on the same intent** for the amount still to be captured. It is an execution change, not an intent change (A1): the purchase, the amount owed and the customer's consent are the same.

### Mode A · `reauth_then_reverse` (default)

```mermaid
sequenceDiagram
  participant PI as Payment Intent
  participant Net as Network / issuer
  PI->>Net: op_5 reauthorization $48 (MIT, reason=reauthorization, ref NTI of op_1)
  Net-->>PI: approved (new NTI)
  Note over PI: authorization.history: op_1 superseded, op_5 active
  PI->>Net: op_6 reversal of op_1 remaining hold ($48)
  Net-->>PI: reversal confirmed
```

* **Pro:** there is never a moment without a valid hold; if the reauthorization is declined, the original authorization is still live until `t_exp` and the merchant can capture what it can.
* **Con:** for a short period the cardholder may see two holds (bad for debit and prepaid cards and for customer-service calls).
* **Used when:** credit cards; high-value goods; `lead` time comfortable.

### Mode B · `reverse_then_reauth`

```mermaid
sequenceDiagram
  participant PI as Payment Intent
  participant Net as Network / issuer
  PI->>Net: op_5 reversal of op_1 remaining hold
  Net-->>PI: reversal confirmed
  PI->>Net: op_6 reauthorization $48 (MIT)
  alt approved
    Net-->>PI: approved
  else declined (e.g. NSF on debit)
    Net-->>PI: declined
    Note over PI: no hold at all → policy: retry schedule or notify
  end
```

* **Pro:** never double-holds open-to-buy — important for **debit and prepaid** where a duplicate hold can cause an NSF on the reauthorization itself.
* **Con:** if the reauthorization fails there is no hold left.
* **Used when:** `card.funding ∈ {debit, prepaid}`; or the original authorization has already expired (nothing to protect).

The platform chooses the mode per intent from `reauthorization_mode`, which defaults to `auto` = Mode B for debit/prepaid, Mode A otherwise. The choice is a decision point with a decision record (so the policy can be improved by experiment, never by guesswork).

### Network mechanics carried on the reauthorization attempt

* Merchant-initiated indicators (stored credential, `reason: reauthorization` / "resubmission" where applicable), and the **original network transaction id** so the issuer links the chain.
* No 3DS challenge: the customer is not present; the original authentication remains evidence on the intent.
* If the issuer declines with a soft code, the attempt strategy may retry within network retry rules; if hard, the intent follows the policy (`notify` → order `payment_exception`).

### States across a reauthorization

| Moment | Payment | Authorization | Order |
|---|---|---|---|
| Before | `authorized` | `active`, expires in 1 day | `confirmed`, `payment_status: authorized` |
| Reauth in flight (Mode A) | `authorized` | `expiring`; `history`: op_1 active, op_5 pending | unchanged |
| Reauth approved, old reversed | `authorized` | `active` (op_5), `reauthorization_count: 1`, new `expires_at` | unchanged; timeline entry `payment.reauthorized` |
| Reauth declined (Mode A), before t_exp | `authorized` | `expiring` (op_1 still live) | `payment_exception` raised; merchant may capture now |
| Reauth declined (Mode B) | `authorized` with `amount_capturable: 0` → after policy: `canceled` (`authorization_expired`) if nothing captured | `reversed` | `payment_status: payment_exception`; collection plan may create a new intent (customer re-engagement) |

### Partial-shipment reauthorization (Visa split-shipment pattern)

With multi-capture, the first shipment is captured inside validity; the remaining shipments ship after expiry. The platform reauthorizes **only the remainder** (`amount_capturable` at that point), referencing the original chain, and subsequent captures reference the reauthorization.

---

## 5. Reversal (void) and partial reversal

| Situation | Operation | Intent after |
|---|---|---|
| Order canceled before any capture | `reversal` (full) | `canceled` (`order_canceled` / `requested_by_customer`) |
| A line canceled before fulfillment, `release_on_cancel: immediate` | `partial_reversal` for the line's allocated amount | Unchanged state; `amount_capturable` reduced |
| Final capture for less than authorized | Automatic `partial_reversal` of the remainder | `captured` |
| Fraud review rejects an authorized order | `reversal` | `canceled` (`fraudulent`) |
| Authorization obtained twice (late response after recovery) | `reversal` of the duplicate (recovery-initiated) | Unchanged; recovery case closed |

Prompt reversal matters: networks expect a reversal soon after the merchant knows an authorization will not be used (Visa expects within 24 hours of the decision for many cases), and debit cardholders feel unreleased holds immediately.

**ACH has no reversal after submission.** A canceled ACH debit after submission becomes a refund (credit entry) once accepted. The rail's declarations make the API return `operation_not_supported_on_rail` rather than pretending.

---

## 6. Capture — single, multiple, final

### Single capture
`POST …/capture {amount}` with `final_capture` defaulting to `true`. Amount ≤ `amount_capturable` (+ tolerance). Remainder released by partial reversal. Intent → `captured`.

### Multi-capture (split shipments, marketplace sellers shipping separately)

```
authorize $118.00 ─┬─ capture seq 1  $70.00  (fg_1, seller A)           → partially_captured, capturable $48
                   └─ capture seq 2  $48.00  final (fg_2, seller B)     → captured, capturable $0
```

Each capture carries `sequence`, `final_capture`, the fulfillment group and line allocations. On card, the platform sets the network multiple-clearing indicators (sequence number / count where the network requires it). Rules:

* Each capture is its own clearing record and its own **dispute target** (a dispute names one cleared transaction).
* A non-final capture never releases anything; a final capture always releases the remainder.
* Captures may arrive out of shipment order; `sequence` is assigned by the platform at submission.
* A capture after the authorization expired is blocked by default (§3); with `capture_after_expiry: allow_with_reauthorization`, the platform inserts a reauthorization first.

### Capture with tip or overcapture
Table-service restaurants and similar MCCs may capture above the authorized amount within network tolerance (commonly up to 20% for tips; verify per network and MCC). Above tolerance, the platform performs an incremental authorization first, or rejects with `amount_exceeds_tolerance`.

### Capture failures
A capture can fail technically (acquirer unavailable) — the platform retries the same operation (new attempt); the merchant sees `processing`. A capture rejected by the acquirer for an expired or reversed authorization returns `authorization_not_capturable` and the order gets `payment_exception`.

### Financial state after capture

| Event | Acquiring ledger | Funds |
|---|---|---|
| Capture submitted | Dr scheme receivable / Cr merchant payable (pending) | `receivable` |
| Clearing confirmed, fees estimated | Interchange and scheme fee estimates | `receivable` |
| Settlement from acquirer/network | Dr settlement cash / Cr scheme receivable | `pending` |
| Availability date (payout schedule, reserves) | Merchant payable PENDING → AVAILABLE (or RESERVED) | `available` / `reserved` |
| Payout | Dr merchant payable / Cr cash | `paid_out` |

---

## 7. Refunds — single, multiple, partial

### Mechanics
`POST /v1/payment_intents/{id}/refunds {amount, reason, capture?, line_allocations?, destination?}` → operation `refund`.

* **Which capture?** For multi-capture intents, refunds draw on a specific capture (each capture is its own cleared transaction). If not specified, the platform allocates by the order's lines (a returned line's capture) else LIFO.
* **How many?** Unlimited partial refunds per capture, while Σ refunds on that capture ≤ capture amount − amount charged back on it.
* **Card refunds** are sent as refund (credit) transactions; where the network requires an online refund authorization, the attempt carries it and can be **declined** (closed account, card reissued with no updater link). A declined refund is `failed` with `fallback_required: true`, and the order's refund plan chooses an alternate destination (store credit, bank transfer to the customer) — never silently.
* **ACH refunds** are credit entries; they can be returned (account closed, R02) → refund `failed` → fallback.
* **BNPL refunds** go to the provider, which adjusts the buyer's plan; the merchant's settlement from the provider is reduced.
* **Before capture there is no refund** — the API turns a "refund" of an uncaptured intent into a reversal and says so (`converted_to_reversal`).

### States

| Σ refunded | Intent |
|---|---|
| 0 < Σ < captured | `partially_refunded` |
| Σ = captured (all captures fully refunded) | `refunded` |

`partially_captured` intents can also be refunded (a refund of the first shipment while the second is unshipped): the intent becomes `partially_refunded`, while `authorization.amount_capturable` still shows what can be captured. A later capture returns the status to the capture-derived value only if nothing has been refunded — refunds are sticky in the status, and the amounts say the rest.

### Refund versus dispute interplay

| Situation | Rule |
|---|---|
| Refund issued, then a chargeback for the same amount arrives | Dispute auto-response with "credit already processed" evidence (refund ARN and date); usually won/reversed by issuer |
| Dispute open, merchant tries to refund the disputed amount | Blocked: `refund_blocked_by_dispute`. Accept the dispute instead (same money, no double loss) |
| Pre-dispute alert (Ethoca/CDRN) received, merchant refunds | Refund operation with `reason: dispute_prevention`, linked to the alert; the alert is closed as `refunded`; most alert programmes then stop the chargeback |
| RDR (Visa Rapid Dispute Resolution) rule matched | The issuer's dispute is auto-resolved in the merchant's favour *for the issuer* by crediting the cardholder: platform records a refund-equivalent `dispute_prevention` credit — not a chargeback — and the intent goes `partially_refunded`/`refunded` |

---

## 8. Pre-dispute

Before a chargeback exists, five kinds of signals may arrive. Each becomes a **dispute alert** (`dpa_`) on the intent; none changes the intent's status by itself.

| Source | What it is | Platform action options | Deadline |
|---|---|---|---|
| Ethoca Alerts (Mastercard) | Issuer reports confirmed fraud or a customer dispute in progress | Refund to stop chargeback; cancel future shipments/subscriptions | Short (typically 24–72h) |
| Verifi CDRN (Visa) | Dispute notification before it becomes a chargeback | Refund or let it proceed | ~72h |
| Visa RDR (Rapid Dispute Resolution) | Merchant-defined rules auto-accept a dispute before it is filed | Rules decide automatically (e.g. amount ≤ $25, reason "not received" where tracking absent) | Real-time |
| Visa Order Insight / Mastercard Consumer Clarity | Issuer queries transaction details while the cardholder is on the phone | Return order details (line items, delivery, receipts) to deflect | Real-time |
| Retrieval request / inquiry (Amex, Discover; Visa RFI) | Issuer asks for a copy of the transaction record | Respond with evidence; non-response often becomes a chargeback | Days |

The **dispute-prevention policy** ([`config/dispute-policy.yaml`](../config/dispute-policy.yaml)) decides auto-refund vs. respond vs. ignore, per reason, amount, customer value, and — in a marketplace — per seller. Auto-refunds created this way are ordinary refund operations (`initiated_by: dispute_prevention`), so they hit the same line allocations and seller ledgers.

---

## 9. Disputes

### Lifecycle

```mermaid
stateDiagram-v2
  [*] --> inquiry: retrieval / inquiry (optional)
  inquiry --> needs_response: escalates to chargeback
  inquiry --> closed_no_dispute: answered, no chargeback
  [*] --> needs_response: chargeback received (funds withdrawn)
  needs_response --> under_review: evidence submitted (representment / pre-arb response)
  needs_response --> lost: accepted by merchant, or deadline missed
  under_review --> won: issuer accepts representment
  under_review --> pre_arbitration: issuer escalates
  pre_arbitration --> lost: merchant accepts
  pre_arbitration --> arbitration: merchant declines, network rules
  pre_arbitration --> won: issuer withdraws
  arbitration --> won
  arbitration --> lost
  won --> [*]
  lost --> [*]
```

| Network flow | Stages | Merchant response window (default, verify) |
|---|---|---|
| Visa (VCR) — *allocation* (fraud, authorization) | Dispute → pre-arbitration (merchant initiates, with e.g. Compelling Evidence 3.0) → arbitration | ~30 days to respond |
| Visa (VCR) — *collaboration* (processing errors, consumer disputes) | Dispute → dispute response (representment) → pre-arbitration → arbitration | ~30 days |
| Mastercard | First chargeback → second presentment → pre-arbitration → arbitration | ~45 days for second presentment |
| Amex | Inquiry → chargeback → (representment) | ~20 days |
| Discover | Inquiry → chargeback → representment → arbitration | ~30 days |
| ACH | Unauthorized return (R05/R07/R10/R11/R29) — **no representment on the rail**; recovery is a new debit with fresh authorization, or collections | — |
| BNPL | Provider-mediated dispute; provider pauses the buyer's payments and asks merchant for evidence | Provider SLA |

### What the intent does

| Dispute event | Intent status | Amounts | Financial |
|---|---|---|---|
| Chargeback received | `disputed` | `amount_disputed += x` | Acquiring ledger: Dr dispute receivable / Cr cash (funds withdrawn) + dispute fee |
| Evidence submitted | `disputed` | — | — |
| Won | Back to prior state (`captured` / `partially_refunded`) | `amount_disputed -= x` | Funds reinstated |
| Lost / accepted | `disputed` (terminal for that dispute) | `amount_charged_back += x` | Loss written to the liable party (merchant, or per marketplace rule) |
| Pre-arbitration lost after a won representment | `disputed` again, then lost | as above | Second debit; arbitration fee if escalated |

### Liability inputs the platform already holds

* **Authentication**: 3DS with liability shift on the attempt → fraud reasons (Visa 10.4 / Mastercard 4837) are typically auto-defensible.
* **Compelling Evidence 3.0** (Visa 10.4): two prior undisputed transactions on the same credential, 120–365 days old, matching device/IP plus another identifier — the platform can assemble this from the credential and order history automatically.
* **Delivery evidence**: shipment tracking and proof of delivery on the order's fulfillment groups (for "not received").
* **Refund evidence**: refund operations with ARNs (for "credit not processed").
* **Agent evidence**: the purchase evidence record with the mandate version and authority record (for agentic purchases).

### Monitoring programmes
Dispute and fraud ratios are tracked per merchant, per seller and per sub-merchant against network monitoring thresholds (Visa VAMP, Mastercard ECM/EFM) in `dispute-policy.yaml`. Breaches raise platform alerts and, in marketplaces, can trigger seller-level reserves.

---

## 10. Everything at once: one intent through its life

A marketplace order of $118.00 paid by Visa credit, two sellers, two shipments, a backorder, a return and a dispute.

| Day | Event | Operation / attempt | Payment | Authorization | Financial | Order |
|---|---|---|---|---|---|---|
| 0 | Checkout, 3DS frictionless | op_1 authorize $118 · att_1 acq A soft decline · att_2 acq B approved | `authorized` | active $118, exp day 10 | — | `confirmed`, `authorized` |
| 1 | Seller A ships | op_2 capture seq 1 $70 | `partially_captured` | capturable $48 | receivable $70 | `in_progress`, `partially_collected` |
| 3 | Settlement of $70 | — | — | — | pending → available day 5 | `settlement: discharging` |
| 9 | Seller B backordered; expiry lead time reached | op_3 reauthorization $48 (MIT, ref NTI) approved; op_4 reversal of op_1 remaining $48 | `partially_captured` | active $48 (op_3), exp day 14 (MIT validity) | — | timeline: `payment.reauthorized` |
| 12 | Seller B ships | op_5 capture seq 2 final $48 | `captured` | capturable 0 | receivable $48 | `completed`, `collected` |
| 20 | Customer returns seller B's item | op_6 refund $44 of op_5 (item $40 + tax $4) | `partially_refunded` | — | refund payable | `partially_returned`, `partially_refunded` |
| 40 | Ethoca alert on seller A's capture — rule says respond, not refund | dpa_1 `declined_by_rule` | unchanged | — | — | `dispute_status: alerted` |
| 45 | Chargeback 13.1 "not received" on op_2 $70 | dp_1 `needs_response` | `disputed` | — | $70 withdrawn + $15 fee | `dispute_status: open`; seller A payout held per rule |
| 46 | Platform auto-submits tracking + proof of delivery | dp_1 `under_review` | `disputed` | — | — | — |
| 70 | Issuer accepts representment | dp_1 `won` | `partially_refunded` (restored) | — | $70 reinstated | `dispute_status: won`; seller A hold released |
| 150 | Dispute window closes | — | — | — | — | `closed` |

The intent's id never changed; the merchant handled two webhooks it cared about (`payment_intent.captured`, `payment_intent.dispute.closed`) and the platform did the rest.

---

## 11. Methods other than card — the same skeleton

### ACH debit (e.g. subscription box paid by bank)

| Day | Event | Payment | Finality | Notes |
|---|---|---|---|---|
| 0 | Confirm; account validated (WEB debit rule) | `processing` | — | Validation via micro-deposit, instant verification or a validation service |
| 0 | Debit entry accepted by ODFI | `captured` (D86) | `provisional`, reversible until day 60 (unauthorized) | Funds `receivable` |
| 2 | Settlement | `captured` | `provisional` | Funds `pending`, held per ACH risk policy |
| 3 | R01 return (NSF) | `failed` with `retryability: retryable, max 2 re-presentments in 180 days` | — | **This is NSF, not a dispute** — see [10 · NSF signals](10-nsf-signals-and-retries.md) |
| 5 | Re-presented (`origin: scheduled_retry`) after funds signal | `processing` → `captured` | `provisional` | Same intent, new operation |
| 40 | R10 return (customer says unauthorized) | `disputed` (lost on arrival — no representment on ACH) | — | Merchant may pursue with a new authorization |
| 62 | Return window closed | `captured` | `final` | — |

### BNPL

| Event | Payment | Notes |
|---|---|---|
| Confirm → redirect to provider | `requires_action` | Buyer approves the plan |
| Provider approves | `authorized` | Provider holds the authorization; validity per provider contract |
| Capture per shipment | `partially_captured` → `captured` | Provider supports multiple partial captures; the merchant is paid by the provider (net of its fee) on the provider's schedule |
| Authorization nearing expiry | Provider extension call (`reauthorization` op on rail `bnpl:<provider>`) if supported; else notify | No MIT reauth with a card network; the provider's API is the rail |
| Refund | `partially_refunded` | Provider adjusts the buyer's plan; merchant settlement reduced |
| Buyer disputes | `disputed` | Provider-mediated; evidence submitted through the provider adapter; buyer payments paused |

### RTP / FedNow (request for payment)

`requires_action` (payer approves RfP) → `captured` and `final` at once. No authorization, no reversal; refunds are new credits; a "dispute" is a return request the merchant may honour or decline — the platform models it as a dispute with `network_flow: instant_return_request`.

---

## 12. What an implementer must never do (the failure list)

1. Retry an authorization at a second acquirer while the first outcome is unknown without reversal advice — duplicate holds.
2. Capture after expiry silently — fees and "no authorization" chargebacks.
3. Refund an amount under open dispute — double loss.
4. Treat an ACH acceptance as final — 60-day unauthorized returns.
5. Treat a pre-dispute alert as a dispute in the intent status — it is not one, and most never become one.
6. Re-present an ACH NSF more than twice, or retry a Mastercard MAC 03 / Visa category-1 decline — network/Nacha violations.
7. Reauthorize without stored-credential consent — the reauthorization is an MIT and must be permitted by the original agreement.
8. Infer the intent's status from the ledger, or the ledger from the status — four state models, kept apart.
